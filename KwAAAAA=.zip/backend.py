"""
Local pump bridge server.

Serves both front-end pages and the pump control API from one process:
  http://localhost:5005/       -> public/kiosk.html      (the controller UI)
  http://localhost:5005/test   -> public/test_mode.html  (the TV test dashboard)

Run directly with `python backend.py`, or via start.sh which also opens the
controller UI and captures logs automatically.

Install once: pip install flask flask-cors pyserial
"""

import os
import time
import logging
import threading
import serial
from flask import Flask, request, jsonify, send_from_directory

# ---- CONFIGURE THIS ----
SERIAL_PORT = "/dev/ttyACM0"   # Windows: something like "COM5"
BAUD_RATE = 9600
PUMP_COUNT = 9  # 1-8 flavor pumps, 9 = primary sparkling water pump
# -------------------------

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
PUBLIC_DIR = os.path.join(BASE_DIR, "public")
LOG_DIR = os.path.join(BASE_DIR, "logs")
os.makedirs(LOG_DIR, exist_ok=True)

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s",
    handlers=[
        logging.FileHandler(os.path.join(LOG_DIR, "server.log")),
        logging.StreamHandler(),
    ],
)
log = logging.getLogger("pump_backend")

app = Flask(__name__)
from flask_cors import CORS
CORS(app)  # harmless to keep even now both pages are same-origin

arduino = None
arduino_lock = threading.Lock()
state_lock = threading.Lock()

pump_state = {
    i: {"active": False, "speed": 0, "total_seconds": 0.0, "started_at": None}
    for i in range(1, PUMP_COUNT + 1)
}


# ---------------- serial handling ----------------

def get_serial():
    """Open the serial connection once, and start the background reader thread.
    Raises serial.SerialException if the Arduino isn't reachable — callers must
    catch this so one disconnected board doesn't crash the whole server."""
    global arduino
    with arduino_lock:
        if arduino is None:
            arduino = serial.Serial(SERIAL_PORT, BAUD_RATE, timeout=1)
            time.sleep(2)  # Arduino resets when the serial connection opens
            threading.Thread(target=serial_reader, daemon=True).start()
            log.info("Serial connected on %s @ %d baud", SERIAL_PORT, BAUD_RATE)
    return arduino


def _finalize(pump_id):
    s = pump_state[pump_id]
    if s["started_at"] is not None:
        s["total_seconds"] += time.time() - s["started_at"]
    s["active"] = False
    s["started_at"] = None


def serial_reader():
    while True:
        try:
            line = arduino.readline().decode(errors="ignore").strip()
        except Exception as e:
            log.error("Serial reader stopped: %s", e)
            break
        if not line:
            continue
        log.info("ARDUINO: %s", line)
        if line.startswith("DONE"):
            try:
                pump_id = int(line.split()[1])
            except (IndexError, ValueError):
                continue
            with state_lock:
                _finalize(pump_id)


def live_status():
    now = time.time()
    out = []
    for pump_id, s in pump_state.items():
        total = s["total_seconds"]
        if s["active"] and s["started_at"] is not None:
            total += now - s["started_at"]
        out.append({
            "pump": pump_id, "active": s["active"],
            "speed": s["speed"], "total_seconds": round(total, 1),
        })
    return out


def send_command(cmd):
    """Send one line to the Arduino and return its reply, logging both sides."""
    ser = get_serial()
    ser.write((cmd + "\n").encode())
    reply = ser.readline().decode().strip()
    log.info("SENT: %s  -> REPLY: %s", cmd, reply or "(no reply)")
    return reply


# ---------------- static pages ----------------

@app.route("/")
def serve_controller():
    return send_from_directory(PUBLIC_DIR, "kiosk.html")


@app.route("/test")
def serve_test():
    return send_from_directory(PUBLIC_DIR, "test_mode.html")


# ---------------- API ----------------

@app.route("/fire", methods=["POST"])
def fire():
    data = request.get_json(force=True)
    pump, ms, speed = int(data["pump"]), int(data.get("ms", 500)), int(data.get("speed", 100))
    try:
        with state_lock:
            pump_state[pump].update(active=True, speed=speed, started_at=time.time())
        reply = send_command(f"FIRE {pump} {ms} {speed}")
        return jsonify({"arduino_reply": reply})
    except serial.SerialException as e:
        log.error("FIRE failed, pump=%s: %s", pump, e)
        return jsonify({"error": str(e)}), 503


@app.route("/start", methods=["POST"])
def start():
    data = request.get_json(force=True)
    pump, speed = int(data["pump"]), int(data.get("speed", 100))
    try:
        reply = send_command(f"START {pump} {speed}")
        with state_lock:
            pump_state[pump].update(active=True, speed=speed, started_at=time.time())
        return jsonify({"arduino_reply": reply})
    except serial.SerialException as e:
        log.error("START failed, pump=%s: %s", pump, e)
        return jsonify({"error": str(e)}), 503


@app.route("/stop", methods=["POST"])
def stop():
    data = request.get_json(force=True)
    pump = int(data["pump"])
    try:
        reply = send_command(f"STOP {pump}")
        with state_lock:
            _finalize(pump)
        return jsonify({"arduino_reply": reply})
    except serial.SerialException as e:
        log.error("STOP failed, pump=%s: %s", pump, e)
        return jsonify({"error": str(e)}), 503


@app.route("/stopall", methods=["POST"])
def stopall():
    try:
        reply = send_command("STOPALL")
        with state_lock:
            for pump_id in pump_state:
                _finalize(pump_id)
        return jsonify({"arduino_reply": reply})
    except serial.SerialException as e:
        log.error("STOPALL failed: %s", e)
        return jsonify({"error": str(e)}), 503


@app.route("/selftest", methods=["POST"])
def selftest():
    data = request.get_json(force=True)
    pumps = data.get("pumps", [])
    results = []
    try:
        for p in pumps:
            with state_lock:
                pump_state[p["id"]].update(active=True, speed=p.get("speed", 100), started_at=time.time())
            reply = send_command(f"FIRE {p['id']} 400 {p.get('speed', 100)}")
            results.append({"pump": p["id"], "reply": reply})
            time.sleep(0.5)
        return jsonify({"results": results})
    except serial.SerialException as e:
        log.error("Self-test failed: %s", e)
        return jsonify({"error": str(e), "results": results}), 503


@app.route("/status", methods=["GET"])
def status():
    try:
        get_serial()
    except serial.SerialException as e:
        log.error("Status check: serial unavailable: %s", e)
        return jsonify({"error": str(e)}), 503
    with state_lock:
        return jsonify(live_status())


if __name__ == "__main__":
    log.info("Starting pump backend on http://localhost:5005")
    app.run(port=5005)
