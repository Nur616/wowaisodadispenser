#!/usr/bin/env bash
# Starts the pump backend and opens the controller UI in the default browser.
# All output is captured to logs/ so nothing gets lost if the terminal closes.

set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"

mkdir -p logs
STAMP=$(date +"%Y%m%d_%H%M%S")
RUN_LOG="logs/start_${STAMP}.log"

echo "[$(date)] Launching backend..." | tee -a "$RUN_LOG"
python3 backend.py >> "$RUN_LOG" 2>&1 &
BACKEND_PID=$!
echo "[$(date)] Backend PID: $BACKEND_PID" | tee -a "$RUN_LOG"

# make sure the backend (and this script) get cleaned up on exit/Ctrl+C
trap 'echo "[$(date)] Stopping backend (PID $BACKEND_PID)..." | tee -a "$RUN_LOG"; kill "$BACKEND_PID" 2>/dev/null' EXIT

# wait for the server to actually come up before opening a browser to it
echo "[$(date)] Waiting for backend to respond..." | tee -a "$RUN_LOG"
for i in $(seq 1 20); do
  if curl -s -o /dev/null --max-time 1 http://localhost:5005/; then
    echo "[$(date)] Backend is up." | tee -a "$RUN_LOG"
    break
  fi
  sleep 0.5
done

URL="http://localhost:5005/"
echo "[$(date)] Opening controller UI: $URL" | tee -a "$RUN_LOG"
if command -v xdg-open > /dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1
elif command -v open > /dev/null 2>&1; then
  open "$URL"
else
  echo "Could not auto-open a browser — open this manually: $URL" | tee -a "$RUN_LOG"
fi

echo ""
echo "Controller UI:   $URL"
echo "Test dashboard:  http://localhost:5005/test"
echo "Run log:         $RUN_LOG"
echo "Server log:      logs/server.log"
echo ""
echo "Press Ctrl+C to stop the backend."

wait "$BACKEND_PID"
