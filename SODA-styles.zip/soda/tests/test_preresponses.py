"""PRERESPONSES.TXT must stay machine-parseable by the kiosk matcher.

Each non-comment line is ``trigger | trigger || answer``. A malformed line is
silently ignored at runtime, which is hard to notice — this test catches it.
"""

from pathlib import Path

BASE = Path(__file__).resolve().parents[1]
PRERESPONSES = BASE / "PRERESPONSES.TXT"


def entries():
    rows = []
    for number, line in enumerate(PRERESPONSES.read_text(encoding="utf-8").splitlines(), 1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        rows.append((number, line))
    return rows


def test_file_exists_and_has_entries():
    assert PRERESPONSES.is_file()
    assert len(entries()) >= 20


def test_every_line_has_triggers_and_a_humorous_answer():
    for number, line in entries():
        assert "||" in line, f"PRERESPONSES.TXT line {number} lacks '||': {line[:70]}"
        triggers, answer = line.split("||", 1)
        trigger_list = [t.strip() for t in triggers.split("|") if t.strip()]
        assert trigger_list, f"PRERESPONSES.TXT line {number} has no trigger phrases"
        assert answer.strip(), f"PRERESPONSES.TXT line {number} has an empty answer"
        assert len(answer.strip()) >= 10, f"PRERESPONSES.TXT line {number} answer is too short"


def test_answers_are_single_line():
    for number, line in enumerate(PRERESPONSES.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip() or line.strip().startswith("#"):
            continue
        assert "\n" not in line, f"PRERESPONSES.TXT line {number} contains a newline"

    # sanity: nothing accidentally left open with a quote-only reply
    for number, line in entries():
        answer = line.split("||", 1)[1].strip()
        assert answer not in ("'", '"', "');"), f"PRERESPONSES.TXT line {number} has a broken answer"


def test_kiosk_exposes_the_presaves_trainer():
    html = (BASE / "kiosk.html").read_text(encoding="utf-8")
    assert 'data-tab="presaves"' in html
    assert 'id="tab-presaves"' in html
    for key in ("prEnabled", "prQuestionOnly", "prThreshold", "prMinWords", "prSpeak", "prWhileBusy", "prLearnMisses"):
        assert key in html, f"training option {key} missing from kiosk.html"
