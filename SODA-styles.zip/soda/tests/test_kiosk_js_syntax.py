"""Every inline <script> block in kiosk.html must be valid JavaScript (node --check)."""

import re
import subprocess
import tempfile
from pathlib import Path

KIOSK = Path(__file__).resolve().parents[1] / "kiosk.html"
SCRIPT_RE = re.compile(r"<script(?![^>]*\bsrc=)[^>]*>(.*?)</script>", re.S | re.I)


def test_every_inline_script_block_is_valid_js():
    html = KIOSK.read_text(encoding="utf-8")
    blocks = SCRIPT_RE.findall(html)
    assert blocks, f"no inline <script> blocks found in {KIOSK}"
    for i, body in enumerate(blocks):
        with tempfile.NamedTemporaryFile("w", suffix=".js", delete=False, encoding="utf-8") as tmp:
            tmp.write(body)
            tmp_path = tmp.name
        result = subprocess.run(["node", "--check", tmp_path], capture_output=True, text=True)
        Path(tmp_path).unlink(missing_ok=True)
        assert result.returncode == 0, (
            f"inline <script> block #{i} in {KIOSK.name} is not valid JS:\n{result.stderr}"
        )
