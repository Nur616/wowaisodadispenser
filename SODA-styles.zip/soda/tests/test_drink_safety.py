"""Unit tests for the recipe safety layer (no hardware required)."""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from drink_safety import MAX_TOTAL_EXTRACT_ML, assess, identify


def pumps(**overrides):
    base = {
        1: {"id": 1, "flavor": "Cherry", "speed": 80, "flow_ml_per_second": 1.0},
        2: {"id": 2, "flavor": "Lime", "speed": 80, "flow_ml_per_second": 1.0},
        3: {"id": 3, "flavor": "Vanilla extract", "speed": 80, "flow_ml_per_second": 1.0},
        4: {"id": 4, "flavor": "Peanut", "speed": 80, "flow_ml_per_second": 1.0},
        9: {"id": 9, "flavor": "Sparkling water", "speed": 100, "flow_ml_per_second": 20.0},
    }
    base.update(overrides)
    return base


def recipe(*ingredients):
    return {
        "name": "Test drink",
        "reply": "A test.",
        "ingredients": [
            {"pump_id": pump_id, "flavor": flavor, "seconds": seconds, "speed": 80}
            for pump_id, flavor, seconds in ingredients
        ],
    }


def test_lemon_has_no_major_allergen():
    profile = identify("Lime")
    assert profile["family"] == "citrus"
    assert profile["allergens"] == {}
    assert profile["unknown"] is False


def test_peanut_is_a_contains_allergen():
    result = assess(recipe((4, "Peanut", 2)), pumps(), cup_ml=355)
    safety = result["safety"]
    assert safety["severity"] == "L2"
    assert "peanuts" in safety["allergens"]["contains"]
    assert "Allergy warning: contains peanuts." in [w["text"] for w in safety["warnings"]]
    assert safety["ack_required"] is True


def test_unknown_flavour_requires_an_unknown_warning():
    result = assess(recipe((1, "Dragonfruit surprise", 2)), pumps(), cup_ml=355)
    safety = result["safety"]
    assert safety["severity"] == "L3"
    assert safety["ack_required"] is True
    assert any(w["kind"] == "unknown" for w in safety["warnings"])


def test_vanilla_extract_reports_alcohol():
    result = assess(recipe((3, "Vanilla extract", 2)), pumps(), cup_ml=355)
    safety = result["safety"]
    assert safety["abv_percent"] > 0
    assert safety["severity"] in ("L4", "L2", "L3")
    assert any(w["kind"] == "alcohol" for w in safety["warnings"])


def test_long_dose_is_capped_and_water_is_added():
    result = assess(recipe((1, "Cherry", 12)), pumps(), cup_ml=355)
    flavour = [i for i in result["recipe"]["ingredients"] if i["pump_id"] == 1][0]
    water = [i for i in result["recipe"]["ingredients"] if i["pump_id"] == 9][0]
    assert flavour["seconds"] <= 2
    assert water["seconds"] >= 1
    safety = result["safety"]
    assert safety["estimated_flavor_ml"] <= MAX_TOTAL_EXTRACT_ML
    assert safety["estimated_water_ml"] >= 40 * safety["estimated_flavor_ml"]


def test_forbidden_botanical_is_blocked():
    result = assess(recipe((1, "Wintergreen oil", 1)), pumps(), cup_ml=355)
    safety = result["safety"]
    assert safety["blocked"] is True
    assert safety["severity"] == "BLOCKED"
    assert safety["ack_required"] is False


def test_declared_allergy_conflict_is_blocked():
    result = assess(recipe((4, "Peanut", 2)), pumps(), cup_ml=355, declared_allergens=["peanut"])
    safety = result["safety"]
    assert safety["blocked"] is True
    assert any("declared allergy" in w["text"].lower() for w in safety["warnings"])


def test_no_water_pump_caps_flavour_to_a_concentrate():
    available = pumps()
    del available[9]
    result = assess(recipe((1, "Cherry", 12)), available, cup_ml=355)
    flavour = [i for i in result["recipe"]["ingredients"] if i["pump_id"] == 1][0]
    assert flavour["seconds"] == 1
    assert any("concentrate" in w["text"].lower() for w in result["safety"]["warnings"])


def test_uncalibrated_pump_uses_a_conservative_default():
    available = pumps()
    available[1]["flow_ml_per_second"] = 0
    result = assess(recipe((1, "Cherry", 12)), available, cup_ml=355)
    flavour = [i for i in result["recipe"]["ingredients"] if i["pump_id"] == 1][0]
    assert flavour["seconds"] <= 1
    assert result["safety"]["estimated_flavor_ml"] <= 2.0
    assert result["safety"]["calibrated"] is False


def test_pump_that_is_too_fast_is_blocked():
    available = pumps()
    available[1]["flow_ml_per_second"] = 5.0
    result = assess(recipe((1, "Cherry", 1)), available, cup_ml=355)
    assert result["safety"]["blocked"] is True
    assert any("safe dose" in w["text"] for w in result["safety"]["warnings"])


def test_hash_is_stable_when_assessed_twice():
    first = assess(recipe((1, "Cherry", 12)), pumps(), cup_ml=355)
    second = assess(first["recipe"], pumps(), cup_ml=355)
    assert first["safety"]["recipe_hash"] == second["safety"]["recipe_hash"]
    assert first["recipe"]["ingredients"] == second["recipe"]["ingredients"]


def test_water_pump_is_always_included_when_flavour_is_used():
    result = assess(recipe((1, "Cherry", 2)), pumps(), cup_ml=355)
    ids = [item["pump_id"] for item in result["recipe"]["ingredients"]]
    assert 9 in ids


def test_large_cup_stays_within_final_volume():
    result = assess(recipe((1, "Cherry", 2)), pumps(), cup_ml=700)
    safety = result["safety"]
    assert safety["estimated_total_ml"] <= 700
    assert safety["estimated_water_ml"] >= 40 * safety["estimated_flavor_ml"]


def test_supplier_override_beats_catalogue():
    available = pumps()
    available[1]["allergens"] = ["may:sesame"]
    profile = identify("Cherry", available[1])
    assert profile["unknown"] is False
    assert profile["allergens"] == {"sesame": "may_contain"}
    result = assess(recipe((1, "Cherry", 2)), available, cup_ml=355)
    assert "sesame" in result["safety"]["allergens"]["may_contain"]


def test_cream_soda_is_not_an_intentional_milk_drink():
    profile = identify("Cream soda")
    assert profile["family"] == "vanilla"
    assert profile["allergens"].get("milk") == "may_contain"


def test_root_beer_is_not_beer():
    profile = identify("Root beer")
    assert profile["family"] == "coffee_cocoa_bitter"
    assert "gluten_cereal" not in profile["allergens"]
    assert profile["abv"] == 0


def test_unknown_override_keeps_the_status_unknown():
    profile = identify("Cherry", {"allergens": "unknown"})
    assert profile["unknown"] is True
    assert profile["allergens"]


def test_hash_changes_when_supplier_data_changes():
    first = assess(recipe((1, "Cherry", 2)), pumps(), cup_ml=355)
    available = pumps()
    available[1]["allergens"] = ["may:sesame"]
    second = assess(recipe((1, "Cherry", 2)), available, cup_ml=355)
    assert first["safety"]["recipe_hash"] != second["safety"]["recipe_hash"]
