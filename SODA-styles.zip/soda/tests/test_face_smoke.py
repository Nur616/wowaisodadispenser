"""Atomic-swap smoke tests — the parametric engine now drives v1/v2 rendering.

These exercise the live page through the same fixture as test_face_engine.py
(chromium software-compositing flags, unfiltered pageerror capture). The kiosk
is one IIFE, so the tests reach the mood/mode entry points via the sanctioned
``window.__faceTest`` mirror (``setMood``/``express``/``setMode``/``applyFaceLook``
/``config``) and prefer ``window.CodaFace.express`` where it suffices; the
engine's own surface (``EMOTIONS``/``LAYOUT_*``/...) stays window-mirrored from
Task 2 and is treated as read-only.

Known-and-ignored console errors, all artifacts of loading the kiosk straight
off disk (file://) that exist with or without the swap (see test_face_engine.py):
  * ``/omni/*.css|js`` — backend-served scripts/styles;
  * ``Fetch API cannot load file:///hardware`` / ``file:///jarvis/status`` —
    fetch() rejects file: URLs inside Blink before any request is made.
The ``/kiosk/storage`` CORS probe IS interceptable and is routed to a stub.
"""

import re
from pathlib import Path

import pytest
from playwright.sync_api import sync_playwright

KIOSK = Path(__file__).resolve().parents[1] / "kiosk.html"
URL = KIOSK.resolve().as_uri()  # file:///.../kiosk.html
LAUNCH_ARGS = ["--disable-gpu", "--disable-gpu-compositing", "--use-gl=swiftshader"]

IGNORED_CONSOLE_ERRORS = re.compile(
    r"/omni/"
    r"|Fetch API cannot load file:///hardware"
    r"|Fetch API cannot load file:///jarvis/status"
    # the portable-settings probe (top of kiosk.html) XHRs /kiosk/storage fine
    # (routed to a stub), but its keepalive POST fetch to a file:// URL fails at
    # the scheme level a few seconds after load and Blink logs it before any
    # promise .catch can see it — unsuppressible file:// artifact, same class
    # as the /hardware and /jarvis/status fetches above
    r"|Fetch API cannot load file:///kiosk/storage"
    # opening Settings ▸ Face (test_settings_emotion_tuning) fires the panel's
    # diagnostics/model-catalog refresh — same file:// artifact class as
    # /hardware above, just paths no earlier test ever reached
    r"|Fetch API cannot load file:///ai/"
    r"|Fetch API cannot load file:///status"
    r"|Fetch API cannot load file:///flow-status"
)


@pytest.fixture(scope="module")
def page():
    errors = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=LAUNCH_ARGS)
        pg = browser.new_page()

        def capture(msg):
            if msg.type != "error":
                return
            text = (f"{msg.text} ({msg.location.get('url', '')})")
            if not IGNORED_CONSOLE_ERRORS.search(text):
                errors.append(f"console.error: {text}")

        pg.on("pageerror", lambda err: errors.append(f"pageerror: {err}"))
        pg.on("console", capture)
        pg.route("**/kiosk/storage*",
                 lambda route: route.fulfill(status=200, content_type="application/json", body="{}"))
        pg.goto(URL)
        pg.wait_for_load_state("load")
        yield pg, errors
        browser.close()


# --------------------------------------------------------------------------
# helpers
# --------------------------------------------------------------------------
def set_version(pg, n):
    """Switch the live face version (config is IIFE state, reached via the hook)."""
    pg.evaluate(
        "() => { window.__faceTest.config.face.version = %d; window.__faceTest.applyFaceLook(); }" % n
    )
    pg.wait_for_timeout(120)


def set_face_cfg(pg, version, **keys):
    def fmt(v):
        if isinstance(v, str):
            return repr(v)
        if isinstance(v, bool):
            return "true" if v else "false"
        return str(v)
    kv = ",".join(f"{k}:{fmt(v)}" for k, v in keys.items())
    pg.evaluate(
        "() => { Object.assign(window.__faceTest.config.face.v%d, {%s}); window.__faceTest.applyFaceLook(); }"
        % (version, kv)
    )


def express(pg, mood, ms=800):
    pg.evaluate("m => window.CodaFace.express(m[0], m[1])", [mood, ms])


def clear_lock(pg):
    """Reset moodLock + decay timer (CodaFace.express turns ms=0 into 6000, so use the hook)."""
    pg.evaluate("() => window.__faceTest.express('content', 0)")


def eye_d(pg, side="L"):
    return pg.evaluate("s => document.getElementById('fvEye' + s).getAttribute('d')", side)


def d_height(d):
    """Bounding-box height of an engine eye path (points alternate x,y; Z closes)."""
    nums = [float(v) for v in re.findall(r"-?\d+\.?\d*", d)]
    ys = nums[1::2]
    return max(ys) - min(ys)


def mood_names(pg):
    return pg.evaluate("() => Object.keys(EMOTIONS)")


# --------------------------------------------------------------------------
# sweep / stability
# --------------------------------------------------------------------------
def test_sweep_all_22_moods_v1_and_v2(page):
    pg, errors = page
    moods = mood_names(pg)
    assert len(moods) == 22
    for version in (1, 2):
        set_version(pg, version)
        before = len(errors)
        for m in moods:
            express(pg, m, 600)
            pg.wait_for_timeout(120)
        assert len(errors) == before, f"console errors sweeping v{version}: {errors[before:]}"
        if version == 2:
            d = eye_d(pg)
            assert d and d.startswith("M"), f"v2 fvEyeL has no path after sweep: {d!r}"
        else:
            painted = pg.evaluate(
                "() => { const c = document.getElementById('faceCanvas');"
                " const x = c.getContext('2d');"
                " const px = x.getImageData(0, 0, c.width, c.height).data;"
                " let n = 0; for(let i = 3; i < px.length; i += 4) if(px[i] > 8) n++; return n; }"
            )
            assert painted > 50, f"v1 canvas looks blank: {painted} painted pixels"
    # two different moods must land on different v2 eye paths
    set_version(pg, 2)
    clear_lock(pg)
    express(pg, "surprised", 900)
    pg.wait_for_timeout(450)
    d_surprised = eye_d(pg)
    express(pg, "sad", 900)
    pg.wait_for_timeout(450)
    d_sad = eye_d(pg)
    assert d_surprised and d_sad and d_surprised != d_sad, (
        "surprised and sad produced identical fvEyeL paths"
    )


def test_b7_eye_nodes_never_rebuilt(page):
    pg, _ = page
    set_version(pg, 2)
    clear_lock(pg)
    handle = pg.query_selector("#fvEyeL")
    assert handle, "#fvEyeL not found"
    for m in ["happy", "sad", "surprised", "angry", "love", "confused"]:
        express(pg, m, 400)
        pg.wait_for_timeout(160)
    same = pg.evaluate("el => el === document.getElementById('fvEyeL')", handle)
    assert same, "#fvEyeL was replaced during the mood sweep (rebuild flicker is back)"


# --------------------------------------------------------------------------
# targeted regressions (B-numbering from the design spec)
# --------------------------------------------------------------------------
def test_b1_mouth_fill_follows_open_mouth(page):
    pg, _ = page
    set_version(pg, 2)
    express(pg, "surprised", 2500)
    pg.wait_for_timeout(1400)                      # let the eased mouth reach o >= .12
    fill_open = pg.evaluate("() => getComputedStyle(document.getElementById('fvMouth')).fill")
    assert fill_open == "currentColor" or fill_open.startswith("rgb("), (
        f"open mouth fill should be currentColor (resolved), got {fill_open!r}"
    )
    express(pg, "happy", 2500)                     # happy: c .90, o .10 -> curve, no fill
    pg.wait_for_timeout(1600)
    fill_closed = pg.evaluate("() => getComputedStyle(document.getElementById('fvMouth')).fill")
    assert fill_closed == "none", f"happy mouth should be an unfilled curve, got fill={fill_closed!r}"


def test_b5_setmood_content_not_early_returned(page):
    pg, _ = page
    set_version(pg, 2)
    pg.evaluate("() => window.__faceTest.setMode('idle', 'IDLE')")
    pg.evaluate("() => window.__faceTest.setMood('sad')")
    pg.wait_for_timeout(800)
    d_sad = eye_d(pg)
    pg.evaluate("() => window.__faceTest.setMood('content')")
    pg.wait_for_timeout(800)
    d_content = eye_d(pg)
    assert d_sad and d_content and d_content != d_sad, (
        "setMood('content') did not change the v2 eye path (FV_MAP early-return bug is back)"
    )


def test_b9_engine_blinks_without_css_classes(page):
    pg, _ = page
    set_version(pg, 2)
    clear_lock(pg)
    set_face_cfg(pg, 2, blinkRate=600)             # faster blinks so a 3 s window catches several
    heights, gaze_seen, class_seen = [], False, set()
    for _ in range(60):                            # 60 x 50 ms = 3 s
        d = eye_d(pg)
        if d:
            heights.append(d_height(d))
        state = pg.evaluate(
            "() => ({"
            "  gaze: document.getElementById('fvGaze').style.transform,"
            "  blinkCls: document.querySelectorAll('#faceV2 .blink').length"
            "})"
        )
        gaze_seen = gaze_seen or bool(state["gaze"])
        class_seen.add(state["blinkCls"])
        pg.wait_for_timeout(50)
    set_face_cfg(pg, 2, blinkRate=100)
    assert len(heights) >= 40, f"too few path samples: {len(heights)}"
    hs = sorted(heights)
    median = hs[len(hs) // 2]
    assert any(h < 0.40 * median for h in heights), (
        f"no blink frame in 3 s of sampling (median height {median:.1f}, min {hs[0]:.1f})"
    )
    assert class_seen == {0}, f"#faceV2 .blink classes appeared during sampling: {class_seen}"
    assert gaze_seen, "#fvGaze never got a transform — v2 gaze is no longer transform-driven"


def test_b10_alias_shocked_renders_surprised(page):
    pg, _ = page
    set_version(pg, 2)

    def settled_d(mood):
        express(pg, mood, 2000)
        pg.wait_for_timeout(900)
        # blinks shrink the lids for ~300 ms; sample across ~0.5 s and take the
        # most-open frame so a blink crossing the capture window can't mask a
        # pose difference
        samples = []
        for _ in range(8):
            d = eye_d(pg)
            if d:
                samples.append(d)
            pg.wait_for_timeout(60)
        return max(samples, key=d_height)

    assert settled_d("surprised") == settled_d("shocked"), (
        "shocked and surprised produced different v2 eye paths (alias not resolved)"
    )


def test_mouth_toggle_hides_v2_mouth(page):
    pg, _ = page
    set_version(pg, 2)
    set_face_cfg(pg, 2, mouth=True)
    pg.wait_for_timeout(150)
    assert pg.evaluate("() => document.getElementById('fvMouth').style.opacity") == "1"
    set_face_cfg(pg, 2, mouth=False)
    pg.wait_for_timeout(150)
    assert pg.evaluate("() => document.getElementById('fvMouth').style.opacity") == "0", (
        "the Show mouth toggle no longer hides #fvMouth"
    )
    set_face_cfg(pg, 2, mouth=True)


def test_b3_pool_resumes_after_mood_lock_decays(page):
    """Ruling: runs on v1. Wrapping can't see IIFE-internal calls, so the
    auto-cycle is detected by sampling --eye: the frame loop writes the eased
    mood colour every frame and AUTO_POOLS' v1 mood colours are distinct from
    the neutral #b9f2df."""
    pg, _ = page
    set_version(pg, 1)
    pg.evaluate("() => window.dispatchEvent(new Event('pointerdown'))")   # wake + go idle
    set_face_cfg(pg, 1, expressions=True, expressionDelay=2)
    express(pg, "sad", 800)                        # locks the face for .8 s
    pg.wait_for_timeout(2000)                      # lock decay + first auto tick
    colors = set()
    for _ in range(16):                            # 16 x 500 ms = 8 s of auto-cycle
        c = pg.evaluate(
            "() => getComputedStyle(document.documentElement).getPropertyValue('--eye').trim()"
        )
        colors.add(c)
        pg.wait_for_timeout(500)
    set_face_cfg(pg, 1, expressions=False, expressionDelay=9)
    assert len(colors) >= 3, (
        f"the mood pool never resumed after the lock decayed (--eye stayed {colors})"
    )


def test_v3_untouched_and_new_moods_resolve(page):
    pg, errors = page
    set_version(pg, 3)
    visible = pg.evaluate(
        "() => ({"
        "  v3: getComputedStyle(document.getElementById('faceV3')).display,"
        "  v2: getComputedStyle(document.getElementById('faceV2')).display,"
        "  canvas: getComputedStyle(document.getElementById('faceCanvas')).display"
        "})"
    )
    assert visible["v3"] == "block", f"faceV3 not visible on v3: {visible}"
    assert visible["v2"] == "none" and visible["canvas"] == "none", f"v2/canvas still shown on v3: {visible}"
    before = len(errors)
    for m in ["excited", "proud", "confused", "laugh", "wink"]:   # FV3_MAP entries from Task 1
        express(pg, m, 500)
        pg.wait_for_timeout(150)
    assert len(errors) == before, f"expressing the 5 new moods on v3 raised errors: {errors[before:]}"
    set_version(pg, 1)


# --------------------------------------------------------------------------
# spec G6: existing features still work
# --------------------------------------------------------------------------
def test_g6_hands_wave_still_mounts(page):
    pg, _ = page
    pg.evaluate("() => window.Hands.perform({action:'wave', hand:'right'})")
    # the appear transition runs ~620 ms and rAF/CSS timing is loose under
    # software compositing, so poll instead of trusting one fixed wait
    state = {}
    for _ in range(15):
        state = pg.evaluate(
            "() => { const h = document.getElementById('handR');"
            " return {on: h.classList.contains('on'), opacity: getComputedStyle(h).opacity}; }"
        )
        if state["on"] and float(state["opacity"]) > 0.15:
            break
        pg.wait_for_timeout(150)
    assert state.get("on"), "Hands.perform({action:'wave'}) did not bring #handR on-stage"
    assert float(state["opacity"]) > 0, f"#handR is on-stage but invisible: {state}"
    pg.evaluate("() => window.Hands.hide('right')")


def test_g6_drink_mode_docks_the_face(page):
    pg, _ = page
    set_version(pg, 2)
    pg.wait_for_timeout(500)                       # let any dock transition settle first
    before = pg.evaluate("() => document.getElementById('faceV2').getBoundingClientRect().width")
    pg.evaluate("() => document.getElementById('frame').classList.add('drink-mode')")
    pg.wait_for_timeout(600)                       # .42s dock transition
    after = pg.evaluate("() => document.getElementById('faceV2').getBoundingClientRect().width")
    pg.evaluate("() => document.getElementById('frame').classList.remove('drink-mode')")
    pg.wait_for_timeout(500)
    assert before > 0 and after > 0 and after < before, (
        f"drink-mode did not dock #faceV2 (before={before:.0f}px, after={after:.0f}px)"
    )


def test_g6_sleep_wake_cycle_v2(page):
    pg, _ = page
    set_version(pg, 2)
    clear_lock(pg)
    pg.wait_for_timeout(400)
    awake = max(d_height(d) for d in (eye_d(pg), eye_d(pg), eye_d(pg)) if d)
    pg.evaluate("() => window.dispatchEvent(new Event('pointerdown'))")   # reset the sleep timer
    set_face_cfg(pg, 2, sleepAfter=1)
    # the sleep check runs once per rAF frame and frames are slow under
    # software compositing — poll for the state change, then let the
    # closed-lid ease settle before measuring
    pg.wait_for_function(
        "() => document.getElementById('statePill').textContent === 'SLEEPING'", timeout=6000
    )
    pg.wait_for_timeout(900)
    closed = [d_height(d) for d in (eye_d(pg), eye_d(pg), eye_d(pg)) if d]
    z_children = pg.evaluate("() => document.getElementById('fvZ').children.length")
    mode = pg.evaluate("() => document.getElementById('statePill').textContent")
    assert closed and max(closed) < 0.40 * awake, (
        f"sleeping eyes not near-closed (awake height {awake:.1f}, sleeping {closed})"
    )
    assert z_children == 3, f"sleeping v2 face should show 3 Z's, got {z_children}"
    assert mode == "SLEEPING", f"state pill should read SLEEPING, got {mode!r}"
    set_face_cfg(pg, 2, sleepAfter=60)             # disarm BEFORE waking, or the face instantly re-sleeps
    pg.evaluate("() => window.dispatchEvent(new Event('pointerdown'))")   # noteActivity wakes it
    pg.wait_for_function(
        "() => document.getElementById('statePill').textContent === 'IDLE'", timeout=6000
    )
    pg.wait_for_timeout(900)                       # let the open-lid ease settle
    reopened = max(d_height(d) for d in (eye_d(pg), eye_d(pg), eye_d(pg)) if d)
    assert reopened > 0.6 * awake, (
        f"eyes did not reopen after wake (awake {awake:.1f}, after wake {reopened:.1f})"
    )
    assert pg.evaluate("() => document.getElementById('statePill').textContent") == "IDLE"


# --------------------------------------------------------------------------
# Settings ▸ Face — "Emotion tuning" group
# --------------------------------------------------------------------------
def open_face_settings(pg):
    """Open Settings and the Face tab (the panel's controls are DOM-driven).

    The SETTINGS button is JS-clicked: under file:// the HUD's BACKEND OFFLINE
    badge parks on top of it and intercepts pointer events (a load-order HUD
    artifact, not what this test is about).
    """
    pg.evaluate("() => document.getElementById('settingsBtn').click()")
    pg.click('button.tab[data-tab="face"]')
    return pg.locator("#faceCtl .ctlRow", has_text="Customising").locator("select")


def face_row(pg, label):
    return pg.locator("#faceBody .ctlRow", has_text=label)


def set_range(pg, label, value):
    """Drive a #faceBody range control the way a slider drag does (input event)."""
    pg.evaluate(
        """([label, value]) => {
          const rows = [...document.querySelectorAll('#faceBody .ctlRow')];
          const row = rows.find(r => r.textContent.includes(label));
          const input = row.querySelector('input[type=range]');
          input.value = value;
          input.dispatchEvent(new Event('input', {bubbles: true}));
        }""",
        [label, str(value)],
    )


def settled_eye_d(pg, mood, ms=2000):
    """Most-open v2 eye path after expressing a mood (skips blink frames, like test_b10)."""
    pg.evaluate("m => window.__faceTest.express(m[0], m[1])", [mood, ms])
    pg.wait_for_timeout(900)
    samples = []
    for _ in range(8):
        d = eye_d(pg)
        if d:
            samples.append(d)
        pg.wait_for_timeout(60)
    return max(samples, key=d_height)


def test_settings_emotion_tuning(page):
    pg, _ = page
    set_version(pg, 1)                 # deterministic start (and what gets saved)
    customising = open_face_settings(pg)

    # all four controls exist on each editing tab (per-version fc() configs)
    for v in ("1", "2", "3"):
        customising.select_option(v)
        for label in ("Expression strength", "Idle personality",
                      "Quick micro-expressions", "Hold reactions for"):
            assert face_row(pg, label).count() == 1, (
                f"'{label}' control missing on face v{v} editing tab"
            )

    # drive v1 through the real controls: personality + intensity
    customising.select_option("1")
    face_row(pg, "Idle personality").locator("select").select_option("playful")
    set_range(pg, "Expression strength", 0)

    # persistence: reload and the saved config adopts the new values
    pg.reload()
    pg.wait_for_load_state("load")
    saved = pg.evaluate(
        "() => { const v = window.__faceTest.config.face.v1;"
        " return {p: v.personality, i: v.emotionIntensity, m: v.microExpressions, h: v.holdSeconds}; }"
    )
    assert saved == {"p": "playful", "i": 0, "m": True, "h": 6}, (
        f"emotion-tuning keys did not survive reload: {saved}"
    )

    # the reopened controls show the persisted values, not the defaults
    customising = open_face_settings(pg)
    assert face_row(pg, "Idle personality").locator("select").input_value() == "playful"
    assert face_row(pg, "Expression strength").locator("input").input_value() == "0"

    # emotionIntensity=0: sad settles to the neutral path (no deviation).
    # The eased floats are compared by eye height (tolerance) rather than exact
    # path strings — two settle trajectories land within ~1e-4 of the same
    # target, which exact 2dp string comparison can't distinguish reliably.
    set_version(pg, 2)                 # fvEyeL is only painted while v2 renders
    clear_lock(pg)
    d_sad_full = settled_eye_d(pg, "sad")
    set_face_cfg(pg, 2, emotionIntensity=0)
    d_sad_zero = settled_eye_d(pg, "sad")
    d_calm_zero = settled_eye_d(pg, "calm")
    h_sad, h_calm, h_full = d_height(d_sad_zero), d_height(d_calm_zero), d_height(d_sad_full)
    assert abs(h_sad - h_calm) < 0.5, (
        f"at emotionIntensity=0 sad must settle to the neutral path: sad h={h_sad:.3f}, calm h={h_calm:.3f}"
    )
    assert abs(h_full - h_sad) > 2, (
        f"sanity: sad at full strength should deviate from the intensity-0 path: {h_full:.2f} vs {h_sad:.2f}"
    )
    set_face_cfg(pg, 2, emotionIntensity=100)   # restore (in-memory only)

    # Reset this face → defaults restored (100 / warm / true / 6)
    set_version(pg, 1)
    customising.select_option("1")
    pg.locator("#faceBody button", has_text="Reset this face").click()
    v1 = pg.evaluate(
        "() => { const v = window.__faceTest.config.face.v1;"
        " return {i: v.emotionIntensity, p: v.personality, m: v.microExpressions, h: v.holdSeconds}; }"
    )
    assert v1 == {"i": 100, "p": "warm", "m": True, "h": 6}, (
        f"Reset this face did not restore emotion-tuning defaults: {v1}"
    )
    assert face_row(pg, "Idle personality").locator("select").input_value() == "warm"
    assert face_row(pg, "Expression strength").locator("input").input_value() == "100"

    pg.click("#closePanel")            # leave the shared page tidy for later tests


# --------------------------------------------------------------------------
# AutoMood pools + micro-expressions
# --------------------------------------------------------------------------
def test_auto_pool_never_negative(page):
    """Static: idle pools and the micro channel carry only safe, real names."""
    pg, _ = page
    report = pg.evaluate(
        """() => {
          const moods = new Set(Object.keys(EMOTIONS));
          const neg = [...NEGATIVE];
          const union = new Set(Object.values(AUTO_POOLS).flat());
          return {
            pools: Object.keys(AUTO_POOLS),
            empty: Object.keys(AUTO_POOLS).filter(k => !AUTO_POOLS[k].length),
            bad: Object.entries(AUTO_POOLS).flatMap(([k, v]) =>
                   v.filter(m => neg.includes(m) || !moods.has(m)).map(m => k + ':' + m)),
            micro: MICRO_POOL.filter(m => neg.includes(m) || !moods.has(m) || !union.has(m)),
          };
        }"""
    )
    assert report["pools"] == ["calm", "warm", "playful"]
    assert report["empty"] == [], f"an AutoMood pool is empty: {report['empty']}"
    assert report["bad"] == [], f"NEGATIVE/unknown names leaked into AUTO_POOLS: {report['bad']}"
    assert report["micro"] == [], f"MICRO_POOL has unsafe or pool-less names: {report['micro']}"


def test_micro_expressions_gate(page):
    """Behavior: auto ticks on personality calm + micro on stay inside
    AUTO_POOLS.calm ∪ MICRO_POOL — NEGATIVE never fires, ≥1 call recorded."""
    pg, _ = page
    set_version(pg, 2)
    pg.evaluate("() => window.dispatchEvent(new Event('pointerdown'))")   # wake + stay idle
    clear_lock(pg)
    set_face_cfg(pg, 2, expressions=True, expressionDelay=2,
                 personality="calm", microExpressions=True)
    # every setMood funnels through window.FaceV3.setMood (the kiosk's setMood
    # calls it unconditionally) — the only interception point that sees
    # IIFE-internal auto calls, since window.__faceTest.setMood is a mirror
    # reference, not a proxy
    pg.evaluate(
        """() => {
          window.__moodCalls = [];
          window.__faceV3SetMood = window.FaceV3.setMood;
          window.FaceV3.setMood = m => { window.__moodCalls.push(m); return window.__faceV3SetMood(m); };
        }"""
    )
    try:
        pg.wait_for_function("() => window.__moodCalls.length >= 3", timeout=12000)
    finally:
        pg.evaluate("() => { window.FaceV3.setMood = window.__faceV3SetMood; }")
        set_face_cfg(pg, 2, expressions=True, expressionDelay=8.7,
                     personality="warm", microExpressions=True)
    calls = pg.evaluate("() => window.__moodCalls")
    allowed = set(pg.evaluate("() => AUTO_POOLS.calm")) | set(pg.evaluate("() => MICRO_POOL"))
    banned = set(pg.evaluate("() => [...NEGATIVE]"))
    assert calls, "no auto mood calls were recorded in 12 s of idle"
    assert not (set(calls) & banned), f"NEGATIVE moods were auto-expressed: {set(calls) & banned}"
    assert set(calls) <= allowed, f"auto calls escaped the calm pool: {set(calls) - allowed}"


def test_intensity_zero_speaking_stays_neutral(page):
    """Spec §7.6 escape hatch: emotionIntensity=0 holds a neutral face at all
    times — including the speaking mouth beat and the ±2.5% eye pulse (the
    sleep pose is exempt; it ignores intensity by design)."""
    pg, _ = page
    set_version(pg, 2)
    pg.evaluate("() => window.dispatchEvent(new Event('pointerdown'))")   # wake
    clear_lock(pg)
    set_face_cfg(pg, 2, emotionIntensity=0, speakingPulse=True)
    pg.evaluate("() => window.__faceTest.setMode('speaking', 'SPEAKING')")
    pg.wait_for_timeout(1200)                    # let the eased values settle
    # 1) targetPose at I=0 stays exactly neutral across beat/pulse phases
    poses = pg.evaluate(
        """() => {
          const out = [];
          for (const t of [0, 41, 82, 123, 149, 230, 372, 500, 740, 1000]) {
            const p = targetPose(t, 'content');
            out.push({c: p.mouth.c, o: p.mouth.o, l: p.L.open, r: p.R.open});
          }
          return out;
        }"""
    )
    for p in poses:
        assert abs(p["o"]) < 0.02, f"I=0 speaking mouth must not beat: {p}"
        assert abs(p["c"]) < 0.02, f"I=0 speaking mouth must not curve: {p}"
        assert abs(p["l"] - 1) < 0.005 and abs(p["r"] - 1) < 0.005, (
            f"I=0 speaking eyes must not pulse: {p}"
        )
    # 2) and the rendered mouth is static in the DOM too
    seen = set()
    for _ in range(12):                          # 12 x 125 ms ≈ 1.5 s
        seen.add(pg.evaluate("() => document.getElementById('fvMouth').getAttribute('d')"))
        pg.wait_for_timeout(125)
    assert len(seen) <= 3, f"I=0 speaking mouth still moves in the DOM ({len(seen)} distinct paths)"
    pg.evaluate("() => window.__faceTest.setMode('idle', 'IDLE')")
    set_face_cfg(pg, 2, emotionIntensity=100)    # restore (in-memory only)


# --------------------------------------------------------------------------
def test_no_unexpected_console_errors(page):
    _, errors = page
    assert errors == [], f"unexpected console/page errors: {errors}"


def test_hands_follow_mood_tint(page):
    """tintMode 'mood': the hands must repaint with the eased --eye colour on
    every mood change (regression: they used to read a stale --eye and lag one
    mood behind, since only the rAF loop writes the variable now)."""
    pg, _ = page
    # the startup greet (setTimeout @ load+1.7 s) expresses 'happy' for 4.4 s
    # and resets the face at ~load+6.1 s — wait it out so it can't override the
    # mood mid-poll (a no-op in the full suite, where the page is minutes old)
    pg.wait_for_function("() => performance.now() > 8000", timeout=20000)
    # v1 only: on v2 colorMode 'auto' pins the eye to Koko cyan (eyeColorFor),
    # so the mood-colour half of this assertion needs the v1 pipeline
    set_version(pg, 1)
    pg.evaluate("() => { window.__faceTest.config.hands.tintMode = 'mood'; window.Hands.paint(); }")

    def settled(mood, rgb):
        # rgbStr truncates (|0) and the eased value approaches asymptotically,
        # so a channel can settle 1 below its target — allow ±1, never a
        # whole-mood delta (the stale-tint bug was hundreds off)
        pg.evaluate("m => window.__faceTest.express(m, 5000)", mood)   # moodLock keeps AutoMood out
        pg.wait_for_function(
            """want => {
                const hand = getComputedStyle(document.getElementById('hands')).getPropertyValue('--hand-core').trim();
                const eye = getComputedStyle(document.documentElement).getPropertyValue('--eye').trim();
                const got = (eye.match(/\\d+/g) || []).map(Number);
                return hand === eye && got.length === 3 &&
                       got.every((v, i) => Math.abs(v - want[i]) <= 1);
            }""",
            arg=rgb,
            timeout=5000,
        )

    try:
        settled("love", [255, 130, 164])
        settled("happy", [255, 224, 122])
    finally:
        pg.evaluate(
            "() => { window.__faceTest.config.hands.tintMode = 'cool';"
            " window.__faceTest.express('content', 0); window.Hands.paint(); }"
        )
