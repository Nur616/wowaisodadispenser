"""Unit tests for serial reply correlation (no Arduino required)."""

import queue
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from pump_link import BusyGate, classify, is_unsolicited, read_matching


def test_unsolicited_lines_are_ignored():
    q = queue.Queue()
    q.put("PONG ESTOP=0")
    q.put("EVENT HOST_CONNECTED")
    q.put("DONE 3")
    q.put("OK")
    assert read_matching(q, timeout=0.5) == "OK"


def test_late_display_reply_cannot_become_a_pump_reply():
    """The old failure: a PONG/ERR for the display arrived first."""
    q = queue.Queue()
    q.put("PONG ESTOP=0")
    q.put("ERR unknown_command")
    q.put("OK")
    # A pump command only accepts OK/ERR; PONG is skipped either way.
    assert read_matching(q, timeout=0.5) == "ERR unknown_command"


def test_only_unsolicited_traffic_means_timeout():
    q = queue.Queue()
    q.put("PONG ESTOP=0")
    q.put("EVENT ESTOP_RESET")
    assert read_matching(q, timeout=0.15) == ""


def test_accept_filter_keeps_waiting_for_its_own_id():
    q = queue.Queue()
    q.put("OK 41")
    q.put("OK 42")

    def accept(line):
        return line.endswith(" 42")

    assert read_matching(q, timeout=0.5, accept=accept) == "OK 42"


def test_accept_can_explicitly_wait_for_pong():
    q = queue.Queue()
    q.put("OK")
    q.put("PONG ESTOP=0")
    assert read_matching(q, timeout=0.5, accept=lambda line: line.startswith("PONG")) == "PONG ESTOP=0"


def test_accept_filter_times_out_when_its_reply_never_comes():
    q = queue.Queue()
    q.put("OK 41")
    assert read_matching(q, timeout=0.1, accept=lambda line: line.endswith(" 99")) == ""


def test_classify_ok_and_errors():
    assert classify("OK")["ok"] is True
    assert classify("OK 7")["ok"] is True
    assert classify("")["code"] == "no_reply"
    assert classify("ERR bad_pump")["code"] == "controller_error"
    assert classify("ERR bad_pump")["ok"] is False
    assert classify("something else")["code"] == "unexpected_reply"


def test_classify_never_marks_an_error_as_started():
    for reply in ("", "ERR bad_format", "ERR unknown_command", "garbage"):
        result = classify(reply)
        assert result["started"] is False
        assert result["ok"] is False


def test_legacy_event_reply_is_treated_as_an_ack():
    """Older boards ack a command with telemetry like "@EVT 949 E17" instead
    of "OK"; the pump physically ran, so it must not read as a failure."""
    q = queue.Queue()
    q.put("@EVT 949 E17")
    assert read_matching(q, timeout=0.5) == "@EVT 949 E17"
    result = classify("@EVT 949 E17")
    assert result["ok"] is True
    assert result["started"] is True
    assert result["code"] == "ok_legacy_event"


def test_real_ok_reply_still_wins_over_legacy_events():
    """A board that answers OK is trusted even if a legacy event line arrives first."""
    q = queue.Queue()
    q.put("@EVT 949 E17")
    q.put("OK")
    assert read_matching(q, timeout=0.5) == "@EVT 949 E17"
    assert classify("OK")["ok"] is True


def test_is_unsolicited_empty_and_telemetry():
    assert is_unsolicited("") is True
    assert is_unsolicited("PONG ESTOP=1") is True
    assert is_unsolicited("OK") is False
    assert is_unsolicited("ERR bad_pump") is False


def test_busy_gate_nests_and_releases():
    gate = BusyGate()
    assert gate.busy() is False
    gate.enter()
    gate.enter()
    assert gate.busy() is True
    gate.leave()
    assert gate.busy() is True
    gate.leave()
    assert gate.busy() is False


def test_busy_gate_context_manager_balances_on_exception():
    gate = BusyGate()
    try:
        with gate:
            raise RuntimeError("boom")
    except RuntimeError:
        pass
    assert gate.busy() is False


def test_busy_gate_is_visible_from_another_thread():
    gate = BusyGate()
    seen = []

    def reader():
        seen.append(gate.busy())

    gate.enter()
    t = threading.Thread(target=reader)
    t.start()
    t.join()
    gate.leave()
    assert seen == [True]
