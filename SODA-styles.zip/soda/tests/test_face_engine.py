"""Parametric emotion engine core (inert block) — loaded live via Playwright.

The engine sits in kiosk.html just before `const moods`, inside the page's one
big IIFE; it mirrors its public surface onto window, so these tests can exercise
its pure functions via page.evaluate. The page drives v1/v2 through it
(animateFace eases eyeLive toward targetPose and renderV1/renderV2 paint it
every frame), and must load clean (zero unexpected console errors) with it
present.

Known-and-ignored console errors, all artifacts of loading the kiosk straight
off disk (file://) that exist with or without the engine block:
  * ``/omni/*.css|js`` — the four external scripts/styles the backend serves;
  * ``Fetch API cannot load file:///hardware`` / ``file:///jarvis/status`` —
    fetch() rejects file: URLs inside Blink before any request is made, so
    these cannot even be intercepted with page.route.
The ``/kiosk/storage`` GET probe IS interceptable and is routed to a stub; its
keepalive POST fallback is not — see the filter below.
"""

import re
from pathlib import Path

import pytest
from playwright.sync_api import sync_playwright

KIOSK = Path(__file__).resolve().parents[1] / "kiosk.html"
URL = KIOSK.resolve().as_uri()  # file:///.../kiosk.html

# --disable-gpu etc: on GPU-less/dbus-less boxes (CI containers, ARM SBCs) the
# Chromium GPU process crashes repeatedly and takes the whole browser down with
# "GPU process isn't usable. Goodbye."; software compositing keeps it alive.
LAUNCH_ARGS = ["--disable-gpu", "--disable-gpu-compositing", "--use-gl=swiftshader"]

IGNORED_CONSOLE_ERRORS = re.compile(
    r"/omni/"                                   # backend-served scripts/styles: absent under file://
    r"|Fetch API cannot load file:///hardware"                    # file:// artifact, pre-existing
    r"|Fetch API cannot load file:///jarvis/status"               # file:// artifact, pre-existing
    # the portable-settings probe XHRs /kiosk/storage fine (routed to a stub),
    # but its keepalive POST fetch to a file:// URL fails at the scheme level a
    # few seconds after load and Blink logs it before any promise .catch can
    # see it — unsuppressible file:// artifact, same class as the two above
    r"|Fetch API cannot load file:///kiosk/storage"
)


@pytest.fixture(scope="module")
def page():
    errors = []
    with sync_playwright() as pw:
        browser = pw.chromium.launch(args=LAUNCH_ARGS)
        pg = browser.new_page()

        def capture(msg):
            if msg.type != "error":
                return
            text = (f"{msg.text} ({msg.location.get('url', '')})")
            if not IGNORED_CONSOLE_ERRORS.search(text):
                errors.append(f"console.error: {text}")

        pg.on("pageerror", lambda err: errors.append(f"pageerror: {err}"))
        pg.on("console", capture)
        # the page's portable-settings probe XHRs /kiosk/storage synchronously;
        # under file:// that is a CORS error, so stub a valid empty response
        pg.route("**/kiosk/storage*",
                 lambda route: route.fulfill(status=200, content_type="application/json", body="{}"))
        pg.goto(URL)
        pg.wait_for_load_state("load")
        yield pg, errors
        browser.close()


def test_emotions_matches_moods(page):
    pg, _ = page
    # `moods` stays IIFE-scoped (exposing it would mean touching existing code),
    # so its names are parsed from source — same approach as test_mood_lists.py
    match = re.search(r"const moods = \{(.*?)\n  \};", KIOSK.read_text(encoding="utf-8"), re.S)
    assert match, "kiosk.html: `const moods = {` block not found"
    moods_names = set(re.findall(r"^\s*(\w+):", match.group(1), re.M))
    result = pg.evaluate("""() => {
        const e = Object.keys(EMOTIONS);
        return {len: e.length, names: e};
    }""")
    emotions_names = set(result["names"])
    assert result["len"] == 22, f"EMOTIONS has {result['len']} entries, expected 22"
    assert emotions_names == moods_names, (
        f"EMOTIONS vs moods mismatch: {sorted(emotions_names ^ moods_names)}"
    )


def test_resolve_mood(page):
    pg, _ = page
    assert pg.evaluate(
        "() => resolveMood('shocked') === 'surprised' && "
        "resolveMood('happy') === 'happy' && resolveMood('nope') === 'nope'"
    )


def test_pose_of_intensity_gate(page):
    pg, _ = page
    assert pg.evaluate(
        "() => poseOf('happy', 1).mouth.c === 0.9 && poseOf('happy', 0).mouth.c === 0"
    )


def test_pose_of_per_side_overrides(page):
    pg, _ = page
    assert pg.evaluate("() => poseOf('confused', 1).L.slope !== poseOf('confused', 1).R.slope")


def test_eye_outline_point_count(page):
    pg, _ = page
    assert pg.evaluate(
        "() => eyeOutline(39, 32, 12.5, 15, poseOf('calm', 1).L, 1, 0, 0, []).length === 96"
    )


def test_mouth_shape_fill_flags(page):
    pg, _ = page
    assert pg.evaluate(
        "() => mouthShape({c: .9, o: 0}, LAYOUT_V1).fill === false && "
        "mouthShape({c: 0, o: .9}, LAYOUT_V1).fill === true"
    )


def test_ease_live_kscale_scales_morph_rate(page):
    """kScale is the motionSpeed/naturalness handle: 0 freezes the morph, >1 converges faster."""
    pg, _ = page
    result = pg.evaluate("""() => {
        const target = poseOf('happy', 1);
        const save = JSON.parse(JSON.stringify(eyeLive));
        const reset = () => { eyeLive.L.open = 0; eyeLive.mouth.c = 0; eyeLive.rgb = [0, 0, 0]; };
        // one synchronous task, so the rAF loop can't interleave between samples
        reset();
        easeLive(target, 0.016, 0);                       // k = 1 - exp(0) = 0
        const frozen = eyeLive.L.open === 0 && eyeLive.mouth.c === 0 && eyeLive.rgb[0] === 0;
        reset();
        easeLive(target, 0.016, 4);                       // faster convergence
        const fast = eyeLive.L.open;
        reset();
        easeLive(target, 0.016, 1);                       // default rate
        const slow = eyeLive.L.open;
        // restore the live values the render loop was easing
        Object.assign(eyeLive.L, save.L); Object.assign(eyeLive.R, save.R);
        Object.assign(eyeLive.mouth, save.mouth); eyeLive.rgb = save.rgb;
        return {frozen, fast, slow};
    }""")
    assert result["frozen"], f"kScale=0 must leave the eased values unchanged: {result}"
    assert result["slow"] > 0 and result["fast"] > result["slow"], (
        f"kScale=4 must converge faster than the default kScale=1: {result}"
    )


def test_no_unexpected_console_errors(page):
    _, errors = page
    assert errors == [], f"unexpected console/page errors: {errors}"
