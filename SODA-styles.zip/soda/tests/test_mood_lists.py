"""All six mood-name lists must match the CANONICAL 22-name set, plus the prose
lists in mind.py's ABOUT["face"] and the README §7.1 region (source-parsing, no imports)."""

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]

CANONICAL = ("content", "calm", "happy", "glee", "love", "curious", "focused", "skeptical",
             "annoyed", "bored", "sad", "worried", "surprised", "scared", "exhausted", "sleepy",
             "angry", "excited", "proud", "confused", "laugh", "wink")


def _read(name):
    return (ROOT / name).read_text(encoding="utf-8")


def test_kiosk_moods():
    match = re.search(r"const moods = \{(.*?)\n  \};", _read("kiosk.html"), re.S)
    assert match, "kiosk.html: `const moods = {` block not found"
    found = re.findall(r"^\s*(\w+):", match.group(1), re.M)
    assert set(found) == set(CANONICAL), f"kiosk moods mismatch: {sorted(set(found) ^ set(CANONICAL))}"


def test_kiosk_fv3_map():
    match = re.search(r"const FV3_MAP = \{(.*?)\};", _read("kiosk.html"), re.S)
    assert match, "kiosk.html: `const FV3_MAP = {` block not found"
    found = re.findall(r"(\w+):", match.group(1))
    assert set(found) == set(CANONICAL), f"FV3_MAP mismatch: {sorted(set(found) ^ set(CANONICAL))}"


def test_agent_face_moods():
    match = re.search(r"FACE_MOODS = \((.*?)\)", _read("agent.py"), re.S)
    assert match, "agent.py: FACE_MOODS tuple not found"
    found = re.findall(r'"([a-z]+)"', match.group(1))
    assert set(found) == set(CANONICAL), f"FACE_MOODS mismatch: {sorted(set(found) ^ set(CANONICAL))}"


def test_mind_enum():
    match = re.search(r'"mood": \{"type": "string", "enum": \[([^\]]+)\]', _read("mind.py"), re.S)
    assert match, "mind.py: set_expression mood enum not found"
    found = re.findall(r'"([a-z]+)"', match.group(1))
    assert set(found) == set(CANONICAL), f"mind enum mismatch: {sorted(set(found) ^ set(CANONICAL))}"


def test_motion_moods():
    match = re.search(r"_MOODS = \{(.*?)\}", _read("motion_bridge.py"), re.S)
    assert match, "motion_bridge.py: _MOODS set not found"
    found = re.findall(r'"([a-z]+)"', match.group(1))
    assert set(found) == set(CANONICAL), f"_MOODS mismatch: {sorted(set(found) ^ set(CANONICAL))}"


def test_mind_about_face():
    match = re.search(r'"face": "([^"]+)"', _read("mind.py"))
    assert match, 'mind.py: ABOUT["face"] string not found'
    value = match.group(1)
    missing = [name for name in CANONICAL if not re.search(rf"\b{name}\b", value)]
    assert not missing, f'ABOUT["face"] missing mood names: {missing}'


def test_readme_mood_list():
    # scope to the §7.1 mood-list region so a name mentioned anywhere else in
    # the README can't false-pass
    readme = _read("README.md")
    region = re.search(r"^### 7\.1 .*?^### ", readme, re.S | re.M)
    assert region, "README.md: §7.1 section not found"
    missing = [name for name in CANONICAL if f"`{name}`" not in region.group(0)]
    assert not missing, f"README §7.1 missing backticked mood names: {missing}"
