"""Music intelligence: turn a spoken/typed request into the RIGHT song, with official artwork.

  resolve("play doubt it by chase atlantic")  ->  {title, artist, album, cover, duration, confidence,
                                                    alternatives: [...], similar: [...]}
  cover_art(title, artist)                    ->  {url, source}      (official album cover, not a video frame)
  clean_title / split_artist_title            ->  tidy "Artist - Topic" / "(Official Video)" noise

Sources (no API keys): the iTunes Search API and the Deezer API. Both are queried with the same guarded
HTTP fetcher the browser tools use. Every network call is optional: when offline the helpers return None and
callers fall back to YouTube's own thumbnail.
"""
import difflib, json, re, time, urllib.parse

_NOISE = re.compile(
    r"\s*[\(\[]\s*(official|lyrics?|audio|video|music video|visuali[sz]er|hd|hq|4k|mv|explicit|clean|remaster(?:ed)?|"
    r"live|performance|full song|with lyrics)[^\)\]]*[\)\]]", re.I)
_FEAT = re.compile(r"\s*[\(\[]?\s*(?:feat\.?|ft\.?|featuring)\s+[^\)\]]*[\)\]]?", re.I)
_CACHE = {}
BN = re.compile(r"[\u0980-\u09FF]")


def has_bangla(text):
    return bool(BN.search(text or ""))


def clean_channel(name):
    name = re.sub(r"\s*-\s*Topic\s*$", "", name or "", flags=re.I)
    name = re.sub(r"\s*(VEVO|Official|Music)\s*$", "", name, flags=re.I)
    return name.strip()


def clean_title(title):
    t = _NOISE.sub("", title or "")
    t = _NOISE.sub("", t)
    return re.sub(r"\s+", " ", t).strip(" -|·")


def split_artist_title(video_title, channel=""):
    """'Chase Atlantic - Doubt It (Official Audio)' on channel 'Chase Atlantic - Topic' -> ('Chase Atlantic', 'Doubt It')."""
    artist = clean_channel(channel)
    title = clean_title(video_title)
    for sep in (" - ", " – ", " — ", " | ", " : "):
        if sep in title:
            left, right = [p.strip() for p in title.split(sep, 1)]
            if artist and artist.lower() in right.lower() and artist.lower() not in left.lower():
                return artist, left
            return (left if not artist or artist.lower() in left.lower() or len(artist) > 40 else artist), right
    title = _FEAT.sub("", title).strip()
    return artist, title


def _norm(text):
    return re.sub(r"[^\w\u0980-\u09FF ]+", " ", str(text or "").lower()).split()


def _phonetic(text):
    """Cheap sound-alike key so 'doubt it' / 'into it' / 'dowt it' land near each other."""
    s = "".join(_norm(text))
    for a, b in (("ph", "f"), ("ck", "k"), ("ght", "t"), ("gh", ""), ("kn", "n"), ("wr", "r"), ("qu", "kw"), ("x", "ks"),
                 ("c", "k"), ("z", "s"), ("w", "v"), ("th", "t"), ("oub", "ub"), ("ou", "u"), ("oo", "u")):
        s = s.replace(a, b)
    s = re.sub(r"(.)\1+", r"\1", s)
    return s[:1] + re.sub(r"[aeiouy]", "", s[1:])


def similarity(a, b):
    ta, tb = _norm(a), _norm(b)
    if not ta or not tb:
        return 0.0
    raw = difflib.SequenceMatcher(None, " ".join(ta), " ".join(tb)).ratio()
    pho = difflib.SequenceMatcher(None, _phonetic(a), _phonetic(b)).ratio()
    return max(raw, 0.9 * pho)


def parse_request(query):
    """'play doubt it by chase atlantic' -> ('doubt it', 'chase atlantic'); 'artist - title' also works."""
    q = re.sub(r"^(?:please\s+)?(?:play|put on|queue|start|listen to|i want to hear|can you play)\s+", "", str(query or "").strip(), flags=re.I)
    q = re.sub(r"\s+(?:on youtube|please|pls)$", "", q, flags=re.I).strip()
    m = re.match(r"^(.*?)\s+by\s+(.+)$", q, re.I)
    if m:
        return m.group(1).strip(), m.group(2).strip()
    for sep in (" - ", " – "):
        if sep in q:
            a, t = q.split(sep, 1)
            return t.strip(), a.strip()
    return q, ""


# ------------------------------------------------------------------ providers
def _get_json(url, fetch):
    key = ("g", url)
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 6 * 3600:
        return hit[1]
    _, ctype, raw = fetch(url, max_bytes=600_000, headers={"Accept": "application/json"})
    data = json.loads(raw.decode("utf-8", "replace"))
    _CACHE[key] = (time.time(), data)
    return data


def _upscale_itunes(url):
    return re.sub(r"/\d+x\d+(bb)?\.(jpg|png)$", r"/1000x1000bb.\2", url or "")


def itunes_search(term, fetch, limit=15, country="US"):
    url = "https://itunes.apple.com/search?" + urllib.parse.urlencode(
        {"term": term, "entity": "song", "limit": limit, "country": country})
    out = []
    for r in _get_json(url, fetch).get("results", []):
        if not r.get("trackName"):
            continue
        out.append({"title": r.get("trackName"), "artist": r.get("artistName"), "album": r.get("collectionName"),
                    "cover": _upscale_itunes(r.get("artworkUrl100")), "duration": round((r.get("trackTimeMillis") or 0) / 1000),
                    "source": "itunes"})
    return out


def deezer_search(term, fetch, limit=15):
    url = "https://api.deezer.com/search?" + urllib.parse.urlencode({"q": term, "limit": limit})
    out = []
    for r in _get_json(url, fetch).get("data", []):
        album = r.get("album") or {}
        out.append({"title": r.get("title"), "artist": (r.get("artist") or {}).get("name"), "album": album.get("title"),
                    "cover": album.get("cover_xl") or album.get("cover_big") or album.get("cover_medium"),
                    "duration": r.get("duration") or 0, "source": "deezer"})
    return out


def _score(c, title, artist):
    s = similarity(c["title"], title) if title else 0.5
    if artist:
        s = 0.62 * s + 0.38 * similarity(c["artist"], artist)
    return s


def search_candidates(title, artist, fetch):
    term = (artist + " " + title).strip() if artist else title
    cands, errors = [], 0
    for fn in (itunes_search, deezer_search):
        try:
            cands += fn(term, fetch)
        except Exception:
            errors += 1
        if cands and fn is itunes_search and len(cands) >= 5:
            pass
    if errors == 2:
        return None
    return cands


def resolve(query, fetch):
    """Best canonical match plus alternatives and sound-alike titles by the same artist. None when offline."""
    title, artist = parse_request(query)
    if not title:
        return None
    key = ("r", title.lower(), artist.lower())
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 6 * 3600:
        return hit[1]
    cands = search_candidates(title, artist, fetch)
    if not cands:
        return None
    ranked = sorted(cands, key=lambda c: -_score(c, title, artist))
    best = ranked[0]
    conf = round(_score(best, title, artist), 3)
    seen, alternatives = {(best["title"].lower(), (best["artist"] or "").lower())}, []
    for c in ranked[1:]:
        k = (c["title"].lower(), (c["artist"] or "").lower())
        if k in seen or _score(c, title, artist) < 0.45:
            continue
        seen.add(k)
        alternatives.append({"title": c["title"], "artist": c["artist"]})
        if len(alternatives) >= 3:
            break
    # titles by the SAME artist that sound like what was asked (speech recognition often swaps them)
    similar = []
    pool = [c for c in cands if similarity(c["artist"], best["artist"]) > 0.85]
    try:
        pool += itunes_search(best["artist"], fetch, 40) if best.get("artist") else []
    except Exception:
        pass
    for c in pool:
        if similarity(c["artist"], best["artist"]) < 0.85 or similarity(c["title"], best["title"]) > 0.97:
            continue
        sim = similarity(c["title"], title)
        if 0.5 <= sim and c["title"].lower() != best["title"].lower() and not any(s["title"].lower() == c["title"].lower() for s in similar):
            similar.append({"title": c["title"], "artist": c["artist"], "similarity": round(sim, 2)})
    similar.sort(key=lambda s: -s["similarity"])
    result = dict(best, confidence=conf, alternatives=alternatives, similar=similar[:3], asked=title)
    _CACHE[key] = (time.time(), result)
    return result


def cover_art(title, artist, fetch):
    """Official album cover for a track: iTunes first, then Deezer. {url, source, album} or None."""
    key = ("c", title.lower(), artist.lower())
    hit = _CACHE.get(key)
    if hit and time.time() - hit[0] < 24 * 3600:
        return hit[1]
    res = None
    for fn in (itunes_search, deezer_search):
        try:
            cands = fn((artist + " " + title).strip(), fetch, 8)
        except Exception:
            continue
        cands = [c for c in cands if c.get("cover") and similarity(c["title"], title) >= 0.6
                 and (not artist or similarity(c["artist"], artist) >= 0.5)]
        if cands:
            best = max(cands, key=lambda c: similarity(c["title"], title) + 0.5 * similarity(c["artist"], artist or c["artist"]))
            res = {"url": best["cover"], "source": best["source"], "album": best.get("album") or ""}
            break
    _CACHE[key] = (time.time(), res)
    return res


def youtube_thumbnail(video_id, topic_channel=False):
    """Fallback when no official art is found. 'Topic' uploads use the real album cover as the video image."""
    return "https://i.ytimg.com/vi/%s/%s.jpg" % (video_id, "maxresdefault" if topic_channel else "hqdefault")
