@echo off
REM Windows launcher (laptop/PC).   start.bat help   lists every command and option.
setlocal EnableExtensions EnableDelayedExpansion
cd /d "%~dp0"
if not exist logs mkdir logs

REM ---------- arguments ----------
set "FORCE="
set "ASK=1"
set "BROWSER_ARG="
set "MODE="
set "EXTRAS_ARG="
set "NO_EXTRAS=0"
set "ASK_EXTRAS=0"
set "LIST_EXTRAS=0"
:parse
if "%~1"=="" goto parsed
if /i "%~1"=="help" goto help
if /i "%~1"=="-h" goto help
if /i "%~1"=="--help" goto help
if /i "%~1"=="/?" goto help
if /i "%~1"=="--reinstall" ( set "FORCE=--force" & shift & goto parse )
if /i "%~1"=="--ask" ( set "ASK=2" & shift & goto parse )
if /i "%~1"=="--no-ask" ( set "ASK=0" & shift & goto parse )
if /i "%~1"=="--browser" ( set "BROWSER_ARG=%~2" & shift & shift & goto parse )
if /i "%~1"=="--extras" ( set "EXTRAS_ARG=%~2" & shift & shift & goto parse )
if /i "%~1"=="--no-extras" ( set "NO_EXTRAS=1" & shift & goto parse )
if /i "%~1"=="--ask-extras" ( set "ASK_EXTRAS=1" & shift & goto parse )
if /i "%~1"=="--list-extras" ( set "LIST_EXTRAS=1" & shift & goto parse )
set "A=%~1"
if "!A:~0,2!"=="--" ( echo Unknown option: %~1   ^(try: start.bat help^) & exit /b 1 )
set "MODE=%~1"
shift
goto parse
:parsed
if "%MODE%"=="" set "MODE=auto"
if "%PUMP_PORT%"=="" set "PUMP_PORT=5005"

REM ---------- find a working Python 3 ----------
set "PY0="
py -3 -c "import sys" >nul 2>nul && set "PY0=py -3"
if not defined PY0 (
  python -c "import sys" >nul 2>nul && set "PY0=python"
)
if not defined PY0 (
  echo Python 3 was not found. Trying to install it with winget...
  where winget >nul 2>nul
  if errorlevel 1 (
    echo winget is not available. Install Python 3 from https://www.python.org/downloads/ ^(tick "Add python.exe to PATH"^) and run start.bat again.
    pause
    exit /b 1
  )
  winget install -e --id Python.Python.3.12 --accept-package-agreements --accept-source-agreements
  echo.
  echo Python was installed. Close this window and run start.bat again so Windows picks it up.
  pause
  exit /b 0
)

REM ---------- is this the first run on this computer? ----------
set "FIRST_RUN=1"
if exist ".venv-win\.deps_stamp" set "FIRST_RUN=0"

if "%LIST_EXTRAS%"=="1" (
  %PY0% deps.py --list-extras
  exit /b 0
)

REM ---------- which browser for ChatGPT + the AI browser? ----------
set "SAVED="
if exist ".coda_browser" set /p SAVED=<".coda_browser"
set "CHOICE="
if defined BROWSER_ARG goto :by_arg
if defined CODA_BROWSER if not "%ASK%"=="2" goto :by_env
if "%ASK%"=="0" goto :by_saved
if "%FIRST_RUN%"=="0" goto :by_saved
goto :by_prompt

:by_arg
call :normalize "%BROWSER_ARG%"
if "!NORM!"=="" ( echo Unknown browser "%BROWSER_ARG%" - use default, chrome or firefox. & exit /b 1 )
set "CHOICE=!NORM!"
goto :browser_done

:by_env
call :normalize "%CODA_BROWSER%"
set "CHOICE=!NORM!"
goto :browser_done

:by_saved
call :normalize "!SAVED!"
set "CHOICE=!NORM!"
goto :browser_done

:by_prompt
set "INFO="
for /f "usebackq delims=" %%i in (`%PY0% coda_browser.py --detect 2^>nul`) do set "INFO=%%i"
call :normalize "!SAVED!"
set "DEFNUM=1"
if "!NORM!"=="chrome" set "DEFNUM=2"
if "!NORM!"=="firefox" set "DEFNUM=3"
echo.
echo Which browser should ChatGPT and the AI browser use?
echo   1^) System default browser
echo   2^) Google Chrome / Chromium / Edge
echo   3^) Mozilla Firefox
echo   Detected: !INFO!
set "ANS="
set /p ANS=Choose 1-3 [Enter = !DEFNUM!]: 
if "!ANS!"=="" set "ANS=!DEFNUM!"
call :normalize "!ANS!"
set "CHOICE=!NORM!"

:browser_done
if "!CHOICE!"=="" set "CHOICE=auto"
set "CODA_BROWSER=!CHOICE!"
>".coda_browser" echo !CHOICE!
echo Browser for ChatGPT / AI browser: !CHOICE! ^(auto = system default^)

REM ---------- virtualenv (created once, then auto-activated) ----------
if exist ".venv-win\Scripts\python.exe" (
  ".venv-win\Scripts\python.exe" -c "import sys" >nul 2>nul
  if errorlevel 1 (
    echo The virtualenv is broken - recreating it.
    rmdir /s /q ".venv-win"
  )
)
if not exist ".venv-win\Scripts\python.exe" (
  echo Creating virtualenv in .venv-win ^(first run on this computer^) ...
  %PY0% -m venv ".venv-win"
  if errorlevel 1 (
    echo Could not create a virtualenv. Reinstall Python from python.org with the "venv" option enabled, and that the drive is writable.
    pause
    exit /b 1
  )
)
call ".venv-win\Scripts\activate.bat"
set "PY=%CD%\.venv-win\Scripts\python.exe"

REM ---------- automatic library checker ----------
echo Checking libraries...
set "DEPS_ARGS=%FORCE%"
if not "%EXTRAS_ARG%"=="" set "DEPS_ARGS=%DEPS_ARGS% --extras %EXTRAS_ARG%"
if "%NO_EXTRAS%"=="1" set "DEPS_ARGS=%DEPS_ARGS% --no-extras"
if "%ASK_EXTRAS%"=="1" set "DEPS_ARGS=%DEPS_ARGS% --ask-extras"
if not "%NO_EXTRAS%"=="1" if "%EXTRAS_ARG%"=="" if "%ASK_EXTRAS%"=="0" if not defined CODA_EXTRAS if not exist ".coda_extras" echo First run on this computer - asking which optional libraries to install ^(Enter = core only^).
"%PY%" deps.py %DEPS_ARGS%
if errorlevel 1 (
  echo.
  echo Library setup failed - see the messages above. Check your internet connection and run start.bat again.
  pause
  exit /b 1
)

if /i "%MODE%"=="setup" (
  echo Setup complete. Start the robot with: start.bat
  pause
  exit /b 0
)

set "PUMP_TRANSPORT=%MODE%"
echo Starting pump backend ^(transport: %MODE%^) ...
echo Opening http://localhost:%PUMP_PORT%/ in a few seconds. Close this window ^(or Ctrl+C^) to stop.
start "" /b cmd /c "timeout /t 4 >nul & start http://localhost:%PUMP_PORT%/"

"%PY%" backend.py
pause
exit /b 0

:normalize
set "NORM="
set "N=%~1"
if /i "!N!"=="1" set "NORM=auto"
if /i "!N!"=="default" set "NORM=auto"
if /i "!N!"=="auto" set "NORM=auto"
if /i "!N!"=="system" set "NORM=auto"
if /i "!N!"=="2" set "NORM=chrome"
if /i "!N!"=="chrome" set "NORM=chrome"
if /i "!N!"=="chromium" set "NORM=chrome"
if /i "!N!"=="edge" set "NORM=chrome"
if /i "!N!"=="3" set "NORM=firefox"
if /i "!N!"=="firefox" set "NORM=firefox"
if /i "!N!"=="ff" set "NORM=firefox"
if "!N!"=="" set "NORM=auto"
exit /b 0

:help
echo CODA start script
echo.
echo USAGE
echo   start.bat [options] [mode]
echo.
echo MODES  ^(what talks to the pumps^)
echo   ^(none^)          Auto-detect the Arduino's COM port
echo   mock            Simulated Arduino, no hardware needed
echo   auto / serial   Real Arduino on a COM port
echo   setup           Create .venv and install the core libraries, then exit
echo.
echo OPTIONS
echo   help, -h, --help  Show this text
echo   --browser NAME    Browser for ChatGPT and the AI browser, without asking:
echo                       default  the system default browser
echo                       chrome   Google Chrome / Chromium / Edge
echo                       firefox  Mozilla Firefox
echo   --ask             Ask which browser even if a choice is saved or CODA_BROWSER is set
echo   --no-ask          Never ask; use --browser / CODA_BROWSER / your last choice
echo   --reinstall       Force a clean reinstall of every library before starting
echo   --extras LIST     Install these optional libraries too, without asking.
echo                     LIST is comma-separated, or "all", or "none":
echo                       browser   Playwright + one browser engine ^(large download^)
echo                       imaging   Screenshot decoding + offline OCR
echo                       jarvis    The Jarvis voice agent's own packages ^(uv sync^)
echo   --no-extras       Install core libraries only; never ask about the optional ones
echo   --ask-extras      Ask the y/n questions again now ^(to change an earlier answer^)
echo   --list-extras     Show the optional libraries for this PC, then exit
echo.
echo OPTIONAL LIBRARIES ^(never downloaded unless you say yes^)
echo   Only the CORE libraries are installed by default ^(flask, flask-cors, pyserial,
echo   pycaw, comtypes^). Everything heavy is an extra: the first run on a PC asks one
echo   y/n question per extra and they all default to No. Answers are remembered in
echo   .coda_extras, so later runs are instant. Change them any time with:
echo       start.bat setup --ask-extras
echo.
echo BROWSER QUESTION
echo   Asked on the first run on a PC, or whenever you pass --ask. Press Enter to keep
echo   your last choice. The answer is saved in .coda_browser and passed on as CODA_BROWSER.
echo.
echo EXAMPLES
echo   start.bat                        start ^(asks on the first run^)
echo   start.bat mock --no-ask          simulated Arduino, no questions
echo   start.bat --browser firefox
echo   start.bat setup                  install core only and exit
echo   start.bat setup --extras browser,imaging
echo   start.bat setup --ask-extras     change which extras are installed
echo.
echo ENVIRONMENT VARIABLES ^(all optional^)
echo   Backend     PUMP_TRANSPORT  PUMP_HOST  PUMP_PORT  PUMP_SERIAL_PORT  FLOW_SENSOR_PORT
echo   AI          GROQ_API_KEY  GROQ_PROXY  OMNIROUTE_BASE_URL  ELEVENLABS_API_KEY  ELEVENLABS_VOICE_ID
echo   Browser     CODA_BROWSER  CHATGPT_BROWSER ^(path^)  CHATGPT_HEADLESS
echo   ChatGPT     CHATGPT_URL  CHATGPT_CAPTURE ^(auto, dom, screenshot^)  CHATGPT_TIMEOUT  CHATGPT_DEBUG_DIR
echo   AI browser  BROWSER_ENGINE  BROWSER_REMOTE  BROWSER_TOKEN  BROWSER_ALLOW_PRIVATE
echo   Setup       SKIP_DEPS_CHECK=1  SKIP_BROWSER_DOWNLOAD=1
echo               CODA_EXTRAS=browser,jarvis  ^(install these extras without asking^)
echo.
echo PORTABLE ^(USB stick^)
echo   Everything lives in this folder: data ^(API keys, settings, ChatGPT login^), .venv-win ^(libraries^), logs.
echo   Copy or carry the whole folder. Python itself must be installed on each computer.
echo.
echo AFTER IT STARTS
echo   Kiosk http://localhost:5005/    Pump test /test    LCD settings /display    Logs: logs folder
exit /b 0
