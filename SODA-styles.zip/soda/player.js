/* player.js — the robot's music player.
 *   - YouTube IFrame playback (same engine as before), now with a record/CD/ring/cover disc
 *   - layouts: sidebar left/right, top bar, bottom bar, floating card, mini pill, hidden
 *   - panels reserve space (CSS insets) so they never cover the face's text
 *   - SponsorBlock: skips sponsors, self-promo, reminders, intros/outros, non-music parts
 *   - every element and number is a setting (see the schema at the bottom)
 *  omni.js owns volume + agent actions and talks to this file through window.Player.
 */
(function () {
  'use strict';
  const UI = window.UI;
  const $ = (s, r) => (r || document).querySelector(s);
  const frame = document.getElementById('frame');
  const ico = (n, c) => UI.icon(n, c);

  const SB_CATS = [
    ['sponsor', 'Sponsor reads'], ['selfpromo', 'Self-promotion'], ['interaction', 'Like / subscribe reminders'],
    ['intro', 'Intros and intermissions'], ['outro', 'Outros and end cards'], ['preview', 'Previews and recaps'],
    ['music_offtopic', 'Non-music parts (talking, skits)'], ['filler', 'Filler and tangents']
  ];
  const CAT_LABEL = { sponsor: 'sponsor', selfpromo: 'self-promo', interaction: 'reminder', intro: 'intro', outro: 'outro', preview: 'recap', music_offtopic: 'non-music part', filler: 'filler', trim: 'trimmed part' };
  const CAT_ON = { sponsor: true, selfpromo: true, interaction: true, intro: true, outro: false, preview: true, music_offtopic: true, filler: true };

  const DEFAULTS = Object.assign({
    // layout
    layout: 'side-right', push: true, width: 320, barHeight: 66, corner: 'tr', surface: 'glass', opacity: 88, border: true, align: 'center', fontScale: 100,
    autoShow: true, hideWhenIdle: true, autoCollapse: 0, orderMode: 'mini',
    // elements
    showHeader: true, showDisc: true, showTitle: true, showArtist: true, showProgress: true, showTime: true, showControls: true,
    showPrev: true, showNext: true, showStop: true, showRepeat: true, showSkipBtn: true, showVolume: true,
    showSearch: true, showResults: true, showSkipChip: true, showMarks: true, showGlow: true, showEq: false, videoMode: 'hidden',
    showLyrics: true, lyricsBold: true, lyricsSize: 100, lyricsEstimate: true,
    // disc
    discStyle: 'vinyl', discSize: 100, spin: 6, spinDir: 'cw', spinWhen: 'playing', spinDown: true, tonearm: true, grooves: 60, sheen: true, labelArt: true, discShadow: true, tint: true,
    // type
    cleanTitles: true, marquee: true, titleSize: 100,
    // skipping
    sbEnabled: true, sbMode: 'auto', trimStart: 0, trimEnd: 0, skipToast: true, preferAudio: true,
    // playback
    repeat: 'off', autoAdvance: false
  }, Object.fromEntries(SB_CATS.map(c => ['cat_' + c[0], CAT_ON[c[0]]])));
  const cfg = UI.store('pl.cfg', DEFAULTS);

  const fmtTime = s => { s = Math.max(0, Math.floor(s || 0)); return Math.floor(s / 60) + ':' + String(s % 60).padStart(2, '0'); };
  async function api(path, body, method) {
    const res = await fetch(path, body === undefined && !method ? {} : { method: method || 'POST', headers: { 'Content-Type': 'application/json' }, body: body === undefined ? undefined : JSON.stringify(body) });
    let d = {}; try { d = await res.json(); } catch (e) {}
    if (!res.ok) throw new Error(d.error || ('HTTP ' + res.status));
    return d;
  }
  const hueOf = id => { let h = 0; for (const ch of String(id || '')) h = (h * 31 + ch.charCodeAt(0)) % 360; return h; };

  /* ================================================================ DOM */
  const el = document.createElement('aside');
  el.id = 'plr'; el.setAttribute('aria-label', 'Music player');
  el.innerHTML = `
    <div class="plr-glow" aria-hidden="true"></div>
    <header class="plr-head" data-el="header">
      <span class="plr-hname">${ico('music')}<span>Music</span></span>
      <span class="plr-hbtns">
        <button type="button" class="plr-ib" data-act="layout" title="Change layout" aria-label="Change layout"></button>
        <button type="button" class="plr-ib" data-act="settings" title="Customize player" aria-label="Customize player">${ico('sliders')}</button>
        <button type="button" class="plr-ib" data-act="collapse" title="Hide player" aria-label="Hide player">${ico('x')}</button>
      </span>
    </header>
    <div class="plr-main">
      <div class="plr-stage" data-el="disc">
        <div class="plr-disc">
          <div class="plr-body">
            <div class="plr-vinyl"></div>
            <div class="plr-label"><img alt="" decoding="async">${ico('music', 'plr-noart')}</div>
            <div class="plr-spindle"></div>
          </div>
          <svg class="plr-ring" viewBox="0 0 100 100" aria-hidden="true"><circle class="rb" cx="50" cy="50" r="48"/><circle class="rf" cx="50" cy="50" r="48" pathLength="100"/></svg>
          <div class="plr-sheen"></div>
          <svg class="plr-arm" viewBox="0 0 100 100" aria-hidden="true"><g class="plr-armg"><circle class="ab" cx="90" cy="10" r="8"/><circle class="ap" cx="90" cy="10" r="3.2"/><path class="al" d="M90 10 L90 58 L83 72"/><rect class="ah" x="77" y="70" width="12" height="7" rx="2" transform="rotate(25 83 73)"/></g></svg>
        </div>
      </div>
      <div class="plr-info">
        <div class="plr-title" data-el="title"><span></span></div>
        <div class="plr-artist" data-el="artist"></div>
        <div class="plr-eq" data-el="eq" aria-hidden="true"><i></i><i></i><i></i><i></i><i></i></div>
      </div>
      <div class="plr-lyric" data-el="lyrics" aria-live="polite">
        <div class="plr-lyric-rail"><div class="plr-lyric-ln cur"></div><div class="plr-lyric-ln nxt" aria-hidden="true"></div></div>
      </div>
      <div class="plr-prog" data-el="progress">
        <span class="plr-t" data-el="time" id="plrCur">0:00</span>
        <div class="plr-bar" role="slider" aria-label="Seek" tabindex="0" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
          <div class="plr-marks" data-el="marks"></div><div class="plr-fill"></div><div class="plr-knob"></div>
        </div>
        <span class="plr-t" data-el="time" id="plrDur">0:00</span>
      </div>
      <div class="plr-ctl" data-el="controls">
        <button type="button" class="plr-b plr-noripple" data-act="repeat" data-el="repeat" title="Repeat" aria-label="Repeat">${ico('repeat')}</button>
        <button type="button" class="plr-b" data-act="prev" data-el="prev" title="Previous" aria-label="Previous">${ico('prev')}</button>
        <button type="button" class="plr-b plr-play" data-act="pp" title="Play / pause" aria-label="Play or pause"><span class="i-play">${ico('play')}</span><span class="i-pause">${ico('pause')}</span></button>
        <button type="button" class="plr-b" data-act="next" data-el="next" title="Next" aria-label="Next">${ico('next')}</button>
        <button type="button" class="plr-b" data-act="stop" data-el="stop" title="Stop" aria-label="Stop">${ico('stop')}</button>
        <button type="button" class="plr-b plr-noripple" data-act="sb" data-el="skipBtn" title="Skip sponsors and clutter" aria-label="Toggle skipping">${ico('scissors')}</button>
      </div>
      <div class="plr-vol" data-el="volume">
        <button type="button" class="plr-b" data-act="mute" title="Mute" aria-label="Mute"><span class="i-vol">${ico('volume')}</span><span class="i-mute">${ico('mute')}</span></button>
        <input type="range" min="0" max="100" step="1" aria-label="Volume" id="plrVol">
        <span class="plr-vl" id="plrVolL"></span>
      </div>
      <div class="plr-skip" data-el="skipChip" hidden><span class="plr-skip-i">${ico('scissors')}</span><span class="plr-skip-t"></span><button type="button" class="plr-chipbtn" data-act="chip"></button></div>
      <div class="plr-video" data-vm="hidden"><div id="plrYT"></div><div class="plr-tap" id="plrTap">${ico('play')}<span>Tap to start</span></div></div>
      <form class="plr-search" data-el="search" autocomplete="off">
        <span class="plr-si">${ico('search')}</span><input type="text" id="plrQ" placeholder="Search a song or artist" aria-label="Search music"><button type="submit" class="plr-b" aria-label="Play">${ico('play2')}</button>
      </form>
      <ol class="plr-results" data-el="results"></ol>
    </div>
    <button type="button" class="plr-handle" data-act="expand" aria-label="Show music player"><span class="plr-hd">${ico('disc')}</span><span class="plr-hc">${ico('left')}</span></button>`;
  frame.appendChild(el);

  const img = $('.plr-label img', el), bodyEl = $('.plr-body', el), titleEl = $('.plr-title span', el), titleBox = $('.plr-title', el), artistEl = $('.plr-artist', el);
  const fillEl = $('.plr-fill', el), knobEl = $('.plr-knob', el), barEl = $('.plr-bar', el), marksEl = $('.plr-marks', el), curEl = $('#plrCur'), durEl = $('#plrDur');
  const volEl = $('#plrVol'), volLEl = $('#plrVolL'), resultsEl = $('.plr-results', el), chipEl = $('.plr-skip', el), chipTxt = $('.plr-skip-t', el), chipBtn = $('.plr-chipbtn', el);
  const ringFill = $('.rf', el), qEl = $('#plrQ'), tapEl = $('#plrTap'), videoEl = $('.plr-video', el);
  const lyricWrap = $('.plr-lyric', el), lyricCur = $('.plr-lyric-ln.cur', el), lyricNxt = $('.plr-lyric-ln.nxt', el);

  /* ================================================================ state */
  const S = {
    yt: null, cands: [], idx: 0, track: null, state: -1, collapsed: false, openedIdle: false, segs: [], raw: null, rawFor: '', built: 0,
    hold: 0, lastSkip: null, skipped: 0, tapTimer: null, lastInteract: Date.now(), tickTimer: null, dur: 0, askSeg: null, seeking: false, resultsOpen: false,
    lyrics: null, lyricsIdx: -1, lyricsToken: 0
  };
  const sbCache = new Map();

  /* ================================================================ titles */
  function parseMeta(t) {
    let title = String(t.title || '').replace(/&amp;/g, '&').replace(/&#39;/g, "'").replace(/&quot;/g, '"');
    let artist = '';
    if (cfg.get('cleanTitles')) {
      title = title.replace(/\s*[\(\[【][^\)\]】]*(official|video|audio|lyric|visuali[sz]er|\bhd\b|\b4k\b|remaster|\bmv\b|m\/v|music video|explicit|full song)[^\)\]】]*[\)\]】]/gi, '').replace(/\s{2,}/g, ' ').trim();
      const m = title.match(/^(.{1,60}?)\s+[-–—]\s+(.+)$/);
      if (m) { artist = m[1].trim(); title = m[2].trim(); }
    }
    if (!artist) artist = String(t.channel || '').replace(/\s*-\s*Topic$/i, '').replace(/VEVO$/i, '').replace(/\s*(Official|Music|Records)$/i, '').trim();
    return { title: title || 'Playing', artist };
  }

  /* ================================================================ YouTube */
  let ytLoading = null;
  function loadYT() {
    if (window.YT && window.YT.Player) return Promise.resolve();
    if (ytLoading) return ytLoading;
    ytLoading = new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('YouTube did not load. Is the internet connected?')), 15000);
      window.onYouTubeIframeAPIReady = () => { clearTimeout(t); resolve(); };
      const s = document.createElement('script'); s.src = 'https://www.youtube.com/iframe_api';
      s.onerror = () => { clearTimeout(t); reject(new Error('Could not reach YouTube.')); };
      document.head.appendChild(s);
    }).catch(err => { ytLoading = null; throw err; });
    return ytLoading;
  }

  const Player = {
    cfg,
    get yt() { return S.yt; },
    get track() { return S.track; },
    get playing() { return S.state === 1 || S.state === 3; },
    get state() { return { track: S.track ? parseMeta(S.track).title : '', repeat: cfg.get('repeat'), skipped: Math.round(S.skipped) }; },

    async play(cands, startIdx) {
      S.cands = (cands || []).filter(c => c && /^[\w-]{11}$/.test(c.video_id));
      S.idx = startIdx || 0;
      if (!S.cands.length) { UI.toast("Couldn't find that song", 'x'); return; }
      S.collapsed = false;
      renderResults();
      await this.start();
    },
    async start() {
      const c = S.cands[S.idx];
      if (!c) { S.track = null; paint(); UI.toast("Couldn't play that one", 'x'); return; }
      S.track = c; S.segs = []; S.raw = null; S.dur = 0; S.built = 0; S.lastSkip = null; S.askSeg = null; S.hold = 0;
      if (cfg.get('autoShow')) S.collapsed = false;
      paint(true); renderResults(); layout();
      try { await loadYT(); } catch (err) { UI.toast(err.message, 'x'); return; }
      const vars = { autoplay: 1, playsinline: 1, rel: 0, modestbranding: 1, iv_load_policy: 3, origin: location.origin };
      if (!S.yt) {
        S.yt = new YT.Player('plrYT', {
          width: '100%', height: '100%', videoId: c.video_id, playerVars: vars,
          events: {
            onReady: () => { window.Omni && Omni.volume.apply(true); armTap(); startTick(); },
            onStateChange: e => { S.state = e.data; if (e.data === 1) tapEl.classList.remove('show'); if (e.data === 0) onEnded(); paint(); },
            onError: () => { S.idx += 1; Player.start(); }
          }
        });
      } else {
        S.yt.loadVideoById(c.video_id);
        window.Omni && Omni.volume.apply(true);
        armTap();
      }
      loadSegments(c.video_id);
      loadLyrics(c);
    },
    control(action) {
      const p = S.yt, V = window.Omni && Omni.volume;
      if (action === 'mute') { if (V) { V.muted = true; V.apply(true); } }
      else if (action === 'unmute') { if (V) { V.muted = false; V.apply(true); } }
      else if (action === 'next') next();
      else if (action === 'previous') prev();
      else if (action === 'restart' || action === 'replay') { if (p) { p.seekTo(0, true); p.playVideo(); } }
      else if (action === 'repeat') setRepeat(cfg.get('repeat') === 'one' ? 'off' : 'one');
      else if (action === 'repeat_on') setRepeat('one');
      else if (action === 'repeat_off') setRepeat('off');
      else if (!p) return;
      else if (action === 'pause') p.pauseVideo();
      else if (action === 'resume') p.playVideo();
      else if (action === 'stop') { p.stopVideo(); S.track = null; S.state = -1; S.segs = []; paint(); renderResults(); }
      if (V) V.paint();
      paint();
    },
    setLayout(l) { cfg.set('layout', l); },
    setSkipping(on) { cfg.set('sbEnabled', !!on); UI.toast('Auto-skip ' + (on ? 'on' : 'off'), 'scissors'); },
    toggle() { toggleCollapsed(); },
    onVolume(level, muted) {
      volEl.value = level; volLEl.textContent = level + '%';
      el.classList.toggle('is-muted', !!muted);
    },
    onDuck(on) { el.classList.toggle('is-ducked', !!on); },
    set(k, v) { cfg.set(k, v); },
    search: manualSearch,
    layouts: ['side-right', 'side-left', 'top', 'bottom', 'float', 'mini', 'hidden']
  };
  window.Player = Player;

  function armTap() {
    clearTimeout(S.tapTimer);
    S.tapTimer = setTimeout(() => {
      const st = S.yt && S.yt.getPlayerState ? S.yt.getPlayerState() : -1;
      if (S.track && st !== 1 && st !== 3) tapEl.classList.add('show');
    }, 2500);
  }
  tapEl.addEventListener('click', () => { if (S.yt) S.yt.playVideo(); tapEl.classList.remove('show'); });

  function next() {
    if (S.idx + 1 < S.cands.length) { S.idx += 1; Player.start(); }
    else if (S.yt) { S.yt.seekTo(0, true); UI.toast('That was the last result', 'list'); }
  }
  function prev() {
    const t = S.yt && S.yt.getCurrentTime ? S.yt.getCurrentTime() : 0;
    if (t > 4 || S.idx === 0) { if (S.yt) S.yt.seekTo(0, true); }
    else { S.idx -= 1; Player.start(); }
  }
  function setRepeat(v) { cfg.set('repeat', v); UI.toast('Repeat ' + (v === 'one' ? 'on' : 'off'), 'repeat'); }
  function onEnded() {
    if (cfg.get('repeat') === 'one' && S.yt) { S.yt.seekTo(0, true); S.yt.playVideo(); return; }
    if (cfg.get('autoAdvance') && S.idx + 1 < S.cands.length) next();
  }
  function endEarly() {          // skipping reached the end of the video
    if (cfg.get('repeat') === 'one' && S.yt) { S.yt.seekTo(0, true); return; }
    if (cfg.get('autoAdvance') && S.idx + 1 < S.cands.length) { next(); return; }
    if (S.yt) { S.yt.pauseVideo(); S.yt.seekTo(0, true); }
  }

  /* ================================================================ SponsorBlock */
  const SB_ALL = SB_CATS.map(c => c[0]);
  async function fetchSB(id) {
    const cats = encodeURIComponent(JSON.stringify(SB_ALL)), acts = encodeURIComponent(JSON.stringify(['skip']));
    const norm = list => (list || []).filter(s => s && s.segment && (s.actionType || 'skip') === 'skip' && SB_ALL.includes(s.category))
      .map(s => ({ cat: s.category, start: +s.segment[0], end: +s.segment[1] })).filter(s => s.end - s.start > 0.5);
    try {
      let r;
      if (window.crypto && crypto.subtle) {
        const h = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(id));
        const prefix = Array.from(new Uint8Array(h)).slice(0, 2).map(b => b.toString(16).padStart(2, '0')).join('');
        r = await fetch('https://sponsor.ajay.app/api/skipSegments/' + prefix + '?categories=' + cats + '&actionTypes=' + acts);
        if (r.status === 404) return [];
        if (r.ok) { const arr = await r.json(); const mine = arr.find(v => v.videoID === id); return mine ? norm(mine.segments) : []; }
      } else {
        r = await fetch('https://sponsor.ajay.app/api/skipSegments?videoID=' + id + '&categories=' + cats + '&actionTypes=' + acts);
        if (r.status === 404) return [];
        if (r.ok) return norm(await r.json());
      }
    } catch (e) { /* fall through to the backend proxy */ }
    const d = await api('/music/segments?video_id=' + encodeURIComponent(id), undefined, 'GET');
    return (d.segments || []).map(s => ({ cat: s.category, start: +s.start, end: +s.end }));
  }
  async function loadSegments(id) {
    if (!cfg.get('sbEnabled')) { S.raw = []; buildSegs(); return; }
    try {
      let raw = sbCache.get(id);
      if (!raw) { raw = await fetchSB(id); sbCache.set(id, raw); }
      if (S.track && S.track.video_id === id) { S.raw = raw; buildSegs(); }
    } catch (e) { if (S.track && S.track.video_id === id) { S.raw = []; buildSegs(); } }
  }
  function buildSegs() {
    const dur = S.dur || (S.yt && S.yt.getDuration ? S.yt.getDuration() : 0) || 0;
    let list = [];
    if (cfg.get('sbEnabled')) list = (S.raw || []).filter(s => cfg.get('cat_' + s.cat));
    const ts = +cfg.get('trimStart'), te = +cfg.get('trimEnd');
    if (ts > 0) list.push({ cat: 'trim', start: 0, end: ts });
    if (te > 0 && dur > te + 5) list.push({ cat: 'trim', start: dur - te, end: dur + 1 });
    list.sort((a, b) => a.start - b.start);
    const merged = [];
    list.forEach(s => { const l = merged[merged.length - 1]; if (l && s.start <= l.end + 0.3) { l.end = Math.max(l.end, s.end); if (l.cat !== s.cat) l.cat = l.cat === 'trim' ? s.cat : l.cat; } else merged.push(Object.assign({}, s)); });
    S.segs = merged; S.built = dur;
    paintMarks();
    const hasSB = (S.raw || []).length > 0;
    el.classList.toggle('has-skips', hasSB || merged.length > 0);
  }
  function checkSkip(t, d) {
    if (!S.segs.length || performance.now() < S.hold) { if (S.askSeg && performance.now() >= S.hold) hideAsk(); return; }
    const mode = cfg.get('sbMode');
    const seg = S.segs.find(s => t >= s.start - 0.05 && t < s.end - 0.25);
    if (!seg) { if (S.askSeg) hideAsk(); return; }
    if (mode === 'ask') { showAsk(seg); return; }
    doSkip(seg, t, d);
  }
  function doSkip(seg, t, d) {
    S.lastSkip = { seg, from: t };
    S.skipped += Math.max(0, seg.end - t);
    if (seg.end >= (d || 1e9) - 1.2) endEarly(); else S.yt.seekTo(seg.end, true);
    S.hold = performance.now() + 700;
    const secs = Math.round(seg.end - t);
    showChip('Skipped ' + (CAT_LABEL[seg.cat] || 'part') + ' · ' + secs + 's', 'Undo', () => { S.hold = performance.now() + (seg.end - seg.start + 2) * 1000; S.yt.seekTo(seg.start, true); hideChip(); }, 5000);
    if (cfg.get('skipToast') && !cfg.get('showSkipChip')) UI.toast('Skipped ' + (CAT_LABEL[seg.cat] || 'part') + ' (' + secs + 's)', 'scissors');
  }
  function showAsk(seg) {
    if (S.askSeg === seg) return;
    S.askSeg = seg;
    showChip((CAT_LABEL[seg.cat] || 'Part') + ' ahead · ' + Math.round(seg.end - seg.start) + 's', 'Skip', () => { S.askSeg = null; doSkip(seg, S.yt.getCurrentTime(), S.dur); }, 0);
  }
  function hideAsk() { S.askSeg = null; hideChip(); }
  let chipTimer = null, chipAct = null;
  function showChip(text, btn, act, ms) {
    chipTxt.textContent = text; chipBtn.textContent = btn; chipAct = act;
    chipEl.hidden = false; chipEl.classList.remove('in'); void chipEl.offsetWidth; chipEl.classList.add('in');
    clearTimeout(chipTimer); if (ms) chipTimer = setTimeout(hideChip, ms);
  }
  function hideChip() { chipEl.classList.remove('in'); chipEl.hidden = true; }
  chipBtn.addEventListener('click', () => { if (chipAct) chipAct(); });

  /* ================================================================ lyrics
   * One line on screen at a time, like Spotify's single-line view. Words
   * bold progressively as they're sung, then the box swipes up to the next
   * line. Lines and (when the source has them) word timings come from the
   * backend's /music/lyrics, which tries lrclib.net's synced-lyrics database
   * first and a YouTube caption track second. When only line-level timing is
   * available we estimate word timing within the line (by word length) so
   * the bolding still sweeps smoothly instead of jumping all at once. */
  const lyricsCache = new Map();
  function wireLineTimes(lines) {
    const out = [];
    for (let i = 0; i < lines.length; i++) {
      const line = lines[i], next = lines[i + 1];
      if (line.time == null) continue;
      const end = next && next.time != null ? next.time : line.time + 6;
      let words = line.words && line.words.length ? line.words.map(w => ({ text: w.text, time: w.time })) : null;
      if (!words) {
        const toks = line.text.split(/\s+/).filter(Boolean);
        const weights = toks.map(t => Math.max(1, t.length));
        const total = weights.reduce((a, b) => a + b, 0) || 1;
        let acc = 0;
        words = toks.map((t, k) => { const start = line.time + (acc / total) * Math.max(0.4, end - line.time) * 0.94; acc += weights[k]; return { text: t, time: start }; });
      }
      out.push({ time: line.time, end, text: line.text, words });
    }
    return out;
  }
  async function loadLyrics(c) {
    S.lyrics = null; S.lyricsIdx = -1; paintLyricLine(null);
    if (!cfg.get('showLyrics')) return;
    const m = parseMeta(c), key = c.video_id + '|' + m.artist + '|' + m.title;
    const token = ++S.lyricsToken;
    try {
      let data = lyricsCache.get(key);
      if (!data) {
        const qs = new URLSearchParams({ video_id: c.video_id, artist: m.artist, title: m.title });
        data = await api('/music/lyrics?' + qs.toString(), undefined, 'GET');
        lyricsCache.set(key, data);
      }
      if (token !== S.lyricsToken || S.track !== c) return;
      const lines = wireLineTimes(data.lines || []);
      S.lyrics = lines.length ? { synced: !!data.synced && lines.length, lines, wordLevel: (data.lines || []).some(l => l.words && l.words.length) } : null;
      el.classList.toggle('has-lyrics', !!(S.lyrics && cfg.get('showLyrics')));
    } catch (e) { S.lyrics = null; el.classList.remove('has-lyrics'); }
  }
  /* Ask the backend for the real cover (iTunes / Deezer) and swap it onto the disc once it has loaded. */
  async function loadOfficialArt(t, m) {
    try {
      const qs = new URLSearchParams({ video_id: t.video_id, title: m.title, artist: m.artist, channel: t.channel || '' });
      const d = await api('/music/art?' + qs.toString(), undefined, 'GET');
      if (!d || !d.url || S.track !== t || d.source === 'youtube') return;     // keep the placeholder if nothing official was found
      const pre = new Image();
      pre.onload = () => { if (S.track === t) { t.cover = d.url; img.classList.remove('ok'); img.src = d.url; } };
      pre.src = d.url;
    } catch (e) { /* offline: the placeholder stays */ }
  }
  function lineHTML(line) {
    if (!line) return '';
    if (!line.words) return '<span class="lyr-track"><span class="w">' + escapeHTML(line.text) + '</span></span>';
    return '<span class="lyr-track">' + line.words.map(w => '<span class="w" data-t="' + w.time + '">' + escapeHTML(w.text) + ' </span>').join('') + '</span>';
  }
  function escapeHTML(s) { return String(s).replace(/[&<>]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' }[c])); }
  function paintLyricLine(line, advancing) {
    if (!line) { lyricCur.innerHTML = ''; lyricNxt.innerHTML = ''; return; }
    if (advancing && !UI.reducedMotion()) {
      lyricNxt.innerHTML = lineHTML(line);
      const rail = $('.plr-lyric-rail', el);
      rail.classList.add('swipe');
      setTimeout(() => {
        lyricCur.innerHTML = lyricNxt.innerHTML; lyricNxt.innerHTML = '';
        rail.classList.remove('swipe');
      }, 420 * (100 / Math.max(25, cfg.get('speed') || 100)));
    } else {
      lyricCur.innerHTML = lineHTML(line); lyricNxt.innerHTML = '';
    }
  }
  function tickLyrics(t) {
    if (!S.lyrics || !cfg.get('showLyrics')) return;
    const lines = S.lyrics.lines;
    let idx = -1;
    for (let i = 0; i < lines.length; i++) if (t >= lines[i].time) idx = i; else break;
    if (idx !== S.lyricsIdx) { paintLyricLine(lines[idx] || null, idx > S.lyricsIdx); S.lyricsIdx = idx; }
    if (idx >= 0 && cfg.get('lyricsBold')) {
      const spans = lyricCur.querySelectorAll('.w[data-t]');
      spans.forEach(sp => sp.classList.toggle('sung', t >= +sp.dataset.t));
    }
    if (idx >= 0) slideLyricLine(lyricCur, t);
  }
  /* A verse wider than the box slides left as it is sung, so the word being
   * sung stays in view (instead of the old "..." cut). Short lines don't move. */
  function slideLyricLine(lineEl, t) {
    const track = lineEl.firstElementChild;
    if (!track || !track.classList.contains('lyr-track')) return;
    const avail = lineEl.clientWidth, over = track.offsetWidth - avail;
    if (avail <= 0 || over <= 2) { lineEl.classList.remove('slides', 'moved'); track.style.transform = ''; return; }
    lineEl.classList.add('slides');
    let cur = null;
    for (const sp of track.querySelectorAll('.w[data-t]')) { if (t >= +sp.dataset.t) cur = sp; else break; }
    const target = cur ? Math.min(over + 6, Math.max(0, cur.offsetLeft + cur.offsetWidth - avail * 0.72)) : 0;
    track.style.transform = 'translateX(' + (-target).toFixed(1) + 'px)';
    lineEl.classList.toggle('moved', target > 4);
  }

  /* ================================================================ ticking */
  function startTick() {
    clearInterval(S.tickTimer);
    S.tickTimer = setInterval(() => {
      const p = S.yt; if (!p || !p.getCurrentTime || !S.track) return;
      const t = p.getCurrentTime() || 0, d = p.getDuration() || 0;
      if (d && d !== S.dur) { S.dur = d; buildSegs(); }
      if (!S.seeking) paintProgress(t, d);
      if (Player.playing) checkSkip(t, d);
      if (Player.playing) tickLyrics(t);
    }, 200);
  }
  function paintProgress(t, d) {
    const frac = d ? Math.min(1, t / d) : 0;
    el.style.setProperty('--p', frac.toFixed(4));
    curEl.textContent = fmtTime(t); durEl.textContent = fmtTime(d);
    barEl.setAttribute('aria-valuenow', Math.round(frac * 100));
    ringFill.style.strokeDashoffset = String(100 - frac * 100);
    el.style.setProperty('--arm', (12 + frac * 11) + 'deg');
  }
  function paintMarks() {
    marksEl.innerHTML = '';
    const d = S.dur || 0; if (!d) return;
    S.segs.forEach(s => {
      const m = document.createElement('i');
      m.style.left = (s.start / d * 100) + '%'; m.style.width = Math.max(.4, (Math.min(s.end, d) - s.start) / d * 100) + '%';
      m.title = (CAT_LABEL[s.cat] || 'skip') + ' · ' + fmtTime(s.start) + '–' + fmtTime(Math.min(s.end, d));
      marksEl.appendChild(m);
    });
  }

  /* ================================================================ seeking */
  function seekFromEvent(e) {
    const r = barEl.getBoundingClientRect(), f = Math.max(0, Math.min(1, (e.clientX - r.left) / r.width));
    const d = S.yt && S.yt.getDuration ? S.yt.getDuration() : 0;
    if (!d) return;
    el.style.setProperty('--p', f.toFixed(4)); curEl.textContent = fmtTime(f * d);
    return f * d;
  }
  barEl.addEventListener('pointerdown', e => {
    S.seeking = true; barEl.setPointerCapture(e.pointerId); el.classList.add('seeking'); seekFromEvent(e);
  });
  barEl.addEventListener('pointermove', e => { if (S.seeking) seekFromEvent(e); });
  barEl.addEventListener('pointerup', e => {
    if (!S.seeking) return;
    const t = seekFromEvent(e); S.seeking = false; el.classList.remove('seeking');
    if (t != null && S.yt) { S.hold = performance.now() + 3000; S.yt.seekTo(t, true); }
  });
  barEl.addEventListener('keydown', e => {
    if (!S.yt) return; const t = S.yt.getCurrentTime();
    if (e.key === 'ArrowRight') { S.hold = performance.now() + 3000; S.yt.seekTo(t + 5, true); }
    if (e.key === 'ArrowLeft') { S.hold = performance.now() + 3000; S.yt.seekTo(Math.max(0, t - 5), true); }
  });

  /* ================================================================ disc spin */
  const Spin = {
    anim: null, rate: 0, target: 0, raf: 0,
    ensure() {
      if (this.anim || !bodyEl.animate) return;
      this.anim = bodyEl.animate([{ transform: 'rotate(0deg)' }, { transform: 'rotate(360deg)' }], { duration: cfg.get('spin') * 1000, iterations: Infinity, direction: cfg.get('spinDir') === 'ccw' ? 'reverse' : 'normal' });
      this.anim.playbackRate = 0;
    },
    timing() {
      if (!this.anim) return;
      this.anim.effect.updateTiming({ duration: cfg.get('spin') * 1000, direction: cfg.get('spinDir') === 'ccw' ? 'reverse' : 'normal' });
    },
    to(target) {
      this.ensure(); if (!this.anim) return;
      this.target = target; cancelAnimationFrame(this.raf);
      const step = () => {
        const k = cfg.get('spinDown') && !UI.reducedMotion() ? 0.05 : 1;
        this.rate += (this.target - this.rate) * k;
        if (Math.abs(this.target - this.rate) < 0.01) this.rate = this.target;
        this.anim.playbackRate = this.rate;
        if (this.rate !== this.target) this.raf = requestAnimationFrame(step);
      };
      step();
    }
  };

  /* ================================================================ painting */
  function paint(newTrack) {
    const t = S.track, playing = Player.playing;
    const m = t ? parseMeta(t) : null;
    el.dataset.state = !t ? 'idle' : playing ? 'playing' : 'paused';
    el.classList.toggle('has-track', !!t);
    if (newTrack && t) {
      titleBox.classList.remove('swap'); artistEl.classList.remove('swap'); void titleBox.offsetWidth;
      titleBox.classList.add('swap'); artistEl.classList.add('swap');
      el.classList.remove('drop'); void el.offsetWidth; el.classList.add('drop');
      // Official album art when we know it; the YouTube frame only as an instant placeholder / last resort.
      const url = t.cover || ('https://i.ytimg.com/vi/' + t.video_id + '/mqdefault.jpg');
      img.classList.remove('ok'); img.onload = () => img.classList.add('ok'); img.onerror = () => img.classList.remove('ok');
      img.src = url;
      if (!t.cover) loadOfficialArt(t, m);
      el.style.setProperty('--hue', hueOf(t.video_id));
      curEl.textContent = '0:00'; durEl.textContent = t.length || '0:00';
      el.style.setProperty('--p', '0'); ringFill.style.strokeDashoffset = '100';
      marksEl.innerHTML = '';
    }
    if (!t) { titleEl.textContent = 'Nothing playing'; artistEl.textContent = 'Ask me to play a song'; img.removeAttribute('src'); img.classList.remove('ok'); marksEl.innerHTML = ''; curEl.textContent = '0:00'; durEl.textContent = '0:00'; el.style.setProperty('--p', '0'); hideChip(); S.lyrics = null; S.lyricsIdx = -1; paintLyricLine(null); el.classList.remove('has-lyrics'); }
    else { titleEl.textContent = m.title; artistEl.textContent = m.artist; }
    el.setAttribute('data-ds', cfg.get('discStyle'));
    fitTitle();
    const spinning = (playing || (cfg.get('spinWhen') === 'always' && t)) && cfg.get('discStyle') !== 'cover' && !UI.reducedMotion();
    Spin.to(spinning ? 1 : 0);
    const dot = document.getElementById('plrBtn');
    if (dot) { dot.classList.toggle('live', !!t && playing); dot.classList.toggle('on', !!t && !S.collapsed && layoutState.visible); }
    el.querySelectorAll('[data-act=sb]').forEach(b => b.classList.toggle('on', cfg.get('sbEnabled')));
    $('[data-act=repeat]', el).classList.toggle('on', cfg.get('repeat') === 'one');
    layout();
  }
  function fitTitle() {
    titleBox.classList.remove('marq'); titleBox.style.removeProperty('--mx');
    if (!cfg.get('marquee')) return;
    requestAnimationFrame(() => {
      const over = titleEl.scrollWidth - titleBox.clientWidth;
      if (over > 6) { titleBox.style.setProperty('--mx', '-' + (over + 12) + 'px'); titleBox.style.setProperty('--md', Math.max(6, (over + 12) / 22) + 's'); titleBox.classList.add('marq'); }
    });
  }
  function renderResults() {
    resultsEl.innerHTML = '';
    S.cands.forEach((c, i) => {
      const m = parseMeta(c), li = document.createElement('li');
      li.style.setProperty('--i', i); if (i === S.idx) li.classList.add('cur');
      li.innerHTML = '<img alt="" loading="lazy"><div><b></b><small></small></div><span class="plr-eqm"><i></i><i></i><i></i></span>';
      $('img', li).src = 'https://i.ytimg.com/vi/' + c.video_id + '/default.jpg';
      $('b', li).textContent = m.title; $('small', li).textContent = (m.artist || '') + (c.length ? ' · ' + c.length : '');
      li.tabIndex = 0;
      const go = () => { S.idx = i; Player.start(); S.resultsOpen = false; layout(); };
      li.addEventListener('click', go); li.addEventListener('keydown', e => { if (e.key === 'Enter') go(); });
      resultsEl.appendChild(li);
    });
  }

  /* ================================================================ layout + insets */
  const layoutState = { visible: false, eff: 'side-right' };
  const isBar = l => l === 'top' || l === 'bottom';
  function effective() {
    let l = cfg.get('layout');
    const inOrder = frame.classList.contains('drink-mode');
    if (inOrder && cfg.get('orderMode') !== 'keep') l = cfg.get('orderMode') === 'hide' ? 'hidden' : 'mini';
    if (window.innerWidth < 640 && (l === 'side-left' || l === 'side-right' || l === 'float')) l = 'mini';
    return l;
  }
  function layout() {
    const eff = effective(), hasTrack = !!S.track;
    let visible = eff !== 'hidden' && (hasTrack || !cfg.get('hideWhenIdle') || S.openedIdle);
    if (isBar(eff) || eff === 'mini' || eff === 'float') visible = visible && !S.collapsed;
    layoutState.visible = visible; layoutState.eff = eff;
    el.dataset.layout = eff === 'hidden' ? cfg.get('layout') : eff;
    el.dataset.corner = cfg.get('corner');
    el.dataset.collapsed = String(S.collapsed);
    el.dataset.visible = String(visible);
    el.dataset.surface = cfg.get('surface');
    el.dataset.align = cfg.get('align');
    el.dataset.vm = cfg.get('videoMode');
    videoEl.dataset.vm = cfg.get('videoMode');
    el.classList.toggle('no-border', !cfg.get('border'));
    el.classList.toggle('results-open', S.resultsOpen);
    const hide = [];
    [['Header', 'header'], ['Disc', 'disc'], ['Title', 'title'], ['Artist', 'artist'], ['Progress', 'progress'], ['Time', 'time'], ['Controls', 'controls'], ['Prev', 'prev'], ['Next', 'next'], ['Stop', 'stop'], ['Repeat', 'repeat'], ['SkipBtn', 'skipBtn'], ['Volume', 'volume'], ['Search', 'search'], ['Results', 'results'], ['SkipChip', 'skipChip'], ['Marks', 'marks'], ['Eq', 'eq'], ['Lyrics', 'lyrics']]
      .forEach(([k, v]) => { if (!cfg.get('show' + k)) hide.push(v); });
    if (!cfg.get('tonearm')) hide.push('arm'); if (!cfg.get('showGlow')) hide.push('glow');
    el.dataset.hide = hide.join(' ');
    const s = el.style;
    s.setProperty('--pl-w', cfg.get('width') + 'px'); s.setProperty('--pl-bh', cfg.get('barHeight') + 'px'); s.setProperty('--pl-a', cfg.get('opacity') / 100);
    s.setProperty('--pl-ds', cfg.get('discSize') / 100); s.setProperty('--pl-groove', cfg.get('grooves') / 100); s.setProperty('--pl-font', cfg.get('fontScale') / 100);
    s.setProperty('--pl-title', cfg.get('titleSize') / 100);
    s.setProperty('--pl-lyr', cfg.get('lyricsSize') / 100);
    if (cfg.get('lyricsBold')) el.setAttribute('data-boldlyrics', ''); else el.removeAttribute('data-boldlyrics');
    el.classList.toggle('no-sheen', !cfg.get('sheen')); el.classList.toggle('no-label', !cfg.get('labelArt')); el.classList.toggle('no-shadow', !cfg.get('discShadow'));
    el.classList.toggle('tint', !!cfg.get('tint'));
    // reserve space so nothing is covered
    let L = 0, R = 0, T = 0, B = 0;
    if (visible && !S.collapsed) {
      if (eff === 'side-left') L = cfg.get('width'); if (eff === 'side-right') R = cfg.get('width');
      if (eff === 'top') T = cfg.get('barHeight'); if (eff === 'bottom') B = cfg.get('barHeight');
    }
    const f = frame.style, push = cfg.get('push');
    f.setProperty('--hL', L + 'px'); f.setProperty('--hR', R + 'px'); f.setProperty('--hT', T + 'px'); f.setProperty('--hB', B + 'px');
    f.setProperty('--fL', push ? L + 'px' : '0px'); f.setProperty('--fR', push ? R + 'px' : '0px'); f.setProperty('--fT', push ? T + 'px' : '0px'); f.setProperty('--fB', push ? B + 'px' : '0px');
    frame.classList.toggle('has-plr', visible && (eff === 'mini' || eff === 'float'));
    // layout button icon + the settings drawer opens on the opposite side
    const lb = $('[data-act=layout]', el);
    const iconFor = { 'side-right': 'panelR', 'side-left': 'panelL', top: 'panelT', bottom: 'panelB', float: 'float', mini: 'mini' };
    lb.innerHTML = ico(iconFor[cfg.get('layout')] || 'panelR');
    const side = (eff === 'side-left' || ((eff === 'float' || eff === 'mini') && /l$/.test(cfg.get('corner')))) ? 'right' : 'left';
    UI.sheet.side(side);
    const hb = document.getElementById('plrBtn'); if (hb) hb.classList.toggle('on', visible);
    // keep the face's canvas buffer in step while the inset transition runs
    if (layout._k !== [L, R, T, B, push].join()) { layout._k = [L, R, T, B, push].join(); burstResize(); }
    fitTitle();
  }
  let resizeUntil = 0;
  function burstResize() {
    const first = resizeUntil < performance.now(); resizeUntil = performance.now() + 700;
    if (!first) return;
    (function loop() { window.dispatchEvent(new Event('resize')); if (performance.now() < resizeUntil) requestAnimationFrame(loop); })();
  }
  new MutationObserver(() => layout()).observe(frame, { attributes: true, attributeFilter: ['class'] });
  window.addEventListener('resize', () => { clearTimeout(layout._t); layout._t = setTimeout(layout, 120); });

  function toggleCollapsed() {
    const eff = effective();
    if (!S.track && cfg.get('hideWhenIdle')) { S.openedIdle = !S.openedIdle; if (S.openedIdle) S.collapsed = false; }
    else S.collapsed = !S.collapsed;
    if (isBar(eff) || eff === 'mini' || eff === 'float') { /* visibility follows collapsed */ }
    layout(); paint();
    if (!S.collapsed && S.openedIdle) setTimeout(() => qEl.focus({ preventScroll: true }), 350);
  }

  /* ================================================================ events */
  const LAYOUT_CYCLE = ['side-right', 'side-left', 'top', 'bottom', 'float', 'mini'];
  el.addEventListener('click', e => {
    const b = e.target.closest('[data-act]'); if (!b || !el.contains(b)) return;
    S.lastInteract = Date.now();
    switch (b.dataset.act) {
      case 'pp': Player.control(Player.playing ? 'pause' : 'resume'); break;
      case 'next': next(); break;
      case 'prev': prev(); break;
      case 'stop': Player.control('stop'); break;
      case 'mute': Player.control(el.classList.contains('is-muted') ? 'unmute' : 'mute'); break;
      case 'repeat': setRepeat(cfg.get('repeat') === 'one' ? 'off' : 'one'); break;
      case 'sb': Player.setSkipping(!cfg.get('sbEnabled')); break;
      case 'layout': { const i = LAYOUT_CYCLE.indexOf(cfg.get('layout')); cfg.set('layout', LAYOUT_CYCLE[(i + 1) % LAYOUT_CYCLE.length]); break; }
      case 'settings': UI.sheet.toggle('p_layout'); break;
      case 'collapse': S.collapsed = true; S.openedIdle = false; layout(); paint(); break;
      case 'expand': S.collapsed = false; layout(); paint(); break;
    }
  });
  volEl.addEventListener('input', () => { window.Omni && Omni.volume.set(volEl.value); });
  async function manualSearch(q) {
    q = String(q || qEl.value).trim(); if (!q) return;
    UI.toast('Searching…', 'search', 1500);
    try {
      const r = await api('/browse/music', { query: q, prefer_audio: !!cfg.get('preferAudio') });
      Player.play(r.results);
    } catch (err) { UI.toast(err.message, 'x'); }
  }
  $('.plr-search', el).addEventListener('submit', e => { e.preventDefault(); manualSearch(); });
  qEl.addEventListener('focus', () => { if (isBar(effective()) && S.cands.length) { S.resultsOpen = true; layout(); } });
  document.addEventListener('pointerdown', e => { if (S.resultsOpen && !el.contains(e.target)) { S.resultsOpen = false; layout(); } });
  el.addEventListener('pointerdown', () => { S.lastInteract = Date.now(); });
  setInterval(() => {
    const sec = +cfg.get('autoCollapse');
    if (sec > 0 && S.track && !S.collapsed && !UI.sheet.isOpen && Date.now() - S.lastInteract > sec * 1000) { S.collapsed = true; layout(); paint(); }
  }, 1000);

  /* ================================================================ settings */
  const L = (v, t, i) => [v, t, i];
  const showToggle = (k, label, hint) => ({ k: 'show' + k, t: 'toggle', label, hint });
  UI.sheet.register({ id: 'p_layout', title: 'Layout', icon: 'layout', store: cfg, schema: [
    { g: 'Where the player lives' },
    { k: 'layout', t: 'seg', label: 'Layout', opts: [L('side-left', 'Sidebar left', 'panelL'), L('side-right', 'Sidebar right', 'panelR'), L('top', 'Top bar', 'panelT'), L('bottom', 'Bottom bar', 'panelB'), L('float', 'Floating card', 'float'), L('mini', 'Mini pill', 'mini'), L('hidden', 'Hidden', 'eyeOff')] },
    { k: 'push', t: 'toggle', label: 'Move the face aside', hint: 'Off keeps the face centred and lets the panel sit over it. Text and buttons always make room.' },
    { k: 'width', t: 'range', label: 'Panel width', min: 240, max: 480, step: 10, unit: 'px', when: c => c.layout === 'side-left' || c.layout === 'side-right' || c.layout === 'float' },
    { k: 'barHeight', t: 'range', label: 'Bar height', min: 52, max: 120, step: 2, unit: 'px', when: c => c.layout === 'top' || c.layout === 'bottom' },
    { k: 'corner', t: 'select', label: 'Corner', opts: [['tr', 'Top right'], ['tl', 'Top left'], ['br', 'Bottom right'], ['bl', 'Bottom left']], when: c => c.layout === 'float' || c.layout === 'mini' },
    { g: 'Surface' },
    { k: 'surface', t: 'seg', label: 'Style', opts: [['glass', 'Glass'], ['solid', 'Solid'], ['clear', 'Clear']] },
    { k: 'opacity', t: 'range', label: 'Opacity', min: 20, max: 100, unit: '%', when: c => c.surface !== 'clear' },
    { k: 'border', t: 'toggle', label: 'Border line' },
    { k: 'align', t: 'seg', label: 'Text alignment', opts: [['left', 'Left'], ['center', 'Centre']] },
    { k: 'fontScale', t: 'range', label: 'Player text size', min: 80, max: 140, step: 5, unit: '%' },
    { g: 'When it shows' },
    { k: 'autoShow', t: 'toggle', label: 'Open when a song starts' },
    { k: 'hideWhenIdle', t: 'toggle', label: 'Hide when nothing is playing' },
    { k: 'autoCollapse', t: 'range', label: 'Auto-hide after', min: 0, max: 60, step: 5, unit: 's', hint: '0 keeps it open' },
    { k: 'orderMode', t: 'select', label: 'While a drink is ordered', opts: [['mini', 'Shrink to a pill'], ['keep', 'Keep as it is'], ['hide', 'Hide']] }
  ] });
  UI.sheet.register({ id: 'p_elements', title: 'Elements', icon: 'eye', store: cfg, schema: [
    { g: 'Show or hide each part' },
    showToggle('Header', 'Header and buttons'), showToggle('Disc', 'Record / disc'), showToggle('Title', 'Song title'), showToggle('Artist', 'Artist'),
    showToggle('Progress', 'Progress bar'), showToggle('Time', 'Time stamps'), showToggle('Marks', 'Skipped-part marks on the bar'),
    showToggle('Controls', 'Control buttons'), showToggle('Prev', 'Previous button'), showToggle('Next', 'Next button'), showToggle('Stop', 'Stop button'), showToggle('Repeat', 'Repeat button'), showToggle('SkipBtn', 'Auto-skip button'),
    showToggle('Volume', 'Volume'), showToggle('Search', 'Search box'), showToggle('Results', 'Results list'), showToggle('SkipChip', 'Skip notice with Undo'),
    showToggle('Glow', 'Colour glow behind the player'), { k: 'showEq', t: 'toggle', label: 'Decorative equalizer', hint: 'Animated bars for looks only. They do not read the audio.' },
    showToggle('Lyrics', 'Lyrics line', 'One line at a time, like Spotify, with words bolding as they\u2019re sung.'),
    { k: 'lyricsBold', t: 'toggle', label: 'Bold words as they\u2019re sung', when: c => c.showLyrics },
    { k: 'lyricsSize', t: 'range', label: 'Lyrics text size', min: 80, max: 160, step: 5, unit: '%', when: c => c.showLyrics },
    { t: 'note', label: 'Lyrics come from lrclib.net (a free synced-lyrics database) or, if that has none, YouTube\u2019s own caption track. Word-by-word timing is exact when the source has it and estimated from line timing otherwise.', when: c => c.showLyrics },
    { k: 'videoMode', t: 'select', label: 'Video', opts: [['hidden', 'Hidden (audio only)'], ['small', 'Small preview'], ['large', 'Large preview']], hint: 'YouTube still plays the video even when hidden.' }
  ] });
  UI.sheet.register({ id: 'p_disc', title: 'Disc', icon: 'disc', store: cfg, schema: [
    { g: 'Look' },
    { k: 'discStyle', t: 'seg', label: 'Style', opts: [['vinyl', 'Vinyl record'], ['cd', 'CD'], ['ring', 'Cover ring'], ['cover', 'Square cover']] },
    { k: 'discSize', t: 'range', label: 'Size', min: 40, max: 100, step: 5, unit: '%' },
    { k: 'labelArt', t: 'toggle', label: 'Album art on the label' },
    { k: 'grooves', t: 'range', label: 'Groove detail', min: 0, max: 100, step: 5, unit: '%', when: c => c.discStyle === 'vinyl' },
    { k: 'sheen', t: 'toggle', label: 'Light reflection' },
    { k: 'discShadow', t: 'toggle', label: 'Drop shadow' },
    { k: 'tint', t: 'toggle', label: 'Tint each song with its own colour' },
    { g: 'Motion' },
    { k: 'spin', t: 'range', label: 'Seconds per turn', min: 2, max: 20, step: 1, unit: 's', when: c => c.discStyle !== 'cover' },
    { k: 'spinDir', t: 'seg', label: 'Direction', opts: [['cw', 'Clockwise'], ['ccw', 'Anticlockwise']], when: c => c.discStyle !== 'cover' },
    { k: 'spinWhen', t: 'select', label: 'Spins', opts: [['playing', 'Only while playing'], ['always', 'Whenever a song is loaded']], when: c => c.discStyle !== 'cover' },
    { k: 'spinDown', t: 'toggle', label: 'Slow down and speed up smoothly' },
    { k: 'tonearm', t: 'toggle', label: 'Tonearm', hint: 'Lifts when paused and moves inward as the song plays.', when: c => c.discStyle === 'vinyl' || c.discStyle === 'cd' },
    { g: 'Text' },
    { k: 'titleSize', t: 'range', label: 'Title size', min: 80, max: 160, step: 5, unit: '%' },
    { k: 'marquee', t: 'toggle', label: 'Scroll long titles' },
    { k: 'cleanTitles', t: 'toggle', label: 'Tidy titles', hint: 'Removes “(Official Video)” and splits “Artist - Song”.' }
  ] });
  UI.sheet.register({ id: 'p_skip', title: 'Skipping', icon: 'scissors', store: cfg, schema: [
    { g: 'Cut the clutter' },
    { k: 'sbEnabled', t: 'toggle', label: 'Skip unwanted parts', hint: 'Uses SponsorBlock, a community database. Many popular songs have entries, but not every video does.' },
    { k: 'sbMode', t: 'seg', label: 'When one is found', opts: [['auto', 'Skip it'], ['ask', 'Ask me']], when: c => c.sbEnabled },
    { k: 'skipToast', t: 'toggle', label: 'Notify when skipping', when: c => c.sbEnabled },
    { g: 'What to skip' }
  ].concat(SB_CATS.map(c => ({ k: 'cat_' + c[0], t: 'toggle', label: c[1], when: s => s.sbEnabled }))).concat([
    { g: 'Your own trims' },
    { k: 'trimStart', t: 'range', label: 'Skip the first', min: 0, max: 60, step: 1, unit: 's', hint: 'Works on every song, even without database entries.' },
    { k: 'trimEnd', t: 'range', label: 'Skip the last', min: 0, max: 60, step: 1, unit: 's' },
    { g: 'Finding cleaner versions' },
    { k: 'preferAudio', t: 'toggle', label: 'Prefer audio versions', hint: 'Ranks “Topic” and official audio uploads above music videos with skits and intros.' },
    { t: 'note', label: 'YouTube’s own ads are not part of SponsorBlock. If YouTube inserts one, it plays as normal.' }
  ]) });
  UI.sheet.register({ id: 'p_play', title: 'Playback', icon: 'repeat', store: cfg, schema: [
    { g: 'Playback' },
    { k: 'repeat', t: 'seg', label: 'Repeat', opts: [['off', 'Off'], ['one', 'This song']] },
    { k: 'autoAdvance', t: 'toggle', label: 'Play the next result when a song ends', hint: 'Results are different matches for your search, not a playlist.' }
  ] });

  cfg.onChange((k) => {
    if (k === 'spin' || k === 'spinDir') Spin.timing();
    if (k && (k === 'sbEnabled' || k.startsWith('cat_') || k === 'trimStart' || k === 'trimEnd')) {
      if (k === 'sbEnabled' && S.track && S.raw == null) loadSegments(S.track.video_id); else buildSegs();
    }
    if (k === 'showLyrics' && S.track) { if (cfg.get('showLyrics') && !S.lyrics) loadLyrics(S.track); else el.classList.toggle('has-lyrics', !!(S.lyrics && cfg.get('showLyrics'))); }
    if (k === null && S.track) { buildSegs(); }
    Spin.timing(); paint();
  });

  /* ================================================================ HUD button */
  UI.hudButton({ id: 'plrBtn', icon: 'music', label: 'Music player', onClick: toggleCollapsed });
  window.addEventListener('keydown', e => { if (e.key === 'Escape' && S.resultsOpen) { S.resultsOpen = false; layout(); } });

  paint(); layout(); renderResults();
})();
