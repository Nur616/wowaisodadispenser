"""Visible ChatGPT website bridge for the kiosk.

Browsers (CODA_BROWSER=chrome|firefox|auto, chosen by start.sh / start.bat):
  * Chrome / Chromium / Edge  - Playwright (laptop) or the built-in DevTools driver (Termux, no pip needed)
  * Firefox                   - the built-in Marionette driver (no pip needed, works on Termux too)

How the reply is read - three layers, so a ChatGPT redesign can't silently break it:
  1. the page's own assistant-message elements
  2. a structure-free text diff: everything on the page that is new since before the prompt was sent,
     minus the prompt itself and ChatGPT's UI words
  3. a screenshot analyzer (screen_reply.py): finds the reply region in a picture of the page, crops
     ONLY that and OCRs it. Used when layers 1-2 return nothing; also decides "finished" by watching the
     pixels stop changing when no stop button can be found.
CHATGPT_CAPTURE=auto (default) | dom (never screenshot) | screenshot (screenshot only).

Other env: CHATGPT_URL, CHATGPT_HEADLESS=1|0, CHATGPT_BROWSER=<path>, CHATGPT_DRIVER=playwright|cdp,
CHATGPT_CDP_URL (attach to a running Chrome), CHATGPT_BRIDGE_URL (use a bridge on another machine).
Remote bridge server: `python chatgpt_web.py --serve`.
"""
import base64, collections, hashlib, json, logging, os, queue, shutil, socket, struct, subprocess
import sys, threading, time, urllib.parse, urllib.request

import coda_browser

log = logging.getLogger("pump_backend.chatgpt_web")
BASE_URL = os.environ.get("CHATGPT_URL", "https://chatgpt.com/")
VIEW_SIZE = (1024, 768)
# Longest wait for ChatGPT to finish a reply. Normal replies return ~2-4 s after the text stops changing;
# this is only the stuck-request ceiling. Raise it for slow "thinking" models: CHATGPT_TIMEOUT=180.
REPLY_TIMEOUT = max(20, int(os.environ.get("CHATGPT_TIMEOUT", "75")))


class ChatGPTWebError(Exception):
    pass


def is_termux():
    return coda_browser.is_termux()


def _log_path(profile_dir):
    return profile_dir.rstrip("/\\") + "_browser.log"


def log_file(profile_dir):
    try:
        os.makedirs(os.path.dirname(_log_path(profile_dir)) or ".", exist_ok=True)
        return open(_log_path(profile_dir), "wb")
    except OSError:
        return subprocess.DEVNULL


def log_tail(profile_dir, n=6):
    try:
        with open(_log_path(profile_dir), "r", errors="replace") as handle:
            lines = [l.strip() for l in handle.read().splitlines() if l.strip()]
        return ("Browser said: " + " | ".join(lines[-n:]))[:420] if lines else ""
    except OSError:
        return ""


def _headless_default():
    env = os.environ.get("CHATGPT_HEADLESS")
    if env == "1":
        return True
    if env == "0":
        return False
    return not os.environ.get("DISPLAY") and (is_termux() or sys.platform.startswith("linux"))


# ---------------------------------------------------------------- page JS
# Evaluated as: (() => { <JS_LIB> return (<expr>); })()   -> expr may use K.*
JS_LIB = r"""
const K = (() => {
  const vis = e => { if (!e) return false; const r = e.getBoundingClientRect(); return r.width > 0 && r.height > 0; };
  const inDialog = e => !!e.closest('[role=dialog]');
  const ASSIST = ['[data-message-author-role="assistant"]', 'article[data-turn="assistant"]',
                  '[data-testid^="conversation-turn"] .markdown', 'div.markdown'];
  const composer = () => {
    for (const s of ['#prompt-textarea', '[data-testid="prompt-textarea"]',
                     'div[contenteditable="true"][role="textbox"]', 'div.ProseMirror[contenteditable="true"]',
                     'div[contenteditable="true"]', 'textarea']) {
      const l = [...document.querySelectorAll(s)].filter(e => vis(e) && !inDialog(e));
      if (l.length) return l[l.length - 1];
    }
    return null;
  };
  const ctext = e => e ? ((e.tagName === 'TEXTAREA') ? e.value : (e.innerText || e.textContent || '')) : '';
  const assistants = () => { for (const s of ASSIST) { const l = document.querySelectorAll(s); if (l.length) return [...l]; } return []; };
  const stop = () => [...document.querySelectorAll('button[data-testid*="stop"], button[aria-label*="Stop"], button[title*="Stop"]')].some(vis);
  const root = () => document.querySelector('main') || document.body;
  return {
    focus() { const c = composer(); if (!c) return false; c.focus(); return true; },
    clear() { const c = composer(); if (!c) return false; c.focus();
      if (c.tagName === 'TEXTAREA') { c.select(); } else { document.execCommand('selectAll'); }
      document.execCommand('delete'); return true; },
    send() { const b = [...document.querySelectorAll('button[data-testid="send-button"], button[aria-label*="Send" i]')]
      .filter(vis).pop(); if (b && !b.disabled) { b.click(); return true; } return false; },
    dismiss() { for (const b of document.querySelectorAll('a,button')) {
      if (/^(stay logged out|continue without|not now|dismiss|close)$/i.test((b.innerText || '').trim()) && vis(b)) { b.click(); return true; } }
      return false; },
    state() { const a = assistants(); const c = composer();
      return {has: !!c, ctext: ctext(c), users: document.querySelectorAll('[data-message-author-role="user"]').length,
              n: a.length, last: a.length ? (a[a.length - 1].innerText || '').trim().slice(0, 30000) : '', stop: stop(),
              url: location.href, title: document.title}; },
    snap() { return (root().innerText || '').split('\n').map(s => s.trim()).filter(Boolean).slice(0, 6000); },
    geo(head) {                       // where things are on screen (for the screenshot analyzer)
      const r = {}, c = composer(), m = root().getBoundingClientRect();
      r.mainLeft = Math.round(m.left); r.mainRight = Math.round(m.right);
      if (c) r.replyBottom = Math.round(c.getBoundingClientRect().top);
      if (head) {
        let best = null;
        for (const e of root().querySelectorAll('div,p,span')) {
          const t = (e.innerText || '').trim().replace(/\s+/g, ' ');
          if (t.startsWith(head) && vis(e) && e !== c && !(c && c.contains(e))) { best = e; if (![...e.children].some(k => (k.innerText || '').trim().replace(/\s+/g, ' ').startsWith(head))) break; }
        }
        if (best) r.replyTop = Math.round(best.getBoundingClientRect().bottom);
      }
      r.vh = window.innerHeight; return r;
    },
    blur() { const a = document.activeElement; if (a && a.blur) a.blur(); return true; },
    toEnd() { const s = document.querySelector('main [class*="overflow-y"]') || document.scrollingElement; if (s) s.scrollTop = s.scrollHeight; return true; }
  };
})();
"""


def _try_import(name):
    try:
        __import__(name)
        return True
    except Exception:
        return False


def _norm(text):
    return "".join(str(text).split())


# ---------------------------------------------------------------- DOM text-diff reader (layer 2)
def dom_diff(lines, base_lines, prompt):
    """New page text since before sending, minus the user's own message and UI words."""
    from screen_reply import UI_LINES, is_symbol_only
    base = collections.Counter(base_lines)
    pl = [" ".join(x.lower().split()) for x in prompt.split("\n") if x.strip()]
    pset, k, out = set(pl), 0, []
    for ln in lines:
        if base[ln] > 0:
            base[ln] -= 1
            continue
        n = " ".join(ln.lower().split())
        if not n or UI_LINES.match(ln.strip()) or is_symbol_only(ln):
            continue
        if k < len(pl) and n == pl[k]:          # the user's bubble, line by line
            k += 1
            continue
        if len(n) >= 10 and n in pset:
            continue
        out.append(ln)
    return "\n".join(out).strip()


# ---------------------------------------------------------------- drivers
class PlaywrightDriver:
    headless = False

    def __init__(self, profile_dir):
        self.profile_dir = profile_dir
        self._pw = self._ctx = self.page = None

    def start(self):
        from playwright.sync_api import sync_playwright
        os.makedirs(self.profile_dir, mode=0o700, exist_ok=True)
        self._pw = sync_playwright().start()
        args = ["--no-sandbox"] if hasattr(os, "geteuid") and os.geteuid() == 0 else []
        self.headless = _headless_default()
        errors = []
        for kw in ({"channel": "chrome"}, {}):
            try:
                self._ctx = self._pw.chromium.launch_persistent_context(
                    self.profile_dir, headless=self.headless, args=args, **kw)
                break
            except Exception as exc:
                errors.append(str(exc).splitlines()[0][:150])
        if not self._ctx:
            raise ChatGPTWebError("Couldn't launch a browser. Install Google Chrome or run "
                                  "'playwright install chromium'. (%s)" % "; ".join(errors))
        self.page = self._ctx.pages[0] if self._ctx.pages else self._ctx.new_page()

    def alive(self):
        try:
            return not self.page.is_closed()
        except Exception:
            return False

    def ensure_page(self):
        if not self.alive():
            self.page = self._ctx.new_page()

    def goto(self, url):
        self.page.goto(url, wait_until="domcontentloaded", timeout=30000)

    def url(self):
        return self.page.url

    def eval(self, expr):
        return self.page.evaluate("(() => { " + JS_LIB + " return (" + expr + "); })()")

    def insert_text(self, text):
        self.page.keyboard.insert_text(text)

    def key(self, name, shift=False):
        if shift:
            self.page.keyboard.down("Shift")
        self.page.keyboard.press(name)
        if shift:
            self.page.keyboard.up("Shift")

    def sleep(self, ms):
        self.page.wait_for_timeout(ms)

    def screenshot_png(self):
        return self.page.screenshot(type="png")

    def set_view_height(self, h):
        self.page.set_viewport_size({"width": VIEW_SIZE[0], "height": int(h)})

    def close(self):
        for obj, fn in ((self._ctx, "close"), (self._pw, "stop")):
            try:
                getattr(obj, fn)()
            except Exception:
                pass


class _WS:
    """Tiny RFC6455 client (text frames only) so Termux needs no pip packages."""
    def __init__(self, url, timeout=60):
        u = urllib.parse.urlsplit(url)
        self.sock = socket.create_connection((u.hostname, u.port or 80), timeout=15)
        key = base64.b64encode(os.urandom(16)).decode()
        path = u.path + (("?" + u.query) if u.query else "")
        self.sock.sendall(("GET %s HTTP/1.1\r\nHost: %s:%s\r\nUpgrade: websocket\r\nConnection: Upgrade\r\n"
                           "Sec-WebSocket-Key: %s\r\nSec-WebSocket-Version: 13\r\n\r\n"
                           % (path, u.hostname, u.port, key)).encode())
        head = b""
        while b"\r\n\r\n" not in head:
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ChatGPTWebError("DevTools websocket closed during handshake.")
            head += chunk
        if b" 101 " not in head.split(b"\r\n")[0]:
            raise ChatGPTWebError("DevTools websocket handshake refused.")
        self.buf = head.split(b"\r\n\r\n", 1)[1]
        self.sock.settimeout(timeout)

    def _read(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ChatGPTWebError("DevTools connection closed.")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def send(self, text, opcode=1):
        data = text.encode() if isinstance(text, str) else text
        mask = os.urandom(4)
        n = len(data)
        head = bytes([0x80 | opcode])
        head += (bytes([0x80 | n]) if n < 126 else bytes([0x80 | 126]) + struct.pack(">H", n)
                 if n < 65536 else bytes([0x80 | 127]) + struct.pack(">Q", n))
        self.sock.sendall(head + mask + bytes(b ^ mask[i % 4] for i, b in enumerate(data)))

    def recv(self):
        msg = b""
        while True:
            b1, b2 = self._read(2)
            op, n = b1 & 0x0F, b2 & 0x7F
            if n == 126:
                n = struct.unpack(">H", self._read(2))[0]
            elif n == 127:
                n = struct.unpack(">Q", self._read(8))[0]
            payload = self._read(n)
            if op == 9:
                self.send(payload, 10)
            elif op == 8:
                raise ChatGPTWebError("DevTools connection closed.")
            elif op in (0, 1, 2):
                msg += payload
                if b1 & 0x80:
                    return msg.decode("utf-8", "replace")

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


_KEYCODES = {"Enter": (13, "\r"), "Backspace": (8, ""), "Tab": (9, "\t"), "Escape": (27, ""), "Delete": (46, ""),
             "ArrowLeft": (37, ""), "ArrowUp": (38, ""), "ArrowRight": (39, ""), "ArrowDown": (40, ""),
             "Home": (36, ""), "End": (35, "")}


class CDPDriver:
    """Chrome / Chromium / Edge through the DevTools protocol, with no third-party packages."""
    _KEYS = _KEYCODES

    def __init__(self, profile_dir):
        self.profile_dir = profile_dir
        self.endpoint = os.environ.get("CHATGPT_CDP_URL", "").rstrip("/")
        self.proc = None
        self.ws = None
        self._id = 0
        self.headless = False

    def _http(self, path, method="GET"):
        req = urllib.request.Request(self.endpoint + path, method=method)
        with urllib.request.urlopen(req, timeout=5) as r:
            return json.loads(r.read().decode())

    def start(self):
        if not self.endpoint:
            exe = coda_browser.find_binary("chrome")
            if not exe:
                raise ChatGPTWebError(
                    "No Chrome/Chromium found. In Termux: pkg install x11-repo && pkg install chromium. "
                    "Or choose Firefox, or set CHATGPT_BRIDGE_URL to a laptop running 'python chatgpt_web.py --serve'.")
            self.headless = _headless_default()
            os.makedirs(self.profile_dir, mode=0o700, exist_ok=True)
            port = int(os.environ.get("CHATGPT_CDP_PORT", "9223"))
            cmd = [exe, "--remote-debugging-port=%d" % port, "--user-data-dir=" + self.profile_dir,
                   "--no-first-run", "--no-default-browser-check", "--remote-allow-origins=*",
                   "--disable-blink-features=AutomationControlled", "--window-size=%d,%d" % VIEW_SIZE]
            if is_termux() or (hasattr(os, "geteuid") and os.geteuid() == 0):
                cmd.append("--no-sandbox")
            if self.headless or is_termux():             # phones/TVs: no GPU process, tiny /dev/shm
                cmd += ["--disable-gpu", "--disable-dev-shm-usage", "--disable-extensions", "--mute-audio"]
            if self.headless:
                cmd.append("--headless=new")
            cmd.append("about:blank")
            self.endpoint = "http://127.0.0.1:%d" % port
            try:
                self._http("/json/version")          # reuse a browser we already started
            except Exception:
                self.proc = subprocess.Popen(cmd, stdout=log_file(self.profile_dir), stderr=subprocess.STDOUT)
        for _ in range(60):
            try:
                self._http("/json/version")
                break
            except Exception:
                if self.proc and self.proc.poll() is not None:
                    raise ChatGPTWebError("The browser exited immediately (code %s). %s" % (self.proc.returncode, log_tail(self.profile_dir)))
                time.sleep(0.5)
        else:
            raise ChatGPTWebError("The browser's DevTools port never came up. %s" % log_tail(self.profile_dir))
        self._attach()

    def _attach(self):
        pages = [t for t in self._http("/json") if t.get("type") == "page"]
        target = pages[0] if pages else self._http("/json/new?about:blank", "PUT")
        self.ws = _WS(target["webSocketDebuggerUrl"])
        self.call("Page.enable")
        self.set_view_height(VIEW_SIZE[1])
        try:
            ua = self.call("Browser.getVersion").get("userAgent", "").replace("HeadlessChrome", "Chrome")
            if ua:
                self.call("Emulation.setUserAgentOverride", userAgent=ua)
        except ChatGPTWebError:
            pass

    def call(self, method, **params):
        self._id += 1
        mid = self._id
        self.ws.send(json.dumps({"id": mid, "method": method, "params": params}))
        while True:
            msg = json.loads(self.ws.recv())
            if msg.get("id") == mid:
                if "error" in msg:
                    raise ChatGPTWebError(msg["error"].get("message", "DevTools error"))
                return msg.get("result", {})

    def alive(self):
        try:
            self.call("Runtime.evaluate", expression="1")
            return True
        except Exception:
            return False

    def ensure_page(self):
        if not self.alive():
            if self.ws:
                self.ws.close()
            self._attach()

    def goto(self, url):
        self.call("Page.navigate", url=url)
        for _ in range(60):
            time.sleep(0.25)
            try:
                if self.eval("document.readyState") in ("interactive", "complete"):
                    return
            except ChatGPTWebError:
                pass

    def url(self):
        return self.eval("location.href")

    def eval(self, expr):
        r = self.call("Runtime.evaluate", expression="(() => { " + JS_LIB + " return (" + expr + "); })()",
                      returnByValue=True, awaitPromise=True)
        if r.get("exceptionDetails"):
            raise ChatGPTWebError("Page script error.")
        return r.get("result", {}).get("value")

    def insert_text(self, text):
        self.call("Input.insertText", text=text)

    def key(self, name, shift=False):
        code, text = _KEYCODES[name]
        base = dict(key=name, code=name, windowsVirtualKeyCode=code, modifiers=8 if shift else 0)
        self.call("Input.dispatchKeyEvent", type="rawKeyDown", **base)
        if text:
            self.call("Input.dispatchKeyEvent", type="char", text=text, **base)
        self.call("Input.dispatchKeyEvent", type="keyUp", **base)

    def sleep(self, ms):
        time.sleep(ms / 1000.0)

    # --- pictures and the remote "sign-in view"
    def screenshot(self):                                   # small JPEG for the live view
        return base64.b64decode(self.call("Page.captureScreenshot", format="jpeg", quality=55)["data"])

    def screenshot_png(self):                               # lossless, for the analyzer
        return base64.b64decode(self.call("Page.captureScreenshot", format="png")["data"])

    def set_view_height(self, h):
        self.call("Emulation.setDeviceMetricsOverride", width=VIEW_SIZE[0], height=int(h), deviceScaleFactor=1, mobile=False)

    def click(self, x, y):
        for kind in ("mouseMoved", "mousePressed", "mouseReleased"):
            self.call("Input.dispatchMouseEvent", type=kind, x=x, y=y, button="left" if kind != "mouseMoved" else "none",
                      buttons=1 if kind == "mousePressed" else 0, clickCount=1 if kind != "mouseMoved" else 0)

    def scroll(self, x, y, dy):
        self.call("Input.dispatchMouseEvent", type="mouseWheel", x=x, y=y, deltaX=0, deltaY=dy)

    def browser_ocr(self, png):
        """OCR inside a scratch tab with tesseract.js (needs internet, no installs). Used as a last resort."""
        target = self._http("/json/new?about:blank", "PUT")
        ws = _WS(target["webSocketDebuggerUrl"], timeout=120)
        try:
            js = ("(async()=>{if(!window.Tesseract){await new Promise((ok,no)=>{const s=document.createElement('script');"
                  "s.src='https://cdn.jsdelivr.net/npm/tesseract.js@5.1.1/dist/tesseract.min.js';s.onload=ok;"
                  "s.onerror=()=>no(new Error('cdn'));document.head.appendChild(s);});}"
                  "const r=await Tesseract.recognize('data:image/png;base64," + base64.b64encode(png).decode() + "','eng');"
                  "return r.data.text;})()")
            ws.send(json.dumps({"id": 1, "method": "Runtime.evaluate",
                                "params": {"expression": js, "awaitPromise": True, "returnByValue": True}}))
            while True:
                msg = json.loads(ws.recv())
                if msg.get("id") == 1:
                    if "error" in msg or msg.get("result", {}).get("exceptionDetails"):
                        raise ChatGPTWebError("browser OCR failed")
                    return msg["result"]["result"].get("value", "")
        finally:
            ws.close()
            try:
                self._http("/json/close/" + target["id"])
            except Exception:
                pass

    def close(self):
        if self.ws:
            self.ws.close()
        if self.proc:
            self.proc.terminate()


# --- Firefox -------------------------------------------------------------------
_FFKEYS = {"Enter": "\ue007", "Backspace": "\ue003", "Tab": "\ue004", "Escape": "\ue00c", "Delete": "\ue017",
           "ArrowLeft": "\ue012", "ArrowUp": "\ue013", "ArrowRight": "\ue014", "ArrowDown": "\ue015",
           "Home": "\ue011", "End": "\ue010", "Shift": "\ue008"}


class _Marionette:
    """Minimal Marionette (Firefox remote protocol) client: length-prefixed JSON over a local socket."""
    def __init__(self, port, timeout=90):
        self.sock = socket.create_connection(("127.0.0.1", port), timeout=15)
        self.sock.settimeout(timeout)
        self.buf = b""
        self.id = 0
        self._msg()                                          # greeting {"applicationType":"gecko",...}
        self.call("WebDriver:NewSession", {"capabilities": {}})

    def _read(self, n):
        while len(self.buf) < n:
            chunk = self.sock.recv(65536)
            if not chunk:
                raise ChatGPTWebError("Firefox closed the Marionette connection.")
            self.buf += chunk
        out, self.buf = self.buf[:n], self.buf[n:]
        return out

    def _msg(self):
        head = b""
        while True:
            c = self._read(1)
            if c == b":":
                break
            head += c
        return json.loads(self._read(int(head)).decode("utf-8", "replace"))

    def call(self, name, params=None):
        self.id += 1
        body = json.dumps([0, self.id, name, params or {}]).encode()
        self.sock.sendall(str(len(body)).encode() + b":" + body)
        while True:
            m = self._msg()
            if isinstance(m, list) and len(m) == 4 and m[0] == 1 and m[1] == self.id:
                if m[2]:
                    raise ChatGPTWebError("Firefox: " + str(m[2].get("message", m[2].get("error", "error")))[:160])
                return m[3]

    def close(self):
        try:
            self.sock.close()
        except Exception:
            pass


class FirefoxDriver:
    """Mozilla Firefox driven over Marionette; works with the system Firefox, no Playwright needed."""
    _KEYS = _KEYCODES

    def __init__(self, profile_dir):
        self.profile_dir = profile_dir
        self.proc = None
        self.m = None
        self.headless = False
        self.port = int(os.environ.get("CHATGPT_MARIONETTE_PORT", "2829"))

    def start(self):
        exe = coda_browser.find_binary("firefox")
        if not exe:
            raise ChatGPTWebError("Firefox not found. Install it (Termux: pkg install x11-repo && pkg install firefox; "
                                  "Debian/Ubuntu: sudo apt install firefox) or choose Chrome.")
        self.headless = _headless_default()
        os.makedirs(self.profile_dir, mode=0o700, exist_ok=True)
        prefs = {"marionette.port": self.port, "browser.shell.checkDefaultBrowser": False,
                 "browser.startup.homepage_override.mstone": "ignore", "startup.homepage_welcome_url": "",
                 "browser.aboutwelcome.enabled": False, "datareporting.policy.dataSubmissionEnabled": False,
                 "browser.tabs.warnOnClose": False, "toolkit.telemetry.reportingpolicy.firstRun": False,
                 "browser.download.panel.shown": True, "signon.rememberSignons": False}
        with open(os.path.join(self.profile_dir, "user.js"), "w") as f:
            for k, v in prefs.items():
                f.write("user_pref(%s, %s);\n" % (json.dumps(k), json.dumps(v)))
        cmd = [exe, "-marionette", "-no-remote", "-profile", self.profile_dir]
        if self.headless:
            cmd += ["-headless"]
        cmd += ["-width", str(VIEW_SIZE[0]), "-height", str(VIEW_SIZE[1]), "about:blank"]
        env = dict(os.environ, MOZ_CRASHREPORTER_DISABLE="1")
        if self.headless:
            env["MOZ_HEADLESS"] = "1"
        self.proc = subprocess.Popen(cmd, stdout=log_file(self.profile_dir), stderr=subprocess.STDOUT, env=env)
        for _ in range(80):
            try:
                self.m = _Marionette(self.port)
                break
            except (OSError, ChatGPTWebError):
                if self.proc.poll() is not None:
                    raise ChatGPTWebError("Firefox exited immediately (code %s). %s" % (self.proc.returncode, log_tail(self.profile_dir)))
                time.sleep(0.5)
        else:
            raise ChatGPTWebError("Firefox's Marionette port never came up (is another Firefox using this profile?). %s" % log_tail(self.profile_dir))
        self.set_view_height(VIEW_SIZE[1])

    def alive(self):
        try:
            self.m.call("WebDriver:GetCurrentURL")
            return True
        except Exception:
            return False

    def ensure_page(self):
        if not self.alive():
            raise ChatGPTWebError("The Firefox window was closed. Press 'Open ChatGPT browser' again.")

    def goto(self, url):
        self.m.call("WebDriver:Navigate", {"url": url})

    def url(self):
        return self.m.call("WebDriver:GetCurrentURL").get("value", "")

    def eval(self, expr):
        script = JS_LIB + "\nreturn (" + expr + ");"
        return self.m.call("WebDriver:ExecuteScript", {"script": script, "args": []}).get("value")

    def insert_text(self, text):
        ok = self.m.call("WebDriver:ExecuteScript", {"script": "return document.execCommand('insertText', false, arguments[0]);",
                                                     "args": [text]}).get("value")
        if not ok:                                           # fall back to real key presses
            self._actions([{"type": "key", "id": "kb", "actions": [a for ch in text for a in
                           ({"type": "keyDown", "value": ch}, {"type": "keyUp", "value": ch})]}])

    def _actions(self, actions):
        self.m.call("WebDriver:PerformActions", {"actions": actions})
        try:
            self.m.call("WebDriver:ReleaseActions")
        except ChatGPTWebError:
            pass

    def key(self, name, shift=False):
        k = _FFKEYS[name]
        acts = []
        if shift:
            acts.append({"type": "keyDown", "value": _FFKEYS["Shift"]})
        acts += [{"type": "keyDown", "value": k}, {"type": "keyUp", "value": k}]
        if shift:
            acts.append({"type": "keyUp", "value": _FFKEYS["Shift"]})
        self._actions([{"type": "key", "id": "kb", "actions": acts}])

    def sleep(self, ms):
        time.sleep(ms / 1000.0)

    def screenshot_png(self):
        return base64.b64decode(self.m.call("WebDriver:TakeScreenshot", {"full": False, "hash": False})["value"])

    screenshot = screenshot_png                              # the live view accepts PNG too

    def set_view_height(self, h):
        try:
            self.m.call("WebDriver:SetWindowRect", {"width": VIEW_SIZE[0], "height": int(h)})
        except ChatGPTWebError:
            pass

    def click(self, x, y):
        self._actions([{"type": "pointer", "id": "mouse", "parameters": {"pointerType": "mouse"}, "actions": [
            {"type": "pointerMove", "x": x, "y": y, "origin": "viewport"}, {"type": "pointerDown", "button": 0},
            {"type": "pointerUp", "button": 0}]}])

    def scroll(self, x, y, dy):
        self.m.call("WebDriver:ExecuteScript", {"script": "window.scrollBy(0, arguments[0]);", "args": [dy]})

    def close(self):
        if self.m:
            try:
                self.m.call("Marionette:Quit")
            except Exception:
                pass
            self.m.close()
        if self.proc:
            try:
                self.proc.terminate()
            except Exception:
                pass


def _make_driver(profile_dir):
    kind = coda_browser.preferred()
    if kind == "firefox":
        return FirefoxDriver(profile_dir.rstrip("/\\") + "_firefox")
    choice = os.environ.get("CHATGPT_DRIVER", "auto").lower()
    if choice == "cdp" or (choice == "auto" and (is_termux() or os.environ.get("CHATGPT_CDP_URL"))):
        return CDPDriver(profile_dir)
    if choice == "playwright":
        return PlaywrightDriver(profile_dir)
    try:
        import playwright.sync_api  # noqa: F401
        return PlaywrightDriver(profile_dir)
    except ImportError:
        return CDPDriver(profile_dir)


# ---------------------------------------------------------------- session
class ChatGPTWebSession:
    def __init__(self, profile_dir):
        self.profile_dir = profile_dir
        self._jobs = queue.Queue()
        self._start_lock = threading.Lock()
        self._ready = threading.Event()
        self._thread = None
        self._startup_error = None
        self._driver = None
        self._open = False
        self.driver_name = ""
        self.last_method = ""

    # -- lifecycle
    def start(self):
        with self._start_lock:
            if self._thread is None or not self._thread.is_alive():
                self._ready.clear()
                self._startup_error = None
                self._thread = threading.Thread(target=self._run, name="chatgpt-web", daemon=True)
                self._thread.start()
        if not self._ready.wait(100):
            raise ChatGPTWebError("Timed out while opening the ChatGPT browser.")
        if self._startup_error:
            raise ChatGPTWebError(self._startup_error)

    def _run(self):
        drv = None
        try:
            drv = _make_driver(self.profile_dir)
            self.driver_name = type(drv).__name__.replace("Driver", "").lower()
            drv.start()
            self._driver = drv
            if not (drv.url() or "").startswith("http") or ("chatgpt" not in (drv.url() or "") and BASE_URL.startswith("https://chatgpt")):
                drv.goto(BASE_URL)
            self._open = True
            self._ready.set()
            while True:
                job = self._jobs.get()
                if job is None:
                    break
                try:
                    job(drv)
                except Exception:
                    log.exception("Unhandled ChatGPT browser job failure")
        except ChatGPTWebError as exc:
            self._startup_error = str(exc)
            self._ready.set()
        except Exception as exc:
            self._startup_error = ("Couldn't open the ChatGPT browser (%s). It needs a graphical desktop "
                                   "(or CHATGPT_HEADLESS=1 / CHATGPT_BRIDGE_URL)." % str(exc).splitlines()[0][:200])
            self._ready.set()
        finally:
            self._open = False
            self._driver = None
            if drv:
                drv.close()

    def _run_job(self, fn, timeout):
        self.start()
        out = queue.Queue(maxsize=1)

        def job(drv):
            try:
                drv.ensure_page()
                out.put(("ok", fn(drv)))
            except Exception as exc:
                out.put(("err", exc))
        self._jobs.put(job)
        try:
            kind, value = out.get(timeout=timeout)
        except queue.Empty:
            raise ChatGPTWebError("The ChatGPT browser did not respond.")
        if kind == "err":
            raise value if isinstance(value, ChatGPTWebError) else ChatGPTWebError(str(value).splitlines()[0][:200])
        return value

    def open(self):
        def inspect(drv):
            if "chatgpt" not in (drv.url() or "") and BASE_URL.startswith("https://chatgpt"):
                drv.goto(BASE_URL)
            self._open = True
            st = drv.eval("K.state()")
            return {"url": st["url"], "title": st["title"], "driver": self.driver_name,
                    "browser": coda_browser.preferred(), "headless": bool(getattr(drv, "headless", False)),
                    "view": hasattr(drv, "screenshot")}
        return self._run_job(inspect, 60)

    def view_frame(self):
        def grab(drv):
            if not hasattr(drv, "screenshot"):
                raise ChatGPTWebError("The sign-in view needs the built-in browser driver (the default on Termux).")
            return drv.screenshot()
        return self._run_job(grab, 25)

    def view_input(self, ev):
        def act(drv):
            if not hasattr(drv, "screenshot"):
                raise ChatGPTWebError("The sign-in view needs the built-in browser driver.")
            kind = ev.get("type")
            x = int(max(0, min(1, float(ev.get("x", 0)))) * VIEW_SIZE[0])
            y = int(max(0, min(1, float(ev.get("y", 0)))) * VIEW_SIZE[1])
            if kind == "click":
                drv.click(x, y)
            elif kind == "scroll":
                drv.scroll(x, y, max(-1200, min(1200, float(ev.get("dy", 0)))))
            elif kind == "text":
                drv.insert_text(str(ev.get("text", ""))[:500])
            elif kind == "key" and ev.get("key") in _KEYCODES:
                drv.key(ev["key"], bool(ev.get("shift")))
            return True
        return self._run_job(act, 15)

    def status(self):
        alive = bool(self._driver and self._open and self._driver.alive())
        return {"browser_open": alive, "driver": self.driver_name, "termux": is_termux(),
                "browser": coda_browser.preferred(), "last_reply_method": self.last_method}

    def diagnose(self, send_test=True):
        """Step-by-step self-check: shows exactly where ChatGPT integration breaks on THIS device."""
        import re as _re
        steps = []

        def step(name, ok, detail=""):
            steps.append({"name": name, "ok": bool(ok), "detail": str(detail)[:400]})
            return ok
        kind = coda_browser.preferred()
        exe = coda_browser.find_binary("firefox" if kind == "firefox" else "chrome")
        step("Browser choice", True, "%s (%s)" % (kind, exe or "binary not found"))
        step("Display", True, "headless (no screen needed)" if _headless_default() else "visible window")
        try:
            self.start()
            step("Browser started", True, "driver: " + self.driver_name)
        except ChatGPTWebError as exc:
            step("Browser started", False, exc)
            return steps
        try:
            def look(drv):
                drv.goto(BASE_URL)
                drv.sleep(2500)
                st = drv.eval("K.state()")
                lines = drv.eval("K.snap()") or []
                return st, " ".join(lines)[:3000]
            st, text = self._run_job(look, 60)
            step("ChatGPT page loaded", True, "%s - %s" % (st.get("url"), st.get("title")))
            blocked = _re.search(r"verify you are human|just a moment|checking your browser|cloudflare|unusual activity", text, _re.I)
            login = _re.search(r"\b(log in|sign up|welcome back)\b", text, _re.I) and not st.get("has")
            if blocked:
                step("Bot check", False, "ChatGPT/Cloudflare is showing a human check. Open the sign-in view, solve it once, or use the laptop bridge.")
            elif login:
                step("Signed in", False, "Not signed in. Use 'Show ChatGPT sign-in view' and log in once.")
            else:
                step("Message box found", bool(st.get("has")), "ready to type" if st.get("has") else "no message box on the page")
            if not st.get("has"):
                return steps
        except ChatGPTWebError as exc:
            step("ChatGPT page loaded", False, exc)
            return steps
        try:
            png = self._run_job(lambda d: d.screenshot_png(), 25)
            step("Screenshot", len(png) > 1000, "%d KB" % (len(png) // 1024))
        except Exception as exc:
            step("Screenshot", False, exc)
        try:
            import screen_reply
            engines = [n for n, ok in (("rapidocr", _try_import("rapidocr_onnxruntime")), ("tesseract", bool(shutil.which("tesseract")))) if ok]
            step("OCR fallback", True, ", ".join(engines) if engines else "none installed (in-browser OCR needs internet; Termux: pkg install tesseract)")
        except Exception as exc:
            step("OCR fallback", False, exc)
        if send_test:
            t0 = time.monotonic()
            try:
                reply = self.complete("Reply with exactly one word: OK")
                step("Test question", True, "reply %r via %s in %.0fs" % (reply[:40], self.last_method or "?", time.monotonic() - t0))
            except ChatGPTWebError as exc:
                step("Test question", False, exc)
        return steps

    # -- one request
    @staticmethod
    def _type(drv, prompt):
        drv.eval("K.clear()")
        drv.sleep(120)
        for i, line in enumerate(prompt.replace("\r", "").split("\n")):
            if i:
                drv.key("Enter", shift=True)      # newline, never submit
            if line:
                drv.insert_text(line)
        drv.sleep(200)

    def _screenshot_reply(self, drv, prompt, base_height=VIEW_SIZE[1]):
        """Layer 3: look at the page, cut out ONLY the reply, OCR it."""
        import screen_reply
        head = " ".join(prompt.split())[:40]
        tall = hasattr(drv, "set_view_height")
        try:
            if tall:
                drv.set_view_height(2400)            # room for long replies in a single picture
                drv.sleep(900)
            try:
                drv.eval("K.toEnd()")
                drv.sleep(300)
                hints = {k: v for k, v in (drv.eval("K.geo(%s)" % json.dumps(head)) or {}).items() if v is not None}
            except ChatGPTWebError:
                hints = {}
            png = drv.screenshot_png()
        finally:
            if tall:
                drv.set_view_height(base_height)
        extra = getattr(drv, "browser_ocr", None)
        dbg = os.environ.get("CHATGPT_DEBUG_DIR")
        try:
            res = screen_reply.analyze(png, hints, prompt, extra)
        finally:
            if dbg:                                  # keep the evidence when something looks wrong
                os.makedirs(dbg, exist_ok=True)
                open(os.path.join(dbg, "screenshot.png"), "wb").write(png)
                open(os.path.join(dbg, "hints.json"), "w").write(json.dumps(hints))
        if dbg:
            open(os.path.join(dbg, "crop.png"), "wb").write(res["crop_png"])
        log.info("ChatGPT reply read from a screenshot (%s, %d lines)", res["engine"], res["info"]["lines"])
        return res["text"]

    def _submit_and_watch(self, drv, prompt, on_text, cancelled):
        mode = os.environ.get("CHATGPT_CAPTURE", "auto").lower()

        def check():
            if cancelled.is_set():
                raise ChatGPTWebError("ChatGPT request was cancelled.")
        # 1. brand-new chat via a real navigation: a freshly mounted composer every time
        drv.goto(BASE_URL)
        deadline = time.monotonic() + 40
        while True:
            check()
            st = drv.eval("K.state()")
            if st["has"]:
                break
            if time.monotonic() > deadline:
                raise ChatGPTWebError("Open ChatGPT in the browser and sign in or choose any available guest "
                                      "mode (complete any checks), then try again.")
            drv.eval("K.dismiss()")
            drv.sleep(400)
        drv.sleep(500)
        st = drv.eval("K.state()")
        n0, last0 = st["n"], st["last"]
        base_lines = drv.eval("K.snap()") or []
        # 2. type (multi-line safe) and verify; retry once flattened to one line
        text = prompt.strip()
        for attempt in (text, " ".join(text.split())):
            drv.eval("K.focus()")
            self._type(drv, attempt)
            if _norm(drv.eval("K.state()")["ctext"]) == _norm(attempt):
                break
        else:
            raise ChatGPTWebError("Couldn't type into the ChatGPT box. Check the browser window and retry.")
        # 3. send
        base_users = drv.eval("K.state()")["users"]
        sent = False
        for _ in range(25):
            check()
            if drv.eval("K.send()"):
                sent = True
                break
            drv.sleep(200)
        if not sent:
            drv.eval("K.focus()")
            drv.key("Enter")
        confirm = time.monotonic() + 8
        while time.monotonic() < confirm:
            check()
            st = drv.eval("K.state()")
            if st["users"] > base_users or not st["ctext"].strip():
                break
            drv.sleep(200)
        else:
            raise ChatGPTWebError("ChatGPT did not accept the prompt. Sign in (or pick a guest option) in the "
                                  "ChatGPT browser, complete any checks, then retry.")
        # 4. watch the reply (drop focus so the blinking caret doesn't look like page activity)
        drv.eval("K.blur()")
        started = last_change = time.monotonic()
        best, method, seen_stop = "", "", False
        last_hash, same, shot_t, changed = None, 0, 0.0, False
        while time.monotonic() - started < REPLY_TIMEOUT:
            check()
            drv.sleep(350)
            now = time.monotonic()
            st = drv.eval("K.state()")
            seen_stop = seen_stop or bool(st["stop"])
            text, how = "", ""
            if mode != "screenshot":
                if st["n"] > n0 or (st["last"] and st["last"] != last0):
                    text, how = st["last"], "dom"                            # layer 1
                else:
                    text, how = dom_diff(drv.eval("K.snap()") or [], base_lines, prompt), "dom-diff"   # layer 2
            if text and text != best:
                best, method, last_change = text, how, now
                on_text(best)
            if best:
                need = 1.6 if (seen_stop or method == "dom") else 3.5
                if now - last_change >= need and not st["stop"]:
                    self.last_method = method
                    return best
            elif mode != "dom" and now - shot_t >= 2.0:
                # nothing readable in the page text: watch the pixels to know when ChatGPT has finished
                shot_t = now
                try:
                    drv.eval("K.blur()")
                    h = hashlib.md5(drv.screenshot_png()).hexdigest()
                except ChatGPTWebError:
                    continue
                if last_hash is not None and h != last_hash:
                    changed, same = True, 0
                elif last_hash is not None:
                    same += 1
                last_hash = h
                if changed and same >= 3 and now - started > 8 and not st["stop"]:
                    break
        if best:
            self.last_method = method
            return best
        if mode != "dom":                                                  # layer 3
            try:
                reply = self._screenshot_reply(drv, prompt)
                self.last_method = "screenshot"
                on_text(reply)
                return reply
            except Exception as exc:
                log.warning("Screenshot reader failed: %s", exc)
                raise ChatGPTWebError("ChatGPT replied but the reply couldn't be read (%s). Install tesseract "
                                      "(Termux: pkg install tesseract) or check the ChatGPT window." % str(exc)[:120])
        raise ChatGPTWebError("ChatGPT didn't return a visible reply in time (CHATGPT_TIMEOUT=%ds). Check the browser." % REPLY_TIMEOUT)

    def stream(self, prompt, timeout=None):
        timeout = timeout or (REPLY_TIMEOUT + 45)
        self.start()
        events = queue.Queue()
        cancelled = threading.Event()

        def job(drv):
            try:
                drv.ensure_page()
                events.put(("done", self._submit_and_watch(
                    drv, prompt, lambda t: events.put(("text", t)), cancelled)))
            except ChatGPTWebError as exc:
                events.put(("error", str(exc)))
            except Exception as exc:
                events.put(("error", "ChatGPT browser request failed (%s)." % str(exc).splitlines()[0][:180]))
        self._jobs.put(job)
        started = time.monotonic()
        try:
            while time.monotonic() - started < timeout:
                try:
                    kind, value = events.get(timeout=0.5)
                except queue.Empty:
                    continue
                if kind == "text":
                    yield value
                elif kind == "error":
                    raise ChatGPTWebError(value)
                else:
                    return
            raise ChatGPTWebError("ChatGPT took too long to respond. Check the browser and retry.")
        finally:
            cancelled.set()

    def complete(self, prompt):
        reply = ""
        for reply in self.stream(prompt):
            pass
        if not reply.strip():
            raise ChatGPTWebError("ChatGPT returned an empty response.")
        return reply.strip()


# ---------------------------------------------------------------- remote bridge
class ChatGPTBridgeClient:
    """Same interface as ChatGPTWebSession, but talks to `chatgpt_web.py --serve` elsewhere."""
    def __init__(self, base):
        self.base = base.rstrip("/")
        self.driver_name = "bridge"

    def _req(self, path, body=None, timeout=15):
        data = json.dumps(body).encode() if body is not None else None
        req = urllib.request.Request(self.base + path, data=data, headers={"Content-Type": "application/json"})
        try:
            return urllib.request.urlopen(req, timeout=timeout)
        except Exception as exc:
            raise ChatGPTWebError("ChatGPT bridge at %s is unreachable (%s)." % (self.base, exc))

    def open(self):
        return json.loads(self._req("/open", {}, 60).read().decode())

    def status(self):
        try:
            st = json.loads(self._req("/status", timeout=4).read().decode())
        except ChatGPTWebError:
            return {"browser_open": False, "driver": "bridge", "termux": is_termux()}
        st["driver"] = "bridge"
        return st

    def view_frame(self):
        raise ChatGPTWebError("The sign-in view isn't available through a remote bridge.")

    view_input = lambda self, ev: self.view_frame()

    def diagnose(self, send_test=True):
        st = self.status()
        return [{"name": "Remote bridge", "ok": bool(st.get("browser_open")), "detail": self.base}]

    def stream(self, prompt, timeout=None):
        timeout = timeout or (REPLY_TIMEOUT + 45)
        resp = self._req("/stream", {"prompt": prompt}, timeout)
        for raw in resp:
            line = raw.decode("utf-8", "replace").strip()
            if not line.startswith("data:"):
                continue
            ev = json.loads(line[5:])
            if "error" in ev:
                raise ChatGPTWebError(ev["error"])
            if ev.get("done"):
                return
            yield ev["text"]

    def complete(self, prompt):
        reply = ""
        for reply in self.stream(prompt):
            pass
        if not reply.strip():
            raise ChatGPTWebError("ChatGPT returned an empty response.")
        return reply.strip()


def create_session(profile_dir):
    bridge = os.environ.get("CHATGPT_BRIDGE_URL", "").strip()
    return ChatGPTBridgeClient(bridge) if bridge else ChatGPTWebSession(profile_dir)


def serve(port=5006, profile_dir=None):
    from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
    session = ChatGPTWebSession(profile_dir or os.path.join(os.path.expanduser("~"), ".chatgpt_bridge_profile"))
    token = os.environ.get("CHATGPT_BRIDGE_TOKEN", "")

    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _ok(self):
            return not token or self.headers.get("X-Bridge-Token") == token

        def _json(self, code, obj):
            body = json.dumps(obj).encode()
            self.send_response(code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def do_GET(self):
            self._json(200, session.status()) if self._ok() else self._json(403, {"error": "token"})

        def do_POST(self):
            if not self._ok():
                return self._json(403, {"error": "token"})
            n = int(self.headers.get("Content-Length") or 0)
            body = json.loads(self.rfile.read(n) or b"{}")
            if self.path == "/open":
                try:
                    return self._json(200, session.open())
                except ChatGPTWebError as exc:
                    return self._json(503, {"error": str(exc)})
            self.send_response(200)
            self.send_header("Content-Type", "text/event-stream")
            self.end_headers()
            try:
                for text in session.stream(body.get("prompt", "")):
                    self.wfile.write(("data: " + json.dumps({"text": text}) + "\n\n").encode())
                    self.wfile.flush()
                self.wfile.write(b'data: {"done": true}\n\n')
            except ChatGPTWebError as exc:
                self.wfile.write(("data: " + json.dumps({"error": str(exc)}) + "\n\n").encode())
            except OSError:
                pass

    print("ChatGPT bridge on 0.0.0.0:%d (set CHATGPT_BRIDGE_URL=http://<this-ip>:%d on the robot)" % (port, port))
    ThreadingHTTPServer(("0.0.0.0", port), H).serve_forever()


if __name__ == "__main__":
    if "--serve" in sys.argv:
        serve(int(os.environ.get("CHATGPT_BRIDGE_PORT", "5006")))
    else:
        print(__doc__)
