#!/data/data/com.termux/files/usr/bin/bash
# One-shot installer for running the robot fully inside Termux.
#
#   bash termux_setup.sh              core only; asks a y/n question per extra (first run)
#   bash termux_setup.sh --core-only  core only, never ask
#   bash termux_setup.sh --ask-extras ask the y/n questions again
#   bash termux_setup.sh --chatgpt    + Chromium/Firefox for the ChatGPT website provider
#   bash termux_setup.sh --usb        + real Arduino over USB (termux-api + libusb)
#   bash termux_setup.sh --jarvis     + the Jarvis voice agent's packages
#   bash termux_setup.sh --all        everything
#   bash termux_setup.sh --upgrade    also run 'pkg upgrade' (slow; skipped by default)
#
# Safe to re-run. Nothing heavy is downloaded unless you say yes.
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

EXTRAS=""
ASK_EXTRAS=0
UPGRADE=0
for a in "$@"; do
  case "$a" in
    --chatgpt|--browser) EXTRAS="$EXTRAS,browser" ;;
    --usb) EXTRAS="$EXTRAS,usb" ;;
    --jarvis|--voice) EXTRAS="$EXTRAS,jarvis" ;;
    --imaging|--ocr) EXTRAS="$EXTRAS,imaging" ;;
    --all) EXTRAS="all" ;;
    --core-only|--no-extras) EXTRAS="none" ;;
    --ask-extras) ASK_EXTRAS=1 ;;
    --upgrade) UPGRADE=1 ;;
    -h|--help) sed -n 2,13p "$0"; exit 0 ;;
    *) echo "Unknown option: $a"; exit 1 ;;
  esac
done

if [ -z "${TERMUX_VERSION:-}" ] && [[ "${PREFIX:-}" != *com.termux* ]]; then
  echo "This script is for Termux on Android."; exit 1
fi

echo "==> Updating the package list"
pkg update -y || echo "   (package list update failed; continuing with what is cached)"

if [ "$UPGRADE" = 1 ]; then
  echo "==> Upgrading installed packages (this can take a while)"
  pkg upgrade -y || echo "   (upgrade failed; continuing)"
else
  echo "   Skipping 'pkg upgrade' (pass --upgrade if you want it)."
fi

echo "==> Core packages"
pkg install -y python git unzip curl

echo "==> Python virtualenv + core libraries"
cd "$DIR"
DEPS=""
if [ -n "$EXTRAS" ]; then
  DEPS="--extras $EXTRAS"
fi
if [ "$ASK_EXTRAS" = 1 ]; then
  DEPS="$DEPS --ask-extras"
fi
# shellcheck disable=SC2086
bash start.sh setup $DEPS

echo "==> Creating the 'coda' launcher"
mkdir -p "$HOME/bin"
cat > "$HOME/bin/coda" <<LAUNCH
#!/data/data/com.termux/files/usr/bin/bash
command -v termux-wake-lock >/dev/null 2>&1 && termux-wake-lock
cd "$DIR" && exec bash start.sh "\$@"
LAUNCH
chmod +x "$HOME/bin/coda"
case ":$PATH:" in *":$HOME/bin:"*) ;; *)
  grep -q 'HOME/bin' "$HOME/.bashrc" 2>/dev/null || echo 'export PATH="$HOME/bin:$PATH"' >> "$HOME/.bashrc"
  export PATH="$HOME/bin:$PATH" ;;
esac

echo
echo "Done. Start the robot with:   coda          (simulated Arduino)"
echo "                              coda termux   (real Arduino over USB)"
echo "Change optional libraries:    coda setup --ask-extras"
echo "Then open http://localhost:5005 in the device's browser."
