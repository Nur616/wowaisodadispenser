"""Serial reply correlation for the pump controller link.

The Arduino link is shared by two kinds of traffic:

* pump commands (FIRE / START / STOP / STOPALL) that must see their own reply
* the LCD display loop, which sends PING and LCD... commands

The original code drained one shared queue and returned whatever line arrived
next.  A late PONG or an ``ERR unknown_command`` meant for the display could
therefore be reported as a pump failure even though the pump had started.

This module keeps that policy in one place:

* ``BusyGate`` lets pump work claim the link so the display loop stops issuing
  new commands before a pump command waits for the lock.
* ``read_matching`` skips unsolicited lines (PONG, EVENT, DONE, ...) and waits
  for a line the caller actually accepts.
* ``classify`` turns a raw reply into a small, stable result the API can expose.

No hardware is required to test any of this.
"""

from __future__ import annotations

import queue
import threading
import time

# Lines the firmware emits on its own schedule, not as the answer to a command.
UNSOLICITED_PREFIXES = (
    "PONG",
    "EVENT",
    "DONE",
    "STATE",
    "READY",
    "CAPS",
    "BOOT",
)

# Replies that mean "the controller understood and accepted the command".
OK_REPLY = "OK"

# Older controllers in the wild acknowledge a command by emitting a telemetry
# event line instead of "OK" (e.g. "@EVT 949 E17").  The pump physically runs,
# so treating that line as a rejection reports a failure that never happened.
# A board that also answers "OK" simply wins first; these legacy events are the
# graceful fallback, and DONE replies / the pour watchdog still confirm the end.
LEGACY_EVENT_PREFIX = "@EVT"


def is_unsolicited(line: str) -> bool:
    text = (line or "").strip()
    if not text:
        return True
    return text.startswith(UNSOLICITED_PREFIXES)


def read_matching(replies: queue.Queue, timeout: float, accept=None) -> str:
    """Return the next reply line that ``accept`` allows, or ``""`` on timeout.

    When ``accept`` is supplied it owns the decision completely (so a caller can
    explicitly wait for ``PONG``).  Without a filter, unsolicited telemetry is
    consumed and ignored so it can never be mistaken for a command reply.
    """
    deadline = time.monotonic() + max(0.0, timeout)
    while True:
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return ""
        try:
            line = replies.get(timeout=remaining)
        except queue.Empty:
            return ""
        if isinstance(line, bytes):
            line = line.decode(errors="ignore")
        text = (line or "").strip()
        if not text:
            continue
        if accept is not None:
            if accept(text):
                return text
            continue
        if is_unsolicited(text):
            continue
        return text


def classify(reply: str) -> dict:
    """Describe a reply without hiding what the controller actually said."""
    text = (reply or "").strip()
    if not text:
        return {
            "ok": False,
            "started": False,
            "code": "no_reply",
            "detail": "The controller did not answer in time.",
            "reply": "",
        }
    if text == OK_REPLY or text.startswith(OK_REPLY + " "):
        return {"ok": True, "started": True, "code": "ok", "detail": "Controller accepted the command.", "reply": text}
    if text.startswith("ERR"):
        return {
            "ok": False,
            "started": False,
            "code": "controller_error",
            "detail": "The controller rejected the command: %s" % text,
            "reply": text,
        }
    if text.startswith(LEGACY_EVENT_PREFIX):
        return {
            "ok": True,
            "started": True,
            "code": "ok_legacy_event",
            "detail": "Legacy controller acknowledged the command (%s)." % text,
            "reply": text,
        }
    return {
        "ok": False,
        "started": False,
        "code": "unexpected_reply",
        "detail": "Unexpected controller reply: %s" % text,
        "reply": text,
    }


class BusyGate:
    """A re-entrant-safe counter used to pause non-urgent serial traffic.

    The display loop checks ``busy()`` before every write.  Pump work calls
    ``enter()`` *before* waiting for the command lock, so the display stops
    queueing new commands while a pump command is waiting.
    """

    def __init__(self) -> None:
        self._lock = threading.Lock()
        self._count = 0

    def enter(self) -> None:
        with self._lock:
            self._count += 1

    def leave(self) -> None:
        with self._lock:
            if self._count > 0:
                self._count -= 1

    def busy(self) -> bool:
        with self._lock:
            return self._count > 0

    def __enter__(self):
        self.enter()
        return self

    def __exit__(self, exc_type, exc, tb):
        self.leave()
        return False
