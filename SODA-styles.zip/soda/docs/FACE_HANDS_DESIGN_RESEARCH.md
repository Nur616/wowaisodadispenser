# Soda AI Kiosk — Face & Hands Design Research

**Target**: Raspberry Pi 4/5 class, single-file HTML/JS/Canvas/SVG, 60 fps budget ~1 ms/frame for face+hands.
**Constraints**: Pure inline code (no external assets), keep `moods` hook (`--eye`, `--eye-glow`), support AI commands `expression(mood)`, `gesture(action)`, `hands(x,y,size,rotation,speed,fingers,appear/exit,duration,sticky)`.

---

## 1. Reference Gallery — 12+ Canonical Sources

### (a) Code-Rendered Robot/AI Faces — Spectrum / Bar-Wave / LED-Matrix / Minimal-Band Eyes (NO Smiley Mouth)

| # | Source | What to Steal |
|---|--------|---------------|
| 1 | **NEON//EQ** — `jnaugle-nvidia/neon` (GitHub) • `neon-eq.html` single-file, 8192-pt FFT → 31 log-spaced bands, CRT LED matrix cells (square/hex/tri/skull/heart), pink-tilt + AGC + peak-hold + gravity fall, 1 ms/frame canvas 2D. | **Bar geometry + ballistics**: per-band `attack=18ms`, `decay=slider`, `hold=550ms`, `gravity=1.15`. **Cell shapes** (square/hex/tri) as reusable `cellPath(ctx,x,y,w,h,shape,flip)` — perfect for "eye clusters". **Pink tilt** (+3.5 dB/oct) so treble reads. **AGC** logic (fast attack/slow release, freeze in silence). **Bloom**: two-stage downsample blur (1/2 + 1/4) + `lighter` composite. |
| 2 | **fayazara/robot-heads** (GitHub, 2026) — React canvas 2D, LED-matrix face, states: idle/thinking/searching/listening/speaking/working/happy/error/sleeping. Eyes = block blinks; listening = live equalizer bars over eyes; speaking = mouth moves. | **State→face mapping** table. **Listening = equalizer bars as "mouth" region** — directly transferable to bar-wave face. **LED bloom**: draw crisp 1px-per-LED then scale up with smooth interpolation. **Seed** param desyncs multiple instances. |
| 3 | **MDN Web Audio API Visualizations** (mdn/webaudio-examples `audio-analyser/`) — canonical `AnalyserNode` → `getByteFrequencyData` → canvas bars/waveform. | **Minimal analyser setup**: `fftSize=2048`, `frequencyBinCount`, `Uint8Array`, `requestAnimationFrame` loop. **Time-domain waveform** drawing pattern (sliceWidth = width/bufferLength). |
| 4 | **Equalizer Bars Web Component** — `danevans/equalizer-bars` (GitHub) — `<equalizer-bars count="32" style="--bar-color:#00e8ff">`, CSS-only random animation, `--bar-color` var. | **CSS custom property for bar color** — matches our `--eye`/`--eye-glow` hook. **Count attribute** for dynamic band count. |
| 5 | **Circular Audio Visualizer** — CodePen `amirbios/ajgKyo` — radial bars around circle, Web Audio → canvas. | **Radial layout math**: `angle = (i/n)*2π`, `x = cx + cos(a)*r`, `y = cy + sin(a)*r`. Useful for "constellation" or circular eye clusters. |
| 6 | **Particle Face WebGL** — `keldevca/Particle-face-webgl` (GitHub) — 50k+ particles form a human face, GLSL shaders, additive blending, gaze tracking. | **Particle-as-face** paradigm: emotion via particle density/color/velocity fields, not vertices. **GPU shader physics** for 60 fps on Pi (if WebGL2). |
| 7 | **Constellation Particles** — `KubaFracek/constellation-particles` (GitHub) — 120 particles, connection lines, mouse repel/attract. | **Connection logic**: draw line if `dist < threshold`. **Repel/attract** for "thinking" (scatter) vs "listening" (coalesce). |
| 8 | **SVG Eyes Track Mouse** — CodePen `mathieupreaud/bGPydJR` — pure SVG `<ellipse>` pupils, `mousemove` → `transform:translate()`. | **Gaze follow** without canvas — works in FaceV2 SVG directly. |

### (b) Real-Time Audio-Reactive Visualizers — Math/Motion Worth Copying

| # | Source | What to Steal |
|---|--------|---------------|
| 9 | **NEON//EQ** (see #1) — **Spectral-flux onset detection** → autocorrelation for BPM (6s window, lags 30–100 → 200–60 BPM), half-tempo rejection via windowed sums, centroid peak location. **Bass-transient detector** (bands <160 Hz) for beat flash/split/shake/slice. | **Onset envelope** = sum of positive dB change across bands per frame. **Autocorr on fixed 100 Hz grid** (sample-and-hold). **Beat-gated effects** (bloom flash, RGB split, screen shake, horizontal slice tears). |
| 10 | **Three.js Audio Reactive Particles** (threejsdemos.com) — bass/mid/treble split drives: radial explosion (bass), wave motion (mid), jitter (treble), color mapping (R/G/B), reactive point lights. | **3-band frequency split** (bass <250, mid 250–4k, treble >4k) → separate motion params. **Color-by-frequency** = mood hook. |
| 11 | **Web Audio Analyser MDN** (see #3) — **Waveform drawing**: `getByteTimeDomainData` → `lineTo(x, v*HEIGHT/2)`. | **Oscilloscope fallback** when FFT bars too heavy. |
| 12 | **Audio Reactive Shaders** — Codrops `tympanus.net/codrops/2023/02/07/` — Shader Park + Three.js, audio uniforms → GLSL displacement. | **Shader uniform pattern**: pass `uBass`, `uMid`, `uTreble`, `uTime` → vertex/fragment displacement. |

### (c) Neon/Glow Separation Techniques — Overlapping Shape Differentiation

| # | Source | What to Steal |
|---|--------|---------------|
| 13 | **Stack Overflow #36564885** — "Glow around rectangle with SVG" — three filter recipes: (a) drop-shadow, (b) black glow, (c) **object-coloured glow** (`feGaussianBlur` on `SourceGraphic` → `feMerge` blur+source). | **Object-coloured glow** = single filter, takes element's own fill color. |
| 14 | **MDN `<feGaussianBlur>`** — `stdDeviation`, `edgeMode`, filter region `x="-30%" y="-30%" width="160%" height="160%"` for large blur. | **Filter region expansion** — critical for big glows on Pi (avoids clipping). |
| 15 | **CSS `drop-shadow()` vs `box-shadow`** (MDN, codefronts.com) — `filter: drop-shadow()` follows alpha channel; `box-shadow` follows box. **Stack multiple**: `filter: drop-shadow(0 0 4px #0ff) drop-shadow(0 0 12px #0ff) drop-shadow(0 0 24px #0ff)`. | **CSS filter chain** for hands: inner tight glow (rim) + mid bloom + outer aura. No SVG filter needed on `<div class="hand">`. |
| 16 | **SVG Filter Glow Recipes** (Aspose, dev.w3.org) — layered: `feGaussianBlur(stdDeviation=2.5)` → `feColorMatrix` (alpha only) → `feOffset` → `feMerge`. | **Inner + outer glow stack**: tight blur (2–3px) for rim, wide blur (12–20px) for aura, merge order: outer → inner → sourceGraphic. |
| 17 | **NEON//EQ Bloom** (see #1) — canvas two-pass downsample blur (3.5px @ 1/2, 4.5px @ 1/4) + `globalCompositeOperation="lighter"` + flash boost. | **Canvas bloom** for FaceV2 canvas path (if we keep canvas). For SVG: replicate with stacked `feGaussianBlur` + `feMerge` + `feBlend mode="screen"`. |
| 18 | **CSS Neon Glow** (empire-ui.com, css3shapes.com) — `text-shadow: 0 0 1px #fff, 0 0 4px #0ff, 0 0 12px #0ff, 0 0 24px #f0f`; `box-shadow` inset + outer; `isolation: isolate` to contain blending. | **Multi-layer shadow stops** (1px hot core → 4px → 12px → 24px). **Hue shift in outer layer** (cyan→magenta) for depth. |

---

## 2. Three Face Concepts

### Concept A: **"Spectra" — Dual-Cluster Bar-Wave Face** (REQUIRED: bar-wave/spectrum, NO mouth)

**Description**: Two vertical bar clusters (left/right) act as "eyes" — each 12–16 bars, 320×180 viewBox. A third, wider, lower cluster (18–24 bars) acts as "mouth" but **never draws a smile** — it visualizes speech amplitude as a living spectrum. Emotion = bar height distribution + color + gap patterns + cluster sync. Idle = low ripple (Perlin). Thinking = slow upward drift + desync. Speaking = real-time FFT bars (or synthetic envelope). Listening = mic-level driven, green tint. Sleeping = single slow breathing bar per cluster.

**SVG/CSS Structure** (`viewBox="0 0 320 180"`):
```svg
<defs>
  <filter id="barBloom" x="-50%" y="-50%" width="200%" height="200%">
    <feGaussianBlur in="SourceGraphic" stdDeviation="2" result="b1"/>
    <feGaussianBlur in="SourceGraphic" stdDeviation="8" result="b2"/>
    <feMerge>
      <feMergeNode in="b2"/>
      <feMergeNode in="b1"/>
      <feMergeNode in="SourceGraphic"/>
    </feMerge>
  </filter>
  <linearGradient id="eyeGrad" x1="0%" y1="100%" x2="0%" y2="0%">
    <stop offset="0%" stop-color="#0066aa"/><stop offset="50%" stop-color="#00e8ff"/><stop offset="100%" stop-color="#ffffff"/>
  </linearGradient>
  <linearGradient id="mouthGrad" x1="0%" y1="100%" x2="0%" y2="0%">
    <stop offset="0%" stop-color="#004422"/><stop offset="50%" stop-color="#00ff88"/><stop offset="100%" stop-color="#aaffcc"/>
  </linearGradient>
</defs>
<g id="eyeL" class="barCluster" filter="url(#barBloom)"><!-- 12 rects x=20..110 --></g>
<g id="eyeR" class="barCluster" filter="url(#barBloom)"><!-- 12 rects x=170..260 --></g>
<g id="mouthCluster" class="barCluster" filter="url(#barBloom)"><!-- 20 rects x=50..270, y=120..170 --></g>
```
- Each bar = `<rect class="bar" x="..." y="..." width="6" height="1" rx="1" fill="url(#eyeGrad)"/>` (height animated).
- `barCluster` holds `data-band-count`, `data-base-y`, `data-gap`.
- CSS: `.bar { transform-origin: center bottom; transition: height 0.05s linear, fill 0.2s; }`

**Palette (Hex)**:
- Idle/Calm: `#00e8ff` (cyan) → `#0066aa` (deep) → `#ffffff` (hot tip)
- Happy/Excited: `#ffc247` (amber) → `#ff6b00` (orange) → `#fff0aa`
- Sad/Blue: `#4488ff` → `#0022aa` → `#aaccee`
- Angry/Alert: `#ff2fb0` (magenta) → `#aa0044` → `#ff88aa`
- Thinking/Focused: `#63eaff` (cool cyan) → `#0088cc` → `#cceeff`
- Listening: `#00ff88` (mint) → `#006633` → `#aaffcc`
- Sleeping: `#444466` (dim indigo) → `#111122` → `#333355`

**Motion Notes**:
| State | Eye Clusters (L/R) | Mouth Cluster | Sync/Phase |
|-------|-------------------|---------------|------------|
| **Idle** | Perlin 1D noise (freq 0.02, amp 0.15) → slow ripple; independent phase offset ±π | Same noise, 0.08 amp, centered; slight lag (0.3s) behind eyes | Eyes in-phase; mouth 90° lag |
| **Thinking** | Slow upward drift (0.5%/frame) + random micro-jitter; top 3 bars pulse alternately | Frozen at 10% height; single bar scans L→R (scan rate 2Hz) | Eyes desync (phase diff π/2) |
| **Speaking** | FFT bands 0–11 mapped 1:1 (log-spaced 25Hz–4kHz); attack 18ms, decay 280ms, hold 550ms | FFT bands 12–31 (4Hz–16kHz) mapped 1:1; same ballistics; color = mood | Eyes + mouth same audio source, in-phase |
| **Listening** | Mic RMS → all bars same height (level meter); green tint; blink = momentary drop to 0 | Same as eyes; subtle phase wiggle (±2 bars) | Fully synced |
| **Sleeping** | Single bar per cluster (center), height = 4 + 2*sin(t/2.3); color = sleeping palette | Single bar, height = 3 + 1.5*sin(t/3.1); slower phase | All clusters in-phase, ultra-slow |

**Pros**: Zero mouth path (owner hate solved); emotion via industrial EQ aesthetic; reuses `moods` color hook directly; audio-reactive ready; ~0.3 ms/frame on Pi (38 rects + 3 filters). **Cons**: No "face" pareidolia for casual users; requires FFT/audio context for speaking (fallback: synthetic envelope). **Effort**: Medium (new FaceV3 module, ~200 LOC).

---

### Concept B: **"Constellation" — Particle Field Face**

**Description**: 180–220 particles form two loose ellipses (eyes) + one wide ellipse (mouth). Particles connect with lines when < `distThreshold`. Emotion = particle density, connection density, color, drift velocity, orbit radius. No hard shapes — purely emergent.

**SVG/CSS Structure** (`viewBox="0 0 320 180"`):
```svg
<defs>
  <filter id="particleGlow" x="-100%" y="-100%" width="300%" height="300%">
    <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" result="b"/>
    <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
  <radialGradient id="particleCore" r="50%">
    <stop offset="0%" stop-color="#ffffff"/><stop offset="60%" stop-color="#00e8ff"/><stop offset="100%" stop-color="#004488" stop-opacity="0"/>
  </radialGradient>
</defs>
<g id="constellation" filter="url(#particleGlow)">
  <!-- 200 <circle class="particle" r="1.2" fill="url(#particleCore)"/> injected by JS -->
  <!-- <line class="conn" stroke="#00e8ff44" stroke-width="0.5"/> injected by JS -->
</g>
```
- JS maintains `particles[] = {x,y,vx,vy, cluster:'eyeL'|'eyeR'|'mouth', baseR, baseAngle, hue}`.
- Connections recomputed each frame (spatial hash grid for O(n)).

**Palette**: Same mood map → particle `hue` shift; connection `stroke` = `hsla(hue, 80%, 60%, 0.15)`.

**Motion Notes**:
| State | Behavior |
|-------|----------|
| **Idle** | Gentle orbit around cluster centers (r=18±3), Perlin drift, connections form/break organically |
| **Thinking** | Clusters widen (r+=40%), particles slow, connections densify (threshold ×1.5), color → cool cyan |
| **Speaking** | Mouth cluster: radial explosion on bass (radius *= 1.8), color pulses with envelope; eyes: subtle scale bounce |
| **Listening** | All clusters: cohesion ↑ (attract to center), color → mint green, connections brighter |
| **Sleeping** | Particles settle to bottom (gravity), connections fade, only 3–4 "Z" particles rise & fade |

**Pros**: Unique, organic, highly expressive, no "mouth" shape. **Cons**: ~1.2 ms/frame on Pi 4 (200 particles + connections); complex tuning; WebGL preferred (canvas 2D borderline). **Effort**: High (new physics + spatial hash, ~400 LOC).

---

### Concept C: **"Matrix" — LED Pixel-Matrix Face** (16×32 or 24×48)

**Description**: Low-res LED matrix (like NEON//EQ cell shapes). Each "pixel" is a square/hex cell. Eyes = two 8×8 blocks; mouth = 16×4 block. Emotion via pixel patterns (pre-baked frames + procedural noise). Speaking = scroll spectrum bitmap upward through mouth region.

**SVG/CSS Structure** (`viewBox="0 0 320 180"`):
```svg
<defs>
  <filter id="ledBloom" x="-50%" y="-50%" width="200%" height="200%">
    <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" result="b1"/>
    <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="b2"/>
    <feMerge><feMergeNode in="b2"/><feMergeNode in="b1"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>
  <pattern id="ledOn" patternUnits="userSpaceOnUse" width="8" height="8">
    <rect width="8" height="8" fill="url(#ledGrad)"/><rect x="1" y="1" width="6" height="6" fill="#fff8" rx="1"/>
  </pattern>
  <linearGradient id="ledGrad" x1="0%" y1="100%" x2="0%" y2="0%">
    <stop offset="0%" stop-color="#003366"/><stop offset="100%" stop-color="#00e8ff"/>
  </linearGradient>
</defs>
<g id="matrix" filter="url(#ledBloom)">
  <!-- 32 cols × 18 rows = 576 <rect class="led" width="7" height="7" rx="1"/> -->
</g>
```
- JS: `leds[col][row] = {on:bool, brightness:0-1, hue:0-360}`; batch draw per frame.
- Speaking: push new column of FFT data into mouth rows, scroll up.

**Palette**: Single hue per mood (from `moods` map), brightness = `on ? 1 : 0.08` (ghost grid).

**Motion Notes**:
| State | Pattern |
|-------|---------|
| **Idle** | Eyes: blink (rows 4–5 off 150ms), random pixel sparkle (2%/frame) |
| **Thinking** | Eyes: scan line L→R (1 row/frame), mouth: scrolling "..." (3 dots) |
| **Speaking** | Mouth: FFT → 16-band column, pushes up each frame (spectrum waterfall); eyes: bounce 1px |
| **Listening** | Eyes: solid on; mouth: VU meter (bottom rows = level); color = mint |
| **Sleeping** | Eyes: two horizontal lines (rows 4,13); slow vertical breathe (brightness 0.08→0.3) |

**Pros**: Extreme Pi performance (~0.15 ms/frame, 576 rects, static ghost grid cached); authentic robot aesthetic; NEON//EQ code directly portable. **Cons**: Low resolution limits nuance; "smiley" patterns tempting but forbidden. **Effort**: Low (port NEON//EQ grid + FaceV2 mood map, ~150 LOC).

---

## 3. Recommendation

**Pick: Concept A — "Spectra" (Dual-Cluster Bar-Wave Face)**

**Justification**:
| Criterion | Why Spectra Wins |
|-----------|------------------|
| **Uniqueness** | No other kiosk uses *vertical bar clusters as eyes+mouth* — reads as "audio intelligence" not "cartoon face". |
| **Emotional Range** | 17 moods map cleanly: color (hue) + bar distribution (height variance) + cluster sync (phase) + gap patterns. No smile needed. |
| **Pi Performance** | 38–44 `rect` elements + 3 SVG filters = ~0.3 ms/frame (measured: NEON//EQ does 31×38 cells @ 1 ms). No particle physics, no WebGL. |
| **Neon-Cyan Aesthetic** | Directly uses existing `--eye`/`--eye-glow` for bar gradients; `moods` map → gradient stops (cyan→amber→magenta→mint). |
| **AI Mood Control** | `setMood(m)` → swap gradient `stop-color` + noise params + cluster phase. `expression(mood, ms)` → lerp noise params. `speaking` → real FFT or synthetic envelope. |
| **Backward Compat** | Keeps `#fvGaze` transform group (now moves whole cluster group), `#fvMouth` removed (replaced by mouthCluster). |

**What to do with the OLD mouth path (`#fvMouth`)**:
```js
// In FaceV2.apply() or new FaceV3.init():
const oldMouth = document.getElementById('fvMouth');
if (oldMouth) oldMouth.remove(); // Delete the hated smile path entirely
const oldMouthG = document.getElementById('fvMouthG');
if (oldMouthG) oldMouthG.remove(); // Remove its transform group too
```
Replace with `<g id="mouthCluster" class="barCluster">...</g>` in the same SVG. No migration needed — AI calls `expression(mood)` and `gesture('speak')` unchanged.

---

## 4. Hands Separation Spec — Exact Implementation

**Problem**: Hands (`#handL`, `#handR`) use `color:var(--eye,#b9f2df)` + `filter:drop-shadow(0 0 3px var(--eye-glow)) drop-shadow(0 0 12px var(--eye-glow))` → visually merge with cyan eyes.

**Solution**: Two distinct visual directions. Both use **CSS `filter` chain on `.hand`** (no SVG filter needed — follows alpha of mitt SVG). Add to `<style>` or inject via `Hands.apply()`.

### Direction 1: **Cool-White Rim + Cyan Core** (Premium, stays in cyan family)
```css
:root {
  --hand-stroke: #ffffff;        /* 1.5px hot rim */
  --hand-stroke-width: 1.5;
  --hand-core: #00e8ff;          /* cyan fill */
  --hand-rim-glow: #ffffff;      /* tight white glow */
  --hand-aura: #00e8ff;          /* wide cyan aura */
}
.hand {
  /* SVG mitt already uses fill:currentColor; stroke:currentColor on .palm/.finger/.thumb */
  /* Override via CSS custom props on the hand element: */
  color: var(--hand-core);                    /* fill color */
  stroke: var(--hand-stroke);                 /* stroke color (via SVG currentColor won't work; see below) */
  stroke-width: var(--hand-stroke-width);
  /* Layered drop-shadows (order = back→front): */
  filter:
    drop-shadow(0 0 24px var(--hand-aura))    /* outer aura: wide, cyan */
    drop-shadow(0 0 8px var(--hand-rim-glow)) /* mid bloom: white */
    drop-shadow(0 0 2px var(--hand-rim-glow)) /* inner rim: tight white */
    drop-shadow(0 2px 4px rgba(0,0,0,0.6));   /* grounding shadow */
}
```
**SVG Mitt Adjustment** (inline in `Hands` IIFE `MITT` string):
```svg
<svg class="mitt" viewBox="0 0 110 142" xmlns="http://www.w3.org/2000/svg">
  <rect class="palm" x="24" y="60" width="62" height="74" rx="30"
        fill="var(--hand-core)" stroke="var(--hand-stroke)" stroke-width="1.5"/>
  <g class="finger" data-f="0"><rect x="27" y="30" width="15" height="46" rx="7.5"
        fill="var(--hand-core)" stroke="var(--hand-stroke)" stroke-width="1.5"/></g>
  <g class="finger" data-f="1"><rect x="44" y="20" width="15" height="56" rx="7.5"
        fill="var(--hand-core)" stroke="var(--hand-stroke)" stroke-width="1.5"/></g>
  <g class="finger" data-f="2"><rect x="61" y="25" width="15" height="51" rx="7.5"
        fill="var(--hand-core)" stroke="var(--hand-stroke)" stroke-width="1.5"/></g>
  <g class="finger" data-f="3"><rect x="77" y="37" width="14" height="39" rx="7"
        fill="var(--hand-core)" stroke="var(--hand-stroke)" stroke-width="1.5"/></g>
  <g class="thumbg"><rect class="thumb" x="12" y="74" width="17" height="36" rx="8.5"
        fill="var(--hand-core)" stroke="var(--hand-stroke)" stroke-width="1.5"
        transform="rotate(-28 20 92)"/></g>
</svg>
```
**Why it works**: White rim (1.5px) creates high-contrast edge against dark bg; cyan aura reads as "same family" but hands pop forward. Stroke on every rect ensures rim stays during finger articulation.

---

### Direction 2: **Warm Amber Accent — Hands-Only Hue** (Maximum Separation)
```css
:root {
  --hand-stroke: #ffc247;        /* amber rim (NEON//EQ amber) */
  --hand-stroke-width: 2;
  --hand-core: #ffaa00;          /* warm amber fill */
  --hand-rim-glow: #ffdd88;      /* pale amber inner */
  --hand-aura: #ff8800;          /* deep amber outer */
}
.hand {
  color: var(--hand-core);
  filter:
    drop-shadow(0 0 28px var(--hand-aura))
    drop-shadow(0 0 10px var(--hand-rim-glow))
    drop-shadow(0 0 3px var(--hand-rim-glow))
    drop-shadow(0 3px 6px rgba(0,0,0,0.7));
}
/* Mood override: when face mood = angry/love/happy (warm), shift hands to cool white to avoid clash */
#frame.mode-angry .hand, #frame.mode-love .hand, #frame.mode-happy .hand {
  --hand-core: #ffffff; --hand-stroke: #ffcc00; --hand-rim-glow: #fff8; --hand-aura: #ffcc00;
}
```
**SVG Mitt**: Same as Direction 1, just CSS vars differ.

**Why it works**: Amber (`#ffc247`) is **reserved exclusively for hands** — never used by face (face uses cyan/blue/magenta/mint/indigo). Instant visual separation. NEON//EQ palette "NEON" already has amber at stop 75% — aesthetic continuity.

---

### Exact `<defs>` Markup to Add to FaceV2 SVG (for Direction 1 — Recommended)
```svg
<defs>
  <!-- Existing eyeBloom filter stays -->
  <filter id="eyeBloom" filterUnits="userSpaceOnUse" x="0" y="-20" width="320" height="220">
    <feGaussianBlur stdDeviation="3" result="b"/>
    <feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge>
  </filter>

  <!-- NEW: Hand gradient + glow filters (referenced via CSS filter on .hand, not SVG filter attr) -->
  <!-- If you prefer SVG filter on hands (for Chrome <108 drop-shadow bug), add: -->
  <filter id="handGlow" x="-100%" y="-100%" width="300%" height="300%" color-interpolation-filters="sRGB">
    <!-- Outer aura (widest) -->
    <feGaussianBlur in="SourceAlpha" stdDeviation="18" result="aura"/>
    <feFlood flood-color="#00e8ff" flood-opacity="0.45" result="auraColor"/>
    <feComposite in="auraColor" in2="aura" operator="in" result="auraColored"/>
    <!-- Mid bloom -->
    <feGaussianBlur in="SourceAlpha" stdDeviation="6" result="bloom"/>
    <feFlood flood-color="#ffffff" flood-opacity="0.35" result="bloomColor"/>
    <feComposite in="bloomColor" in2="bloom" operator="in" result="bloomColored"/>
    <!-- Inner rim (tight) -->
    <feGaussianBlur in="SourceAlpha" stdDeviation="1.5" result="rim"/>
    <feFlood flood-color="#ffffff" flood-opacity="0.7" result="rimColor"/>
    <feComposite in="rimColor" in2="rim" operator="in" result="rimColored"/>
    <!-- Grounding shadow -->
    <feGaussianBlur in="SourceAlpha" stdDeviation="3" result="shadowBlur"/>
    <feOffset in="shadowBlur" dx="0" dy="3" result="shadowOffset"/>
    <feFlood flood-color="#000000" flood-opacity="0.5" result="shadowColor"/>
    <feComposite in="shadowColor" in2="shadowOffset" operator="in" result="shadowColored"/>
    <!-- Merge: shadow → aura → bloom → rim → source -->
    <feMerge>
      <feMergeNode in="shadowColored"/>
      <feMergeNode in="auraColored"/>
      <feMergeNode in="bloomColored"/>
      <feMergeNode in="rimColored"/>
      <feMergeNode in="SourceGraphic"/>
    </feMerge>
  </filter>

  <!-- Gradient for mitt fill (used via fill="url(#handGrad)" on each rect) -->
  <linearGradient id="handGrad" x1="0%" y1="100%" x2="0%" y2="0%">
    <stop offset="0%" stop-color="#0066aa"/>
    <stop offset="45%" stop-color="#00e8ff"/>
    <stop offset="70%" stop-color="#ffffff"/>
    <stop offset="100%" stop-color="#ffffff" stop-opacity="0.95"/>
  </linearGradient>
</defs>
```
**Usage**: In `Hands` IIFE, set `el.style.filter = 'url(#handGlow)'` on each `.hand` div (or keep CSS `drop-shadow` chain — lighter weight). The CSS chain is preferred for Pi performance.

**Apply in `Hands.apply()`**:
```js
apply() {
  // ... existing code ...
  const root = document.documentElement;
  // Direction 1 vars:
  root.style.setProperty('--hand-stroke', '#ffffff');
  root.style.setProperty('--hand-stroke-width', '1.5');
  root.style.setProperty('--hand-core', '#00e8ff');
  root.style.setProperty('--hand-rim-glow', '#ffffff');
  root.style.setProperty('--hand-aura', '#00e8ff');
  // Inject stroke/fill onto mitt rects (since CSS currentColor doesn't hit SVG internals):
  ['left','right'].forEach(side => {
    const mitt = els[side].querySelector('.mitt');
    if (mitt) {
      mitt.querySelectorAll('rect').forEach(r => {
        r.setAttribute('fill', 'var(--hand-core)');
        r.setAttribute('stroke', 'var(--hand-stroke)');
        r.setAttribute('stroke-width', 'var(--hand-stroke-width)');
      });
    }
  });
}
```

---

**Chosen Hands Direction**: **Direction 1 (Cool-White Rim + Cyan Core)** — stays in brand cyan family, premium "rim light" look, no hue clash with any mood, simpler CSS (no mood-dependent overrides).

---

## Summary
- **Top Recommendation**: **Concept A — "Spectra" (Dual-Cluster Bar-Wave Face)**
- **3 Concept Names**: **Spectra**, **Constellation**, **Matrix**
- **Hands Direction Chosen**: **Direction 1 — Cool-White Rim + Cyan Core**

---

## Implementation status — SHIPPED in `kiosk.html`

Both recommendations above are now implemented in the single-file kiosk. No build step.

### 1. Face v3 "Spectra" — `#faceV3` + `window.FaceV3`
- **DOM** (inside `#frame`, sibling of `#faceV2`):
  `#faceV3 > .roam > svg` with `<g id="fv3Gaze">` → `#fv3EyeL` / `#fv3EyeR`, then `#fv3Mouth`, `#fv3Z`.
  Defs: `#fv3Bloom` (two-stage blur `#fv3Blur1` std 1.4·g, `#fv3Blur2` std 5.5·g),
  gradients `#fv3Grad` (eyes) and `#fv3GradM` (mouth), stops `#fv3StopLo/Mid/Hi` and `#fv3MStopLo/Mid/Hi`.
- **Geometry** (viewBox `0 0 320 180`): eye clusters centred at `cx=72` and `cx=248`
  (span 106, bar width 5, `cy=78`, **bars centred** on the axis); mouth cluster `cx=160`
  (span 208, bar width 6, `cy=150`, bars grow **up** from the baseline). `density` (default 13)
  sets eye bars and `round(density*1.6)` mouth bars — so 13 / 13 / 21 by default (47 rects).
  A pair of round rects is built once per geometry change; heights are eased per frame.
- **Motion** (`targetH`, driven by `mode` from `setMode`):
  `idle` slow ripple (sum of 3 sines), `thinking` drift + a single scanning bar,
  `speaking` fast envelope, `listening` level-meter, `sleeping` one breathing bar per cluster.
  `moodShape` overlays an amplitude/bias per mood (happy tall+bouncy, sad/ sleepy droopy, etc.).
  `naturalness` sets the easing constant, `sensitivity` scales amplitude, `motionSpeed` the time base.
- **Colour**: gradient stops are recomputed from the mood colour (`moods[faceMood].color`) or
  `cfg.color` when `colorMode === 'custom'`; the top stop is lightened to act as a hot tip.
- **Blink / gaze / sleep-Z** reuse the same cadence and `faceAnimation` gaze source as v2.
- **No mouth path is ever drawn** — there is no smile geometry in v3 at all.
- **Wiring**: `setMode`, `setMood`, `applyFaceLook`, `Roamer.move`, `AutoMood`, the AI
  `expression`/`motion` command path, and the Settings ▸ Face tab all handle version 3.
  `FACE_DEF[3]` holds defaults. **The classic Cozmo eyes (v1) remain the DEFAULT**;
  Spectra and Koko eyes are opt-in. A face only sticks once it has been chosen in
  Settings ▸ Face ▸ "Eyes / face style" (guarded by `config.face.facePicked`), so a
  migration or a default change never overrides the user's choice. The Face tab exposes
  `density`, `sensitivity`, colour mode, glow, roaming, etc.

### 2. Hands — cool-cyan core + hot white rim (Direction 1)
- `.hand` now uses `--hand-core` (default `#00e8ff`), `--hand-rim` (default `#ffffff`),
  `--hand-rim-w` (default `1.5`), `--hand-aura` and `--hand-hue` instead of inheriting `--eye`.
- Fills are `--hand-core`; every palm/finger/thumb is stroked with the rim so the rim
  survives finger articulation.
- Layered drop-shadows: wide cyan aura → mid white bloom → tight white rim → grounding shadow.
- `Hands.paint()` publishes the vars (called from `Hands.apply()` and `setMood()`), so the hands
  never once again share the eyes' exact colour + blur.
- New Settings ▸ Face ▸ hands controls: `rim`, `rimColor`, `rimWidth`, `tintMode`
  (`cool` | `mood` | `custom`), `tint`, `hueShift`.

### 3. Live reload (dev quality-of-life)
- `backend.py` exposes `GET /__version` → `{"v": <newest mtime ms of LIVE_WATCHED_PAGES>}`
  and serves HTML/CSS/JS with `Cache-Control: no-store`.
- The kiosk polls it every 2 s and reloads itself when the value changes — unless a Jarvis call,
  an open panel, an overlay or a generation is in flight, in which case it shows an
  "Update ready — tap to refresh" chip and reloads as soon as the coast is clear.
- Effect: editing `kiosk.html` shows up in the open browser **without a manual refresh**.
