# Jarvis (Gemini Live) Integration — CODA Robot Kiosk

This document describes how the downloaded **Jarvis** voice agent (Gemini Live +
web browsing) was reverse-engineered and integrated into the existing **CODA**
robot kiosk, without breaking any existing robot functionality. Every Jarvis
capability is exposed and tweakable from the kiosk **Settings → Jarvis** tab.

---

## 1. TL;DR

* Jarvis runs as a **supervised sidecar process** launched and monitored by the robot
  backend. It runs the project's own interpreter (`.venv/bin/python src/agent.py start`)
  and falls back to `uv run src/agent.py start` only if that venv is missing. `uv`'s
  sync step is skipped on purpose: on Termux/Android it fails to hardlink packages into
  its cache (`Operation not permitted`), and `UV_LINK_MODE=copy` is exported as a belt-and-
  braces fallback. It never replaces CODA.
* The kiosk gains a **Voice brain** switch: `Coda (Groq + ElevenLabs)` or
  `Jarvis (Gemini Live)`. When Jarvis is selected, the **TALK** button opens a
  real Gemini Live voice session **inside the kiosk browser over LiveKit WebRTC**.
* The robot backend owns Jarvis' lifecycle and settings via `/jarvis/*` routes and
  persists them in `data/jarvis_settings.json`; it writes the agent config the
  sidecar reads at boot (`data/jarvis_agent_config.json`).
* Jarvis can optionally drive the robot (status + confirmation-gated pouring)
  through its own tools, gated from the kiosk.
* **No new dependencies** were added to the robot's Python venv; LiveKit tokens
  are signed with the standard library.

---

## 2. Reverse-engineered Jarvis architecture

Source: `jarvis-voice-butler/jarvis_new/` (a LiveKit **Agents** project, `uv`-managed).

| Component | File | Role |
|---|---|---|
| Agent entrypoint | `src/agent.py` | `Assistant(Agent)` + `AgentServer`; `my_agent()` joins a LiveKit room |
| Brain | `src/agent.py` → `google.beta.realtime.RealtimeModel` | **Gemini Live** realtime model `gemini-3.1-flash-live-preview`, voice `Enceladus`, `en-GB` |
| Turn handling | `AgentSession` + `inference.TurnDetector()` | adaptive interruption, preemptive generation |
| Audio | `livekit.plugins.ai_coustics` | noise cancellation (`QUAIL_VF_S`) |
| Web browsing | `src/browser.py` (`BrowserManager`) | isolated Playwright Chromium: open/read/inspect/click/type/scroll/press/screenshot |
| Browser tools | `src/tools.py` (`BrowserTools`) | 11 `function_tool`s incl. confirmation-gated clicks |
| End call | `livekit.agents.beta.tools.EndCallTool` | ends the session politely |
| Instructions | `src/prompts.py` (`AGENT_INSTRUCTIONS`) | butler persona, output rules, tool routing, guardrails |
| Transport | LiveKit Cloud rooms | client ↔ agent WebRTC; agent dispatch by name (`my-agent`) |

**How it ran originally:** as a standalone LiveKit worker (`uv run src/agent.py start`)
that connects to LiveKit Cloud and waits for a room dispatch; a separate frontend
(Next.js in `frontend/`, or the Flutter starter) joined the room to talk to it.

**Integration challenges identified:**

1. **Transport mismatch** — Jarvis speaks LiveKit WebRTC; the robot is a synchronous
   Flask + single-page-HTML kiosk with its own Web Speech/ElevenLabs voice path.
2. **Hard-coded configuration** — model, voice, language, headless mode, and the
   entire prompt were literals; nothing was tweakable.
3. **Two voices / two agents** — CODA (Groq + ElevenLabs + tool calling) already
   owns TALK, recipes and pours; a second agent must not disturb it.
4. **Process isolation** — a Playwright/Gemini worker must never be able to crash
   the pump controller.
5. **Credentials** — LiveKit API key/secret must stay server-side; the browser
   may only receive a short-lived room token.
6. **Pre-existing bug** — `tests/test_prompts.py` imported a misspelled symbol
   (`AGENT_ISNTRUCTIONS`), so that test file could never run.

---

## 3. Integration strategy

Design principles: **additive**, **non-breaking**, **kiosk-tweakable**, **safe**.

```
┌──────────────────────────── Kiosk browser (kiosk.html) ────────────────────────────┐
│  TALK button ──► "Voice brain" setting ──► Coda path (existing)                     │
│                                    └─────► JarvisVoice (LiveKit WebRTC + mic) ──┐   │
│  Settings → Jarvis tab  ──► GET/POST /jarvis/*   (settings, status, control)     │   │
└───────────────────────────────────────────────┬─────────────────────────────────┼───┘
                                                 │ HTTP (same origin)              │ WebRTC
┌────────────────────────────────────────────────▼─────────────────┐   ┌────────▼─────────┐
│ CODA Flask backend (:5005)                                       │   │ LiveKit Cloud     │
│  • pump control / recipes / CODA agent  (UNCHANGED)              │   │  room: jarvis-room│
│  • jarvis_bridge.py  ── settings, supervision, token minting     │   └────────┬─────────┘
│  • POST /jarvis/token ─► short-lived JWT (stdlib HS256)          │            │
└───────────────────┬──────────────────────────────────────────────┘            │
                    │ spawns / supervises ── uv run src/agent.py start          │
                    ▼                                                           ▼
        ┌─────────────────────────────────────────────────────────────────────────────┐
        │ Jarvis sidecar (jarvis_new)  ── Gemini Live + Playwright browser ──┘        │
        │ reads data/jarvis_agent_config.json (written by the backend)                │
        │ optional robot tools ──► CODA HTTP API (/status, /hardware, /ai/recipe, /ai/dispense)
        └─────────────────────────────────────────────────────────────────────────────┘
```

Why this shape:

* **Sidecar, not merge** — Jarvis keeps its native LiveKit/Gemini runtime, so its
  browsing and realtime voice behave exactly as designed, while CODA keeps its
  own agent/voice/recipe/ pump paths untouched.
* **In-browser WebRTC** — real Gemini Live audio with the kiosk's own mic/speakers;
  CODA's Web Speech + ElevenLabs path is only paused, never rewired.
* **Backend as control plane** — one place owns lifecycle, secrets, and the
  settings that must reach a separate process.

---

## 4. Files added / modified

### Jarvis project (`jarvis-voice-butler/jarvis_new/`)

| File | Status | Purpose |
|---|---|---|
| `src/config.py` | **new** | `JarvisConfig` dataclass + `load_config()` (JSON file via `JARVIS_CONFIG` + `JARVIS_*` env overrides) with clamping/coercion |
| `src/robot_tools.py` | **new** | Optional `RobotTools`: `get_robot_status`, confirmation-gated `pour_drink` (calls the CODA HTTP API) |
| `src/prompts.py` | modified | Kept `AGENT_INSTRUCTIONS` byte-identical; added `build_instructions(cfg)` (persona rename, sarcasm toggle, browsing on/off, robot section, custom instructions) |
| `src/agent.py` | modified | Loads config; builds the RealtimeModel, turn handling, tools and prompt from it; dispatch name follows `agent_name` |
| `tests/test_prompts.py` | modified | Fixed the import bug; added 10 tests for config + prompt building |

### Robot project (`Robot-main/`)

| File | Status | Purpose |
|---|---|---|
| `jarvis_bridge.py` | **new** | Settings persistence, agent-config writer, process supervision, LiveKit token minting, `/jarvis/*` routes |
| `motion_bridge.py` | **new** | Bounded motion-command queue + `/robot/*` routes so Jarvis can drive the kiosk face and hands (§14) |
| `backend.py` | modified | 4 added lines: `import jarvis_bridge` + `jarvis_bridge.init(...)` and `import motion_bridge` + `motion_bridge.init(...)`, next to the existing `agent.init` |
| `kiosk.html` | modified | New **Jarvis** settings tab, `JARVIS_DEF` config group, `JarvisVoice` LiveKit session module, TALK-button brain switch |
| `docs/JARVIS_INTEGRATION.md` | **new** | This document |

---

## 5. Kiosk settings (Settings → Jarvis)

All values persist in the browser (`soda_kiosk_config`, mirrored to
`data/browser_storage.json`) **and** in `data/jarvis_settings.json`; changing one
writes the agent config and (on *Restart & apply*) restarts the sidecar.

### Status & control

| Control | Meaning |
|---|---|
| Status card | Enabled, running (with uptime), installed?, LiveKit configured?, active brain, agent name, project path, last error |
| **Start Jarvis** | Enable + launch the sidecar |
| **Stop** | Stop the sidecar |
| **Restart & apply** | Save settings and restart the sidecar so they take effect |
| **Refresh** | Re-read status + log |
| **Talk to Jarvis** | Start/stop the in-browser Gemini Live voice session |

### Voice brain

| Setting | Default | Notes |
|---|---|---|
| Enable Jarvis | off | Master switch (off ⇒ no process, no polling) |
| Voice brain (TALK button) | Coda | `Coda — Groq + ElevenLabs` or `Jarvis — Gemini Live` |
| Start Jarvis automatically with the robot | off | Sidecar autostart on backend boot |
| LiveKit room name | `jarvis-room` | Room the kiosk and agent meet in |
| Room token lifetime | 60 min | 5–1440 min |

### Gemini Live voice

| Setting | Default |
|---|---|
| Model | `gemini-3.1-flash-live-preview` |
| Voice | `Enceladus` (Puck, Charon, Kore, Fenrir, Aoede, Leda, Orus, Zephyr, …) |
| Language | `en-GB` (15+ languages) |
| Sarcastic tone | on |
| Assistant name | `Jarvis` |
| Opening greeting | `Good day, Sir` |
| Dispatch name (advanced) | `my-agent` |
| Persona instructions | free text, appended to the built-in rules |

### Conversation

| Setting | Default |
|---|---|
| Smart turn detection | on |
| Interruptions | `adaptive` (ignore back-channels) / `strict` |
| Predict replies early | on |
| Noise cancellation | on |
| Accept camera / video input | on |

### Web browsing

| Setting | Default |
|---|---|
| Let Jarvis browse the web | on |
| Hide the browser window | off (visible per session) |
| Home page to open first | (blank) |
| Page load timeout | 15000 ms (2000–120000) |
| Max page text read | 12000 chars (1000–60000) |

### Robot tools

| Setting | Default |
|---|---|
| Let Jarvis control the robot | off |
| Robot API address | `http://127.0.0.1:5005` |
| Allow Jarvis to pour drinks (asks to confirm) | off |

### LiveKit connection

URL + API key + API secret inputs (secret fields are masked and never returned to
the browser; leaving them blank keeps the saved value; **Clear credentials**
wipes them). If left blank the backend falls back to the project's
`.env.local` / `LIVEKIT_*` environment variables.

---

## 6. Backend API (`/jarvis/*`)

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/jarvis/status` | any | Enabled, running, pid, uptime, availability, LiveKit configured, masked settings |
| POST | `/jarvis/control` | loopback | `{action: start\|stop\|restart}` |
| GET | `/jarvis/settings` | any | Public (secret-masked) settings + defaults |
| POST | `/jarvis/settings` | loopback | Save settings (+ `apply_now`, `clear_secrets`); writes agent config; optional restart |
| GET | `/jarvis/log` | any | Tail of `data/jarvis_agent.log` |
| POST | `/jarvis/token` | loopback | Mint a short-lived LiveKit room token (with agent dispatch) |
| GET | `/jarvis/health` | any | Liveness |

**Token minting (stdlib):** the backend signs an HS256 JWT with the LiveKit API
secret — claims `iss`, `sub`, `name`, `video{roomJoin,room,canPublish,canSubscribe,canPublishData}`,
`roomConfig{agents:[{agentName}]}`, `nbf`/`exp`. Verified against the official
`livekit.api.TokenVerifier`. This avoids adding `livekit-api` (and its
dependencies) to the robot venv.

---

## 7. Jarvis → robot tools

Registered only when *Let Jarvis control the robot* is on:

* `get_robot_status` — reads `/status` + `/hardware` (read-only).
* `pour_drink(description, confirmed)` — only registered when *Allow Jarvis to
  pour drinks* is also on. Call with `confirmed=false` returns the recipe the
  robot would use; the model must read it back and get explicit user agreement
  before calling with `confirmed=true`, which POSTs to `/ai/dispense`. Recipe
  generation and all safety limits (max 3 ingredients, 12 s/pump, 24 s total,
  e-stop latch) stay on the robot.

---

## 8. Third-party components used

No new Python dependencies were installed into the robot venv. Components used:

| Component | Where | Purpose |
|---|---|---|
| `livekit-agents[google,images]` | Jarvis venv (pre-existing) | Gemini Live realtime + LiveKit runtime |
| `livekit-plugins-ai-coustics` | Jarvis venv (pre-existing) | Noise cancellation |
| `playwright` | Jarvis venv (pre-existing) | Web browsing (Chromium) |
| `google-genai` | Jarvis venv (pre-existing) | `FunctionResponseScheduling` for tool responses |
| `livekit.api.TokenVerifier` | Jarvis venv (verification only) | Cross-checked our stdlib JWT signature |
| `livekit-client` (JS) | kiosk, loaded lazily from jsDelivr CDN | In-browser WebRTC session with Gemini Live |
| `uv` | host machine | Runs the Jarvis project (required for the sidecar) |

---

## 9. Bugs found and resolved

| # | Where | Issue | Resolution |
|---|---|---|---|
| 1 | `tests/test_prompts.py` | Pre-existing typo imported `AGENT_ISNTRUCTIONS`; file could never run | Fixed import; rewrote with 11 assertions |
| 2 | `src/config.py` | `_BOOL_FIELDS` tested `f.type in ("bool","bool")` (never true with `from __future__ import annotations`) | Compare `f.type == "bool"` |
| 3 | `src/config.py` | `CONFIG_FIELDS - _BOOL_FIELDS` subtracted a tuple (TypeError at import) | Derive from a `set` |
| 4 | `src/prompts.py` | Browsing-off slicing used indented markers but the string is dedented (`ValueError`) | Slice on `# Tools` → `# Guardrails` |
| 5 | `src/prompts.py` | Browsing-off left the "Special Requests" URL rule dangling | Cut through to `# Guardrails` (also drops theme-song rule) |
| 6 | `src/agent.py` | Instructions defined inline while `prompts.AGENT_INSTRUCTIONS` was imported but unused (dead code + drift) | Single source via `build_instructions(cfg)` |
| 7 | `src/agent.py` + `jarvis_bridge.py` | Dispatch name hard-coded; changing the kiosk "dispatch name" would break agent routing | Worker registers under `_BOOT_CONFIG.agent_name`, the same value the token dispatches to |
| 8 | `jarvis_bridge.py` | No way to clear stored LiveKit credentials (only "keep if blank") | Added `clear_secrets` handling + kiosk button |
| 9 | `kiosk.html` | `.jarvis-brain` class toggled with no CSS | Added styling so the active brain is visible on TALK |

---

## 10. Verification performed

* **Unit tests** — `PYTHONPATH=src pytest tests/test_prompts.py` → 11 passed
  (config file/bad-JSON/missing-file/type coercion/clamping; prompt equality,
  persona rename, sarcasm toggle, browsing-off slicing, robot section, custom text).
* **Lint/format** — `ruff check src/ tests/` clean; `ruff format --check` clean.
* **Robot tools** — exercised against a local fake robot HTTP server: status
  summary, gating by `allow_pour`, unconfirmed pour returns recipe only, confirmed
  pour calls `/ai/dispense`.
* **Token** — stdlib JWT verified by `jwt.decode` (HS256) **and**
  `livekit.api.TokenVerifier`; payload matches the official library byte-for-byte
  in structure.
* **Backend live smoke test** (`PUMP_TRANSPORT=mock`): `/jarvis/status`,
  `/jarvis/settings` GET/POST, agent-config generation, `/jarvis/token` after
  injecting credentials, `start`/`stop` supervision (no orphans), and
  `clear_secrets`. Artifacts removed afterwards.
* **Kiosk** — all inline `<script>` blocks pass `node --check`; tab/section counts
  balanced (9/9).

---

## 11. Operating & configuring Jarvis from the kiosk

1. **Open Settings → Jarvis** (gear button on the kiosk).
2. **Connect LiveKit:** paste the project **URL**, **API key** and **API secret**
   (or leave blank to use `jarvis_new/.env.local`), then **Save connection**.
3. **Turn on "Enable Jarvis".**
4. Choose the **Voice brain**: `Jarvis — Gemini Live` to route TALK to Jarvis,
   or keep `Coda` for the original assistant.
5. Tune **Gemini Live voice** (model/voice/language), **Conversation**,
   **Web browsing**, and optionally **Robot tools**.
6. Press **Start Jarvis** (or **Restart & apply** after changes). The status card
   should read *Running*.
7. Press **TALK** (or **Talk to Jarvis**). Grant microphone permission; the
   browser joins the LiveKit room and Gemini Live responds. **TALK** again stops it.
8. Use **Refresh** and the **Agent log** to diagnose issues.

Defaults are **all-off**: if you never open the Jarvis tab, the robot behaves
exactly as before.

---

## 12. Troubleshooting

| Symptom | Likely cause / fix |
|---|---|
| Status "Installed: No" | `uv` not on PATH or the Jarvis folder missing; set **Project dir** or install `uv` |
| Status "LiveKit: Missing credentials" | Enter URL/key/secret, or fill `jarvis_new/.env.local` |
| Talk fails "Could not load the LiveKit client" | No internet to reach the jsDelivr CDN |
| Buttons return 403 | `/jarvis/*` writes are loopback-only — open the kiosk on the robot's own machine |
| TALK does nothing / still uses Coda | **Voice brain** still set to Coda, or Jarvis disabled/not running |
| Sidecar exits immediately | Check **Agent log**; usually missing/invalid LiveKit credentials |
| No browser window appears | **Hide the browser window** is on, or the machine is headless (use headless mode) |
| Mic denied | Allow microphone for `localhost`/HTTPS; browser speech/WebRTC needs a secure context |

---

## 13. Security notes & limitations

* **Secrets** (LiveKit key/secret) are stored server-side in
  `data/jarvis_settings.json` with `0600` permissions, are never returned to the
  browser, and are omitted from disk entirely when `CODA_SAVE_KEYS=0`.
* **Token** issuance and all state-changing `/jarvis/*` calls are **loopback-only**
  (same policy as the existing `/ai/configure`), so a LAN client cannot control
  the sidecar or mint credentials.
* The `/robot/*` **read** routes (`GET /robot/motion`, `GET /robot/motion/status`)
  are intentionally **unauthenticated**: they carry no secrets and a kiosk running
  on another device must be able to poll them. Every `/robot/*` **write** route is
  loopback-only like `POST /ai/configure`.
* Jarvis' web browsing is **untrusted input**; the persona already treats page
  content cautiously, and pouring requires explicit confirmation.
* The `livekit-client` browser library is loaded from a CDN on first use; for
  fully offline deployments, vendor it under `/omni/` and point the loader there.
* The sidecar needs the host to have `uv`, internet (Gemini Live + LiveKit
  Cloud), and (for visible browsing) a display. On Termux/mobile the bridge
  degrades gracefully: it reports `available: false` and nothing else changes.

---

## 14. Extension: full AI control of face & hands

A follow-up workstream makes the kiosk **face** and floating **hands** more
natural and gives the robot AI — including **Gemini Live when selected as the
voice brain** — full parameterized control of them. It is deliberately decoupled
from the CODA agent loop through a tiny backend command queue.

### Command schema (one JSON object)

| Field | Values | Meaning |
|---|---|---|
| `type` | `expression` \| `gesture` \| `hands` \| `hide` | What to do |
| `mood` | `happy`, `curious`, … | Face mood (`expression`) |
| `action` | `wave`, `present`, `give`, `swipe`, `point_at`, `beckon`, `thumbs_up`, `tap`, `shrug`, `clap`, `hide`, `show` | Hand action |
| `hand` | `left` \| `right` \| `both` \| `auto` | Which hand(s) |
| `x`, `y` | 0–100 | Anchor position (% of stage) |
| `size` | 1–300 | Scale % (100 = default) |
| `rotation` | −360–360 | Extra rotation (deg) |
| `speed` | 0.25–3 | Motion speed multiplier (1 = natural) |
| `fingers` | `open` \| `fist` \| `point` \| `[f0,f1,f2,f3(,f4)]` | Per-finger articulation (index→little, optional thumb) |
| `appear` / `exit` | `fade` \| `slide-left` \| `slide-right` \| `slide-up` \| `slide-down` \| `scale` \| `none` | How the hand enters/leaves |
| `duration` | seconds | Auto-hide after this long |
| `sticky` | bool | Keep it on screen past `duration` |

All fields are optional; unknown keys are ignored, out-of-range values are
clamped, and a payload that carries **nothing actionable** — an empty object, a
malformed body, or an unrecognised `action` — is rejected with `400` rather than
silently miming a wave. If `type` is omitted it is inferred (`mood`→expression,
`action:hide`→hide, `action:show`→hands, any other valid `action`→gesture).
`duration` is optional; omitting it uses a sensible hold, `duration:0` is a short
flash, and `sticky:true` keeps the hand on screen past `duration`.

### Transport (`Robot-main/motion_bridge.py`)

| Method | Path | Purpose |
|---|---|---|
| POST | `/robot/motion` | Enqueue a full command (loopback-only) |
| GET | `/robot/motion?since=<id>` | `{cursor, commands}` of newer commands (kiosk polls ~400 ms) |
| POST | `/robot/expression` | Convenience: `{mood}` |
| POST | `/robot/gesture` | Convenience: `{action, hand, x, y, size, seconds}` |
| GET | `/robot/motion/status` | `{pending, cursor}` |

### Jarvis tools (`src/robot_tools.py`, kiosk-gated)

* `set_face_expression(mood)`
* `hand_gesture(action, hand, x, y, size, seconds)`
* `control_hands(action, hand, x, y, size, rotation, speed, fingers, appear, exit, duration)`

Gated by `face_control_enabled` / `hands_control_enabled`, which only apply when
`robot_tools_enabled` is on. The kiosk polls `/robot/motion` **only when Jarvis is
enabled**, so the default robot has zero added overhead and is visually
unchanged.

### Kiosk JS API (what the poller applies)

* `window.CodaFace.applyCommand(cmd)` / `.motion(cmd)` — dispatch an
  `expression` / `gesture` / `hands` / `hide` command.
* `window.MotionQueue` — polls `GET /robot/motion?since=<cursor>` every 400 ms
  **only while `config.jarvis.enabled`** (zero overhead when Jarvis is off);
  started/stopped from `updateJarvisUI()`.
* `window.Hands` gained `hide(side, {exit, speed})`, `fingers(side, deg, dur, stagger)`
  and richer `perform()` (honours `rotation`, `speed`, `size`, `x`/`y`, `fingers`,
  `appear`, `exit`, `duration`, `sticky`). Legacy `angle`/`duration` still work,
  so existing CODA callers are unaffected.
* `window.CodaFace.gesture` / `.express` / `.greet` / `.previewMood` are unchanged.

### Settings knobs added

| Where | Setting | Default |
|---|---|---|
| Face (v1 & v2) | Motion speed | 100 % |
| Face (v1 & v2) | Naturalness / smoothing | 100 % |
| Face (v1 & v2) | Occasional double blinks | on |
| Hands | Motion speed | 100 % |
| Hands | Idle sway / breathing | on |
| Hands | Sway period | 5.4 s |
| Hands | Default appear / exit style | `fade` / `fade` |
| Jarvis | Let Jarvis change its face expression | on (gated by robot tools) |
| Jarvis | Let Jarvis move its floating hands | on (gated by robot tools) |

The **Jarvis** tab also has a **Test motion (no Gemini needed)** section with
buttons for every mood, gesture, finger pose, speed, and every appear/exit
style, so the whole path can be verified without a LiveKit session.

### Naturalness

Face: smooth mood cross-fades, saccadic eye movement, natural blink cadence with
occasional double-blinks, subtle breathing. Hands: spring-like easing,
anticipation/overshoot/settle, staggered finger articulation, idle sway, wrist
tilt toward the target, follow-through, and physical appear/disappear. Set the
Face/Hands knobs to `0` (or turn off the toggles, or set `appear`/`exit` to
`none`) to approach the legacy visuals.

### Kiosk JS API & settings

* `window.CodaFace.applyCommand(cmd)` / `window.CodaFace.motion(cmd)` — apply a
  command object directly (also used by omni.js and by the built-in test buttons).
* `window.MotionQueue` — polls `GET /robot/motion?since=<cursor>` every 400 ms
  **only while Jarvis is enabled** (`MotionQueue.sync()` runs from the Jarvis UI
  update), so a default robot has zero added overhead.
* Tuning knobs (persisted with the rest of the kiosk config):
  * Settings → Face → each face (v1 & v2): `motionSpeed`, `naturalness`,
    `doubleBlink`.
  * Settings → Face → hands: `motionSpeed`, `idleSway`, `swayPeriod`, `appear`,
    `exit`.
  * Settings → Jarvis → Robot tools: `face_control_enabled`,
    `hands_control_enabled` (effective only when `robot_tools_enabled` is on),
    plus a **Test motion** area that exercises the exact same command path with
    no Gemini session.

### Hardening applied after independent review

The new code (only) was reviewed and hardened; the pre-existing pump/recipe
endpoints were deliberately left untouched.

* `motion_bridge.py`: non-dict JSON bodies → `400` on every POST; a shared
  `_read_json()` caps the body at 64 KB and guards `RecursionError` (deeply
  nested JSON) → `400`; `?since=` tolerates `Infinity`/`NaN`/garbage; the action
  allowlist (`_ACTIONS` + `_ACTION_ALIASES`) is enforced; an empty body or an
  unrecognised action is now **rejected** (`400`) instead of silently becoming a
  wave; a burst larger than the page size is delivered non-lossily (the oldest
  50 unseen are returned and the cursor advances to the last returned id);
  `seconds` is translated to `duration`.
* `robot_tools.py`: outbound HTTP is restricted to `http(s)`, redirects are
  disabled, and responses are read with a 1 MB cap; `_fingers_payload` guards a
  malformed list; `get_robot_status` guards a missing `/hardware`.
* `jarvis_bridge.py`: non-dict JSON → `400` on `/jarvis/control` and
  `/jarvis/token`.
* `kiosk.html`: the explicit `fingers` pose is no longer reverted by a gesture's
  own delayed finger timers (a per-show finger lock); `MotionQueue` seeds its
  cursor from `/robot/motion/status` on start (a page reload does not replay the
  old backlog) and every poll/seed has a 5 s timeout so a half-open connection
  cannot wedge polling; "Start" persists `enabled=true` before asking the backend
  to start; text controls honour a per-spec `maxLength`; the face/hand speed
  labels are disambiguated.

### How it is verified

* Backend (`PUMP_TRANSPORT=mock`, live server): rich command queued with all
  fields preserved (`hand`, `fingers`, `appear`, `exit`, `duration`, `rotation`,
  `speed`); malformed values clamped (`x:9999→100`, `y:-50→0`,
  `rotation:-9999→-360`, unknown `speed`/`fingers`/`appear` dropped); empty body
  / unknown action / empty expression → `400`; `?since=` cursoring returns only
  newer ids; a 124-command burst is delivered completely (124/124, no gap);
  `POST` from a non-loopback address → `403`; the server stops with no leftovers
  and no `data/` artifacts.
* Jarvis: `ruff check` / `ruff format --check` clean; `pytest` 13 passed; tool
  gating matrix (master + face/hands/pour sub-gates) verified with stubs. The two
  new robot modules are held to the same Python style
  (`ruff check --select E,F,W,I,N,B,A,C4,UP,SIM,RUF` + `ruff format`).
* Kiosk: both inline scripts pass `node --check`; 9 tabs / 9 sections balanced.

> Naturalness/animation correctness is validated by syntax + static review only in
> this environment (no browser available). Defaults (`motionSpeed=100`,
> `naturalness=100`) enable the improved motion; set them low / turn off
> `idleSway`, `doubleBlink`, or set `appear`/`exit` to `none` to approach the
> legacy look.
