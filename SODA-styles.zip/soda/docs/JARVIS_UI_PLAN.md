# Jarvis UI Plan — text bar → Jarvis, user-voice captions, Jarvis-mode UI

**Status:** implementation plan (no source files were edited to produce this doc).
**Scope:** adapt `Robot-main/kiosk.html` (and, only if strictly required, the agent/bridge) so the
Gemini-Live voice agent ("Jarvis") gets the same first-class treatment as the Coda brain.

> **Note on the working tree.** `kiosk.html` is being edited live while this plan was written
> (`git status` shows it untracked; mtime moved during investigation). Many items below are
> **already implemented** in the current file. This plan records them for the record, verifies
> they match the real APIs, and calls out the **remaining gaps**. Line numbers move; all anchors
> below are **exact code strings**, not line numbers.

---

## 0. How the claims in this doc were verified (and the ground-truth rule)

Everything about LiveKit behaviour here was checked against the **installed packages**, which is
the authority. Where the public docs and the installed source disagree, this doc follows the
installed source and says so.

| Thing | Where it was verified |
|---|---|
| Google realtime model kwargs | `.venv/lib/python3.13/site-packages/livekit/plugins/google/realtime/realtime_api.py` (plugin **1.6.10**) |
| `RealtimeModel.__init__` default of `input_audio_transcription` | same file, lines ~221, ~281‑284 |
| Text-stream chat input consumption | `livekit/agents/voice/room_io/room_io.py` (`TOPIC_CHAT`, `_on_chat_text_stream`) |
| Text-stream topic/attribute names | `livekit/agents/types.py` (`TOPIC_CHAT`, `TOPIC_TRANSCRIPTION`, `ATTRIBUTE_TRANSCRIPTION_*`) |
| Transcription is published on **two** paths | `livekit/agents/voice/room_io/_output.py` (`_ParticipantTranscriptionOutput`) |
| Browser API (`sendText`, `registerTextStreamHandler`, `RoomEvent.*`) | the exact UMD the kiosk loads: `https://cdn.jsdelivr.net/npm/livekit-client/dist/livekit-client.umd.min.js` → resolved to **livekit-client 2.23.0** (jsDelivr `x-jsd-version`) |
| Agent worker + dispatch name | `jarvis_new/src/agent.py`, `src/config.py` |
| Token minting / routes | `Robot-main/jarvis_bridge.py` |

**Doc-vs-source discrepancies found (source wins):**

1. The plugin docstring says `input_audio_transcription (…) Defaults to None.` **The code disagrees:**
   ```python
   if not is_given(input_audio_transcription):
       input_audio_transcription = types.AudioTranscriptionConfig()   # ENABLED
   ```
   So **user transcription is ON by default** in this version. The docstring is stale.
2. The multimodality docs say writing the `lk.transcription` text stream "doesn't trigger
   `TranscriptionReceived`", while the migration guide says the framework publishes **both** paths
   simultaneously. **The source confirms the migration guide**: `_ParticipantTranscriptionOutput`
   writes to a legacy sink *and* a stream sink. `TranscriptionReceived` still works today for both
   agent and user speech — but it is deprecated and will be removed, so the plan prefers text
   streams and keeps legacy only as a fallback.
3. The kiosk model dropdown (`LIVEKIT_MODELS`) offers
   `gemini-2.5-flash-preview-native-audio-dialog` and `gemini-2.0-flash-live-001`, neither of which
   is in the plugin's `KNOWN_GEMINI_API_MODELS`/`api_proto.LiveAPIModels`; the *valid* second name
   `gemini-2.5-flash-native-audio-preview-12-2025` is **not** offered. See failure mode F3.

---

## 1. Text bar → Jarvis

### 1.1 The correct, current browser call

```js
// room = a connected LK.Room; requires a token with "canPublishData": true (the bridge grants it).
await room.localParticipant.sendText(text, { topic: 'lk.chat' });
```

- `sendText(text, opts)` on `LocalParticipant` is the current API in **livekit-client 2.23.0**
  (`LocalParticipant.sendText` → `roomOutgoingDataStreamManager.sendText`). It chunks automatically,
  so length is not a problem.
- The **topic must be `'lk.chat'`**. That value is the agents SDK constant `TOPIC_CHAT = "lk.chat"`
  (`livekit/agents/types.py`).
- `sendChatMessage(...)` also exists in 2.23.0 but is the **chat-message** helper, not the agents
  text-input path. `publishData(...)` is the lower-level data-packet API and is **not** what the
  agent listens for. Do not use either.
- The call is **async** and must run only after `await room.connect(...)`.

### 1.2 Agent side — **no change required**

On `session.start(...)`, RoomIO registers a text-stream handler on `lk.chat` unless text input is
explicitly disabled:

```python
# room_io/room_io.py
self._room.register_text_stream_handler(TOPIC_CHAT, self._on_chat_text_stream)
...
async def _read_text() -> None:
    text = await reader.read_all()
    text_input_cb(session, TextInputEvent(text=text, info=reader.info, participant=participant))
```

`RoomOptions.text_input` defaults to `NOT_GIVEN` → `get_text_input_options()` returns
`TextInputOptions()` → `text_input_cb = _default_text_input_cb`:

```python
# room_io/types.py
async def _default_text_input_cb(sess: AgentSession, ev: TextInputEvent) -> None:
    async with sess._claim_user_turn():
        await sess.interrupt()
        sess.generate_reply(user_input=ev.text)
```

`src/agent.py` builds `room_io.RoomOptions(video_input=..., audio_input=...)` **without**
`text_input=...`, so the default callback is installed. Typed text therefore **interrupts Jarvis
and generates a spoken reply with zero agent-side code.**

> Guard: the handler ignores any sender that isn't the RoomIO's *linked participant*
> (`if linked and participant_identity != linked.identity: return`). With one kiosk participant in
> the room this is always satisfied.

### 1.3 What the kiosk already does (verify against current file)

- `JarvisVoice.sendText(text)` — `await this._room.localParticipant.sendText(msg, {topic:'lk.chat'})`.
- `textGoesToJarvis()` + `updateTextBarBrain()` + the `drinkForm.addEventListener('submit', …)`
  branch route the bar to Jarvis when Jarvis is the active/selected text brain.
- New setting `config.jarvis.text_brain` (`'auto' | 'jarvis' | 'coda'`), rendered in
  `renderJarvisControls()` as *"Text bar sends to"*. **Kiosk-local only** — it is intentionally not
  a bridge/agent field (`jarvis_bridge.py` `_sanitize` drops unknown keys, which is fine).

### 1.4 Important subtlety: typed input is **not** echoed back as a caption

The agent does **not** emit a user-transcription event for `lk.chat` input (only the realtime
model's *audio* input produces `input_audio_transcription_completed`). So the browser must echo
typed messages itself. `JarvisVoice.sendText` already does:

```js
this.addLog('you', msg);
showSubtitle('You: ' + msg);
```

If a future refactor drops this, typed messages will vanish from both the log and the subtitles
while Jarvis still answers.

### 1.5 Fallbacks (only if `lk.chat` ever breaks)

1. **Custom data packet + a small agent hook.** Publish a reliable data packet on a custom topic
   (e.g. `kiosk.command`) and register a handler in `agent.py` with
   `ctx.room.register_text_stream_handler("kiosk.command", …)` that calls
   `session.interrupt(); session.generate_reply(user_input=text)`. More moving parts than `lk.chat`;
   use only if the built-in path is unavailable.
2. **RPC** (`room.localParticipant.performRpc` → `session.generate_reply`). Heavier, needs an agent
   RPC method.
3. **A new backend route** (e.g. `POST /jarvis/text`) that pushes into the agent. This needs an IPC
   channel from the Flask bridge to the separate `uv` worker — significant new plumbing. Avoid.

**Recommendation:** keep `lk.chat`; it is the documented, zero-agent-change path and is already used.

---

## 2. User-voice captions

### 2.1 Ground truth: input transcription is already ON

`google.beta.realtime.RealtimeModel` (plugin 1.6.10) default:

```python
input_audio_transcription: NotGivenOr[types.AudioTranscriptionConfig | None] = NOT_GIVEN
...
if not is_given(input_audio_transcription):
    input_audio_transcription = types.AudioTranscriptionConfig()   # enabled
...
capabilities=llm.RealtimeCapabilities(user_transcription=input_audio_transcription is not None)
```

`src/agent.py` currently passes nothing for it, so **Gemini Live already emits input (user)
transcription**, and `capabilities.user_transcription == True` (which suppresses the separate STT
path in `agent_activity.py`). Passing `None` would **disable** it.

### 2.2 Exact kwargs to make it explicit and robust

The only change worth making in `src/agent.py` is to pass it **explicitly** (so a future refactor or
a kiosk option can't silently disable captions), and optionally set the transcription language:

```python
llm=google.beta.realtime.RealtimeModel(
    model=self.cfg.model,
    voice=self.cfg.voice,
    language=self.cfg.language,
    # Explicitly request INPUT (user) transcription. In plugin 1.6.10 this is the
    # default (AudioTranscriptionConfig()), but pass it so it can never drift.
    input_audio_transcription=genai_types.AudioTranscriptionConfig(),
    # Agent (output) transcription is also on by default:
    output_audio_transcription=genai_types.AudioTranscriptionConfig(),
    tool_response_scheduling=genai_types.FunctionResponseScheduling.WHEN_IDLE,
),
```

`genai_types` is already imported in `agent.py` (`from google.genai import types as genai_types`).
`AudioTranscriptionConfig()` accepts optional `language_codes=[...]`/`language_code` in the genai
types if you later want to force a language; leaving it empty is correct here.

> Do **not** pass `input_audio_transcription=None` — that is the only way to turn user captions off.

### 2.3 How the agent delivers those captions — two paths, both live in 1.6.10

`_ParticipantTranscriptionOutput` (source, `_output.py`) fans every transcript out to **both**:

```python
self.__outputs = [
    _ParticipantLegacyTranscriptionOutput(...),   # -> local_participant.publish_transcription()
    _ParticipantStreamTranscriptionOutput(...),   # -> stream_text(topic="lk.transcription")
]
```

- **Legacy sink** → the SFU relays a `transcription` packet → browser emits
  `LK.RoomEvent.TranscriptionReceived(segments, participant, publication)`.
- **Stream sink** → a text stream on topic **`lk.transcription`**, with attributes
  `lk.transcription_final` (`"true"/"false"`), `lk.segment_id`, and `lk.transcribed_track_id`.
  Receive with `room.registerTextStreamHandler('lk.transcription', …)`.

The user-transcription sink is wired in `room_io.py`:

```python
self._user_tr_output = _ParticipantTranscriptionOutput(room=,…, participant=self._participant_identity)
self._user_transcript_ch = utils.aio.Chan[UserInputTranscribedEvent]()
...
async def _forward_user_transcript(event_ch):
    async for ev in event_ch:
        await self._user_tr_output.capture_text(ev.transcript)   # interim OR final body
        if ev.is_final:
            self._user_tr_output.flush()
```

`UserInputTranscribedEvent` is emitted from the realtime model's
`input_audio_transcription_completed` (`is_final=False` while speaking, `is_final=True` on turn
complete).

**Consequence:** the kiosk's existing `TranscriptionReceived` listener should already receive
**both** "Jarvis:" and "You:" segments in the current build.

### 2.4 Why user captions may still be missing/odd, and the fix

Two grounded risks:

1. **Legacy path requires a known microphone track id.** `_ParticipantLegacyTranscriptionOutput.capture_text()`
   returns early when `self._track_id is None`. For the user sink the track id comes from the
   kiosk's published mic track (`_is_local_proxy_participant` + `SOURCE_MICROPHONE`). If a
   transcription beat the track-published event, that segment is dropped. The stream path has no
   such dependency.
2. **Deprecation.** LiveKit states `TranscriptionReceived` "will be removed in a future version."
   The CDN URL is unpinned, so a future `livekit-client` could drop it and captions would vanish.

**Recommendation: make `lk.transcription` text streams the primary path and keep legacy only as a
fallback — but never listen to both at once, or every line renders twice.**

#### 2.4.1 Text-stream handler (primary), copy-pasteable

```js
// Call once after room.connect(), before/independent of the mic.
function registerJarvisTranscriptions(room, LK, onSegment){
  const ATT_FINAL = 'lk.transcription_final';      // "true" | "false"
  const ATT_TRACK = 'lk.transcribed_track_id';     // SID of the transcribed mic track

  room.registerTextStreamHandler('lk.transcription', async (reader, participantInfo) => {
    let text = '';
    try{ text = await reader.readAll(); }            // reader can be consumed once
    catch(e){ console.warn('lk.transcription stream failed', e); return; }
    text = String(text || '').replace(/\s+/g,' ').trim();
    if(!text) return;

    const attrs   = (reader.info && reader.info.attributes) || {};
    const isFinal = attrs[ATT_FINAL] === 'true';
    const segId   = attrs['lk.segment_id'] || (reader.info && reader.info.id) || text;

    // Attribute the segment: if the transcribed track SID is our own mic, it is the user.
    let mine = false;
    try{
      const myMicSid = localMicTrackSid(room, LK);
      mine = myMicSid ? (attrs[ATT_TRACK] === myMicSid)
                      : !!(participantInfo && room.localParticipant &&
                           participantInfo.identity === room.localParticipant.identity);
    }catch(e){}
    onSegment(mine ? 'you' : 'jarvis', segId, text, isFinal);
  });
}

function localMicTrackSid(room, LK){
  try{
    const pub = room.localParticipant.getTrackPublication(LK.Track.Source.Microphone);
    return pub && pub.trackSid ? pub.trackSid : '';
  }catch(e){ return ''; }
}
```

#### 2.4.2 Flicker-free segment buffer (copy-pasteable)

Interim and final arrive as **separate streams sharing `segment_id`** and the interim text is the
*whole* segment so far (not a delta). Buffer per `segment_id`, and commit on final:

```js
// Add to the JarvisVoice object:
_segs: {},                                   // segId -> {who, text, final}
_onSegment(who, segId, text, isFinal){
  const prev = this._segs[segId] || (this._segs[segId] = {who, text:'', final:false});
  prev.who = who;
  prev.text = text;                          // replace: interim is cumulative
  prev.final = isFinal;

  // oldest-committed + live tail
  const parts = [];
  for(const k in this._segs){
    const s = this._segs[k];
    if(s.who === who && s.text) parts.push(s.text);
  }
  const shown = parts.join(' ').replace(/\s+/g,' ').trim();
  if(shown) showSubtitle((who === 'jarvis' ? 'Jarvis: ' : 'You: ') + shown);
  if(who === 'jarvis') setMode('speaking','JARVIS');

  if(isFinal){
    this.addLog(who, text);
    if(who === 'jarvis') reactToText(text);
    delete this._segs[segId];                // commit; stop mixing it into the live caption
  }
},
```

Deduplicate the `_segs` scan to only the current speaker, and prune committed ids so the caption
does not accumulate the whole conversation. (Simplest: keep only the newest `segId` for the live
line and everything else already committed to the log.)

#### 2.4.3 Interim vs final with the legacy path

`TranscriptionSegment` already carries a boolean `.final`; the current `_onTranscript()` reads
`s.final`. That logic is equivalent to the `lk.transcription_final` attribute. Keep whichever single
path you choose.

### 2.5 Attribution summary

| Source | "mine?" test | Notes |
|---|---|---|
| Stream, robust | `attrs['lk.transcribed_track_id'] === localMicTrackSid` | Independent of who the SFU names as sender. |
| Stream, fallback | `participantInfo.identity === room.localParticipant.identity` | The agents framework sets `sender_identity` to the transcribed participant, so this matches. |
| Legacy (`TranscriptionReceived`) | `participant.identity === room.localParticipant.identity` | `handleTranscription` maps `transcribedParticipantIdentity` to `localParticipant` when it matches. |

Flicker rule: **replace** the live caption on interim, **commit** to the log only on final, and
never render the same segment twice (pick one transport).

---

## 3. Jarvis-mode UI adaptation

### 3.1 Blocking TALK when the sidecar is not running (the silent-room bug)

Root cause: the bridge mints a dispatchable token even when the worker isn't running, so
`room.connect()` succeeds and the browser publishes the mic, but **no agent ever joins** → silence.

Current mitigations in the file (keep and verify):

- `JarvisVoice.blocker()` returns the **first** actionable reason, in fix order:
  not enabled → not installed → LiveKit creds missing → **Gemini key missing** → **helper not
  running**. `start()` shows it and aborts instead of connecting to an empty room.
- `shouldHandleTalk()` only routes to Jarvis when `status.available`.
- `_watchForAgent(room)` + `_seeAgent(room)`: for ~10 s after connect, if no remote participant
  (other than self) appears, it says *"No Jarvis agent joined the room. Press 'Start Jarvis', then
  check the Gemini key and the Agent log."* This is the backstop for a token that dispatches to a
  dead/renamed worker.

**Gap to close:** `status.running` is only refreshed when the Jarvis tab is opened
(`refreshJarvis()` is called on tab click and on load). If the sidecar dies while the tab is
closed, `blocker()` can use a stale `running:true`. Fix: poll `GET /jarvis/status` on a slow
interval (e.g. 5 s) whenever `config.jarvis.enabled`, or re-check immediately inside
`JarvisVoice.start()` and abort before minting a token.

### 3.2 Distinct warnings

`blocker()` already separates the important cases. Make sure the UI can tell them apart visually:

- not installed → "Jarvis is not installed or runnable on this computer." (grey/info)
- LiveKit missing → "LiveKit credentials are missing (Jarvis tab, LiveKit connection)."
- **Gemini key missing → "Gemini API key is missing (Jarvis tab, Google Gemini)."** (`status.google_configured`)
- helper not running → "The Jarvis helper is not running — press 'Start Jarvis' on the Jarvis tab."

`renderJarvisStatus()`/`jarvisStatus` should show **Google: Configured / Missing** as its own row
(the bridge returns `google_configured` and `_public_settings().google_api_key_set`).

### 3.3 Visual state: connecting / listening / thinking / speaking

Keep the single state machine (`setMode`) and drive it from **both** signals:

| State | Trigger |
|---|---|
| IDLE | before connect, after stop/disconnect |
| CONNECTING | shown while minting the token + `room.connect()` (add an explicit `setMode('thinking','CONNECTING')` or a dedicated label) |
| LISTENING | `setMicrophoneEnabled(true)` done; and when `ActiveSpeakersChanged` has no non-local speaker |
| SPEAKING (JARVIS) | `ActiveSpeakersChanged` includes a non-local speaker, **or** an agent transcript segment arrives |
| THINKING | typed message sent (`sendText`), or user speech detected but no reply yet |

Current code sets `listening`/`speaking` from `ActiveSpeakersChanged` and `speaking` from
`_onTranscript`. Add `thinking` on `sendText()` (already done) and a `CONNECTING` label during
`start()`.

### 3.4 Mic-level indicator (missing)

There is no mic meter today. `livekit-client` 2.23.0 has **no** `RoomEvent.AudioLevel`, but
`LocalParticipant.audioLevel` (0..1) is updated by the SDK, and
`RoomEvent.LocalAudioSilenceDetected` exists. Poll the level on a light interval while the room is
active:

```js
// inside JarvisVoice.start(), after connect:
clearInterval(this._levelTimer);
this._levelTimer = setInterval(()=>{
  if(!this.active || !this._room){ clearInterval(this._levelTimer); return; }
  const lvl = this._room.localParticipant.audioLevel || 0;   // 0..1
  const el = document.getElementById('jarvisMicLevel');
  if(el) el.style.setProperty('--lvl', Math.min(1, lvl * 4).toFixed(2));
}, 100);
// in _teardown(): clearInterval(this._levelTimer);
```

Add a small bar/ring element (`#jarvisMicLevel`) and a `--lvl` CSS transform. `audioLevel` is only
meaningful while the mic is enabled; show "muted" if `localParticipant.getTrackPublication(Source.Microphone)` is absent.

### 3.5 Conversation log pane (present)

- HTML: `<div id="jarvisChat" class="jarvisChat" …>` with `.chatYou` / `.chatJarvis` styling.
- `JarvisVoice.addLog(who, text)` keeps the last 200 rows; `renderJarvisChat()` renders them; the
  "Clear conversation" button calls `JarvisVoice.clearLog()`.
- Both `_onTranscript` (voice/final) and `sendText` (typed) feed it. **Remaining bug:** the
  `jarvisClearChat` click handler is registered **twice** (duplicate
  `document.getElementById('jarvisClearChat').addEventListener(...)` lines). It is harmless
  (idempotent) but should be deduped.

### 3.6 Text bar switches target (present)

`textGoesToJarvis()` reads `config.jarvis.text_brain` (`auto`/`jarvis`/`coda`); `updateTextBarBrain()`
toggles `#drinkForm.jarvis-target` (button turns cyan), swaps the placeholder ("Ask Jarvis…" vs
"Describe your drink...") and the button label (`ASK` vs `MAKE`). Call `updateTextBarBrain()` from
`updateJarvisUI()` **and** after any change to `text_brain`, so the bar reflects the choice live
(not only on tab open).

### 3.7 Agent disconnects mid-session

Today only `RoomEvent.Disconnected` is handled (`_onDisconnect()`). Add the reconnection states so a
transient drop doesn't strand the UI:

```js
room.on(LK.RoomEvent.Reconnecting, ()=>{
  if(!this.active) return;
  setJarvisMsg('Connection to Jarvis lost — reconnecting…');
  showSubtitle('Reconnecting to Jarvis…');
  setMode('thinking','RECONNECTING');
});
room.on(LK.RoomEvent.Reconnected, ()=>{
  if(!this.active) return;
  setJarvisMsg('Reconnected to Jarvis.');
  setMode('listening','LISTENING');
  // Report presence again; the agent may or may not have returned.
  this._agentSeen = false; this._watchForAgent(room);
});
room.on(LK.RoomEvent.Disconnected, ()=>{
  if(!this.active) return;
  this.active = false; this._room = null; this._agentSeen = false;
  clearInterval(this._presenceTimer); clearInterval(this._levelTimer);
  setMode('idle','IDLE');
  setJarvisMsg('Jarvis disconnected. Press TALK to reconnect.');
  showSubtitle('Jarvis disconnected.');
  updateJarvisUI();
});
```

Also treat the **agent leaving while the room stays up** (`RoomEvent.ParticipantDisconnected` for a
non-local participant) as "agent disconnected": re-arm `_watchForAgent` and warn, rather than
leaving the user talking to a room with no agent.

---

## 4. Failure modes + verification

### 4.1 Every silent-failure path and its detector

| # | Failure | Symptom | Detector / fix |
|---|---|---|---|
| F1 | **No agent worker running** but token still dispatches | Room connects, mic live, silence | `status.running` (bridge) at `blocker()`; `_watchForAgent()` "No Jarvis agent joined"; `GET /jarvis/log` tail |
| F2 | **Worker running, no Gemini key** | Worker may exit at boot, or start then fail the Gemini WS handshake | Bridge **refuses to start** the sidecar without a Google key (`start()` → "Gemini API key is missing…"); `status.google_configured=false`; `blocker()` shows the Gemini-specific message; agent log shows the `ValueError: API key is required…` from `RealtimeModel.__init__` |
| F3 | **Model name rejected** | Session setup fails; no reply; agent log WebSocket error (often `1008 policy violation`) | `_get_1008_error_hint()` in the plugin logs a model-vs-API hint. The dropdown offers names not in `LiveAPIModels` (`gemini-2.5-flash-preview-native-audio-dialog`, `gemini-2.0-flash-live-001`) → **trim the dropdown to the two known-good names** and default to `gemini-3.1-flash-live-preview`. Detection: user gets no spoken reply + agent log shows the WS error. |
| F4 | **Token room mismatch** | Browser in room A, agent dispatched to room A but user expects B | Ensure the `/jarvis/token` request `room` == `config.jarvis.room_name` == the value the operator expects; log the room name from the token response and display it in `renderJarvisStatus` |
| F5 | **`agent_name` mismatch bridge↔worker** | Room connects, agent never joins | Worker registers at boot from `JARVIS_CONFIG.agent_name` (`_BOOT_CONFIG`), and the bridge mints `roomConfig.agents=[{agentName: cfg.agent_name}]` from the **same** settings file. Mismatch only if the worker is started **manually without `JARVIS_CONFIG`** (defaults to `my-agent`) while kiosk `agent_name` differs. Detection: `_watchForAgent` "no agent joined"; fix by always starting via the bridge ("Start Jarvis"/"Restart & apply"). |
| F6 | **Mic permission denied / no mic** | Token minted, `setMicrophoneEnabled(true)` rejects | `start()`'s `catch` aborts and shows the error; add an explicit "Allow microphone for localhost/HTTPS" hint on `NotAllowedError`/`NotFoundError`. `window.isSecureContext` is already checked for Coda's SpeechRecognition — reuse it as a pre-flight note. |
| F7 | **livekit-client CDN unreachable** | "Could not load the LiveKit client (check internet access)." | `loadLiveKitClient()` rejects; surfaced by `start()`. Pin the version and/or vendor under `/omni/` for offline (see §5). |
| F8 | **Captions duplicated or absent** | Two lines per utterance, or none | Duplicated ⇒ two transports active (remove one). Absent ⇒ legacy path's `_track_id` race, or a future client dropped `TranscriptionReceived` ⇒ the stream handler fixes it. |
| F9 | **Typed text gets no confirmation** | Input clears, nothing in log/subtitles | Local echo is required (see §1.4); verify `sendText()` still calls `addLog`/`showSubtitle`. |

### 4.2 Manual test procedure

Preconditions: kiosk open on `localhost` (secure context), Settings → Jarvis.

1. **Pre-flight (no room yet).** Jarvis tab: confirm rows read State=Running, Installed=Yes,
   LiveKit=Configured, **Google=Configured**, Agent=`my-agent` (or your dispatch name).
   *Expect:* no error banner; Agent log shows a startup line.
2. **Negative test — stop the helper.** Press **Stop**, then **TALK**.
   *Expect:* TALK does **not** connect; subtitle/banner says "The Jarvis helper is not running —
   press 'Start Jarvis'…". No audio, no empty room.
3. **Negative test — kill the room, keep the UI.** Start Jarvis, TALK, then press **Restart & apply**.
   *Expect:* the presence watcher warns if the agent doesn't rejoin; no silent stall.
4. **Voice round-trip.** Press **TALK**, allow the mic.
   *Expect:* brief "Connecting…"; then LISTENING. Say *"Jarvis, you there?"*.
   *Expect:* `ActiveSpeakersChanged` flips to SPEAKING/JARVIS; a **"You: …"** caption appears (user
   transcription), followed by a **"Jarvis: …"** caption/speech. Agent log shows the generation.
5. **Caption attribution.** Watch the subtitles while speaking. *Expect:* interim text grows without
   flicker, commits once; "You:" never shows Jarvis' words and vice-versa. (If both appear twice,
   disable one transport.)
6. **Typed round-trip.** With Jarvis up, type *"open YouTube"* in the bar (placeholder should read
   "Ask Jarvis…" and the button should read ASK/cyan). Submit.
   *Expect:* the input clears; the conversation pane immediately shows **You: open YouTube** (local
   echo); state → THINKING; then Jarvis speaks and an agent caption appears. Agent log shows the
   browser tool call.
7. **Text-brain switch.** Set "Text bar sends to" = *Always Coda (drink flow)*. Type *"make me a
   berry soda"*. *Expect:* the CODA recipe flow (overlay/recipe), **not** Jarvis.
8. **Mic meter.** While TALKing, speak; *Expect:* the level indicator moves; silence parks it near 0.
9. **Disconnect handling.** Stop Jarvis from the tab while TALKing. *Expect:* clear "disconnected"
   message, state returns to IDLE, mic released, no orphan audio element.
10. **Agent log cross-check.** For every negative test, open the Agent log
    (`GET /jarvis/log`), which should contain the concrete Python error (missing key, bad model, WS
    close code). Match each browser message to a log line.

### 4.3 Automated checks worth adding

- Extend `jarvis_new/tests/` with a test asserting `RealtimeModel` is constructed with
  `input_audio_transcription` not `None` (guards §2.1 against drift).
- A tiny `node --check` pass on the kiosk script blocks (already used in
  `docs/JARVIS_INTEGRATION.md` §10) after edits.

---

## 5. Remaining work checklist (concrete)

All anchors are exact strings in the current `kiosk.html` / `src/agent.py`.

- [ ] **`src/agent.py`** — in `google.beta.realtime.RealtimeModel(...)` inside `class Assistant.__init__`,
      add `input_audio_transcription=genai_types.AudioTranscriptionConfig()` (and optionally
      `output_audio_transcription=...`). No other agent change is needed for text input.
- [ ] **`kiosk.html`** — make text streams the primary caption transport: on `const room = new LK.Room(...)`
      in `JarvisVoice.start()`, call `room.registerTextStreamHandler('lk.transcription', …)` and route
      to a per-`segment_id` buffer (`_onSegment`), then **remove** the
      `if(LK.RoomEvent.TranscriptionReceived){ … }` block (or gate it behind a feature flag) to avoid
      double rendering.
- [ ] **`kiosk.html`** — add `RoomEvent.Reconnecting` / `Reconnected` / `ParticipantDisconnected`
      handlers next to `room.on(LK.RoomEvent.Disconnected, …)` (see §3.7).
- [ ] **`kiosk.html`** — add the mic-level poll (`#jarvisMicLevel`) and clear it in `_teardown()`.
- [ ] **`kiosk.html`** — poll `/jarvis/status` every ~5 s while `config.jarvis.enabled`, so
      `blocker()`/TALK see a stopped helper without reopening the tab.
- [ ] **`kiosk.html`** — call `updateTextBarBrain()` from `updateJarvisUI()` and after the
      `text_brain` control changes.
- [ ] **`kiosk.html`** — dedupe the duplicated `jarvisClearChat` click listener.
- [ ] **`kiosk.html`** — trim `LIVEKIT_MODELS` to the two plugin-valid names
      (`gemini-3.1-flash-live-preview`, `gemini-2.5-flash-native-audio-preview-12-2025`), or add
      the valid name and drop the two unknown ones.
- [ ] **`kiosk.html`** — pin `loadLiveKitClient()`'s CDN URL to a version (verified: `2.23.0`) or
      vendor the UMD under `/omni/` for offline use.
- [ ] **`kiosk.html`** — map `NotAllowedError`/`NotFoundError` from `setMicrophoneEnabled` to a
      specific "allow the microphone" message.

---

## 6. One-paragraph summary

Injecting text needs **one browser line** — `room.localParticipant.sendText(text, {topic:'lk.chat'})`
— and **no agent-side change**, because `AgentSession`/RoomIO already consume `lk.chat` and run the
default *interrupt + `generate_reply(user_input=...)`* callback. User captions are **already
enabled** in `livekit-plugins-google` 1.6.10 (`input_audio_transcription` defaults to an empty but
non-`None` `AudioTranscriptionConfig`); pass it explicitly for safety, and switch the kiosk to the
`lk.transcription` **text stream** (via `registerTextStreamHandler`) as the durable receiver, keeping
`TranscriptionReceived` only as fallback and never both at once. The UI work is mostly states and
guards: block TALK with a reason-specific message when there is no runnable keyed agent, warn
distinctly for the missing Gemini key, drive
connecting/listening/thinking/speaking from `ActiveSpeakersChanged` + transcript segments, add a
`localParticipant.audioLevel` meter, keep the conversation pane fed by both voice and typed turns
(typed turns are echoed locally, not by the agent), and handle reconnection/agent-departure instead
of sitting in a silent room.
