# Air gesture pointer

The kiosk can be driven without touching the screen. The laptop / TV webcam watches for a
**pen grip** made with the thumb, index and middle fingers. When the grip is held, a colourful
glass pointer appears and follows the hand. Hovering a button, slider, toggle, select, text field
or card makes the pointer **grow into a rounded glass outline around that target** — the same
iPad-style highlight in which the cursor itself becomes the shape, rather than shrinking while a
separate button highlight appears. Lift the index finger and put it back down to click — like
clicking the button on a pen.

The pointer is a gallery of 12 live styles: **Glass orb** (the original), minimal dot, hollow
ring, crosshair, comet, star, soap bubble, neon reticle, pixel, classic arrow, petal and ink drop.
Every style uses the same colour, glow, trail, size and morph controls, and the gallery sits at
the top of the Air gesture settings tab.

Older saved settings that do not have `pointer.morphVersion: 2` are migrated once on load: the
old glass-label morph becomes the iPad-style outline, the pointer becomes the target, and the
legacy `700 ms` tap window / `.30` lift delta become `1000 ms` / `.18`. After that marker is
saved, an explicit choice of another morph style is preserved.

Everything runs inside the browser. Camera frames are not uploaded to the backend or to any
cloud service. The only network use is loading MediaPipe the first time (unless the model files
are vendored locally, see [Offline use](#offline-use)).

Reference photos of the intended grip are in the repository root:
`IMG_20261021_001828.jpg`, `IMG_20261021_001833.jpg` and `IMG_20261021_001836.jpg`.

---

## 1. Quick start

1. Start the kiosk normally (`start.sh`, `start.bat`, or `python backend.py`) and open
   **http://localhost:5005/**.
2. Allow camera access when the browser asks. Camera access needs `localhost`, `127.0.0.1`,
   or HTTPS. A plain `http://192.168.x.x` address will be blocked by the browser.
3. Open **Settings (gear) ▸ Air gesture**. The preview should show the mirrored camera and an
   `AIR READY` status after MediaPipe loads (usually 5–15 seconds).
4. Make the pen grip in front of the camera: thumb, index and middle fingertips together,
   ring finger and little finger folded.
5. Keep **thumb + middle** together. Lift the **index** finger, then bring it back down over a
   target to click. The pointer stays alive while the thumb and middle touch.
6. Use **Demo pointer** in the settings panel to test the pointer with the mouse instead of a
   camera. Use **Air gesture lab** for the full-size test page.

If the camera works but the grip is unreliable, use **Learn pinch** / **Learn click** while
holding the real pose, or tune the thresholds in the same panel (section 4).

---

## 2. The gesture model

```
                 index  lifted
                    │
   thumb ───── middle          ← hold pose = pointer alive
        \   /
         pen grip               ← activate pointer
```

| Step | What the hand does | What the kiosk does |
|---|---|---|
| Activate | Thumb, index and middle tips are close; ring + pinky folded | Pointer blooms in with a shimmer |
| Hold | Thumb + middle stay close; index may lift | Pointer keeps following the hand |
| Click | Index lifts clear of the pen-grip baseline, then falls back toward it within `tapWindowMs` | Clicks the morphed target |
| Release | Thumb and middle separate for `releaseFrames` frames | Pointer fades out |

The first click is ignored until `settleMs` has passed after the pointer appears. This prevents
the motion of forming the grip from clicking something by accident.

Index-tap clicks are **adaptive**, because a real hand rarely reaches the fixed `clickUp`
distance. The detector records the thumb–index distance of the pen grip as `tapBase`, then
accepts a lift of `clickLiftDelta` above that baseline (with `clickDown + 0.08` as the minimum).
The tap finishes when the index falls `clickDropDelta` below its peak. If the pointer is over a
target but no lock has happened yet, the click also performs a fresh hit-test at click time, so a
fast tap does not silently miss. The **Index tap** metric shows `down <base>` or `UP <peak>` live.

Two click modes are available:

- **Index finger tap (default)** — lift and lower the index while thumb + middle stay together.
- **Dwell** — keep the pointer still over a target for `dwellMs`. This is the default when the
  contour fallback is active, because contours do not expose individual finger landmarks.
- **Pointer only** — track and morph, but never click.

The contour fallback uses a different trigger: a compact skin-coloured hand shape with no more
than `contourMaxPeaks` finger peaks. It cannot distinguish the index finger from the middle
finger, so use dwell mode with it.

---

## 3. Pages and controls

| Where | What it is for |
|---|---|
| `/` → Settings → **Air gesture** | Live camera preview, 100+ tuning controls, pointer gallery, learn buttons, click test and diagnostics |
| `/airgesture` | Full-size lab: large preview, test buttons, slider, toggle, select, text field and block |
| `/airgesture?demo=1` | Lab that starts in mouse-demo mode (no camera needed) |
| **Demo pointer** button | Mouse moves the same pointer; click a target with the left mouse button |
| **Auto demo** button (lab) | The pointer moves itself and clicks targets repeatedly |
| **Tuning panel** button (lab) | Opens the kiosk settings tab in a new window |

The lab writes to the same `config.air` object as the kiosk, so a change made in either place
applies to both after saving. The settings are part of the normal kiosk export/import file
(`soda_kiosk_config`), and **Reset air gesture** restores the defaults.

### Status pill

The pill in the top-right HUD shows the current state:

| Text | Meaning |
|---|---|
| `AIR STARTING` / `AIR LOADING` | Camera or MediaPipe is starting |
| `AIR READY` | Camera and model are ready, no hand seen yet |
| `AIR LIVE` | Hand seen and pointer active |
| `AIR DEMO` | Mouse/demo mode |
| `AIR CAM ERROR` | Camera or model failed; open settings for the error text |

`Settings ▸ Air gesture` also prints the engine (`landmarker`, `contour`), detection FPS and the
raw pinch metrics. **Copy diagnostics** puts the whole state on the clipboard as JSON.

---

## 4. Tuning guide

All values live under `config.air` and are editable in **Settings ▸ Air gesture**.

### The gesture

| Control | Default | What to change |
|---|---|---|
| `Pinch enter threshold` | `0.78` | Lower = a tighter pinch is required. Raise it if the pointer will not appear. |
| `Pinch hold/release threshold` | `1.10` | Raise it if the pointer disappears while you move. |
| `Require ring + pinky folded` | on | Turn off if folded fingers are uncomfortable. |
| `Ring folded threshold` / `Pinky folded threshold` | `0.95` / `0.90` | Raise these if folded fingers still count as open. |
| `Frames to appear` | `4` | Lower = reacts faster but can trigger accidentally. |
| `Frames to disappear` | `8` | Raise = the pointer survives brief tracking dropouts. |
| `Ignore clicks after appear` | `350 ms` | Raise if forming the grip clicks something. |
| `Click trigger` | index tap | Use **Dwell** if index taps are hard to control. |
| `Index-up threshold` | `1.05` | The fixed ceiling used by the adaptive lift. Lower it if even a large lift will not register. |
| `Index-down threshold` | `0.72` | Must be below the up threshold. Raise if the click fires too early. |
| `Extra lift needed above pen grip` | `0.18` | Adaptive trigger. Lower it if real taps do not click; raise it if tiny index movements click accidentally. |
| `How far the tap must fall` | `0.18` | How far below the peak the index must return before the tap counts. Raise for a more deliberate click. |
| `Tap must finish within` | `1000 ms` | Raise if your lift-and-return is slow. |
| `Dwell time` | `850 ms` | Time required in dwell mode. |
| `Minimum hand confidence` | `0.30` | Lower if the hand is occasionally ignored. |

**Learn pinch** sets `pinchEnter`, `pinchExit`, `ringFoldMax` and `pinkyFoldMax` from the hand
currently in view. **Learn click** sets `clickUp` / `clickDown` from the lifted index. Hold the
pose still for a moment before pressing the button. **Test click on current target** fires the
same click path on whatever is currently under the pointer without using the camera, which
separates a target/click-handler problem from a gesture problem.

### Tracking

| Control | Default | What to change |
|---|---|---|
| `Tracking mode` | wrist-relative | **Wrist-relative** puts the pointer in the centre when the pen grip activates, then moves it relative to that wrist position like a mouse. **Absolute** points at the screen position of the hand. |
| `Wrist travel gain` | `2.2×` | Relative mode only. Raise it if a small wrist movement should cover more screen; lower it for finer control. |
| `Hand anchor point` | palm | `index` feels more like a mouse but jitters more; `pinch` is the pen tip. |
| `Horizontal / vertical sensitivity` | `1×` | Increase if you cannot reach the screen edges. Applies to both modes. |
| `Invert horizontal / vertical` | off | Useful when the camera is mounted behind or upside down. |
| `Active box left/right/top/bottom` | `0.10–0.90` | Absolute mode: the part of the camera frame mapped to the screen. Smaller box = more movement. |
| `Pixel deadzone` | `1.5 px` | Raise to stop small tremors. |
| `Smoothing` | `1.6` | Lower = smoother but laggier; higher = snappier. |
| `Speed responsiveness` | `0.025` | Higher = less lag during fast moves. |
| `Motion prediction` | `28 ms` | Compensates for camera latency. Too high overshoots. |
| `Hold pointer when hand lost` | `420 ms` | How long the pointer coasts after tracking drops. |
| `Hide after release` | `180 ms` | Fade-out delay. |
| `Keep pointer on screen` | on | Clamps the pointer inside the viewport. |

### Pointer and morphing

| Control | Default | What to change |
|---|---|---|
| `Pointer style` | `orb` | Pick from the 12-card gallery or the dropdown: `orb`, `dot`, `ring`, `crosshair`, `comet`, `star`, `bubble`, `neon`, `pixel`, `arrow`, `petal`, `ink`. Switching is live and saved. |
| `Rendering quality` | auto | **Auto** switches to **Lite** on phones/Termux. Lite keeps the colour and motion but removes expensive backdrop blur and full-screen trail work, which stops the camera preview freezing when the pointer activates. Use **Full** on a desktop. |
| `Pointer size` / `Core dot size` | `46` / `13 px` | Overall scale. Some gallery shapes use the size as their bounding box. |
| `Primary / Secondary / Accent colour` | mint / pink / blue | Glass gradient and orbit colours. |
| `Glass opacity`, `Backdrop blur`, `Glass rim width` | `.34`, `12 px`, `1.2 px` | Apple-glass look. |
| `Glow strength`, `Hue rotation`, `Orbit speed` | `80%`, `0°`, `14` | Energy and colour animation. |
| `Motion trail` | `55%` | Comet trail behind fast movement. |
| `Sparkle particles`, `Click particle count` | on, `18` | Click burst. |
| `Pointer scale when locked` | `.42` | Used only when **Pointer becomes the target** is off; otherwise the pointer fades while the morph outline takes over. |
| `Pointer becomes the target` | on | Hides the dot on lock and lets `#agMorph` become the cursor. Turn off to keep the pointer visible and only highlight the target. |
| `Grow from pointer position` | on | The outline starts as a small glass seed where the pointer is and expands into the target. Turn off to fade/snap directly onto the target. |
| `Morph style` | iPad-style outline + highlight | `highlight` is the outline plus translucent fill. `clone` copies the target content, `label` shows a glass label, `outline` is rim-only, `none` disables the overlay. |
| `Morph travel time` | `220 ms` | Time for the seed to travel/grow into the target outline. |
| `Morph padding` | `7 px` | Space between the target and the glass rim. |
| `Magnetic snap radius` | `30 px` | How close the pointer must be before it locks. |
| `Dwell before morph` | `85 ms` | Debounce before locking. |
| `Delay before unmorph` | `140 ms` | Hysteresis when leaving a target. |
| `Morph onto cards/blocks too` | on | Allows large cards to become targets. |
| `Largest block (% of screen)` | `32%` | Prevents a full-screen card from becoming a target. |
| `Sliders follow the pointer live` | on | Moving across a locked slider changes its value; disable to only change on click. |
| `Edge auto-scroll` | on | Scrolls the page when the pointer rests near an edge. |
| `High-contrast pointer` | off | Stronger rim for bright rooms. |
| `Reduce pointer motion` | off | Stops orbit/transition animation. |
| `Hide system mouse cursor` | off | Hides the normal cursor while the kiosk is open. |

The morph overlay is a separate `#agMorph` glass layer. It does not add `:hover` to the real
target and does not steal focus. The original element is only changed by the click handler
(`click`, `input`, `change`, or a custom event).

### Sounds

Sounds are generated with the Web Audio API; there are no audio files to manage. Choose
`glass`, `soft`, `synth` or `retro`, set the volume, and enable/disable individual events:
`appear`, `lock`, `click`, `release`, `error`, `calibrate`, `tick`. **Test** next to each event
plays only that sound.

### Diagnostics

- **Index tap** — live `down <baseline>` / `UP <peak>` value; use it to see whether a real index
  lift is registering before the click fires.
- **Clicks** — total successful gesture/API clicks.
- **Test click on current target** — fires the click path immediately, even before a morph lock.
- **Floating vision overlay** — small always-on-top preview with landmarks and metrics.
- **Draw hand landmarks** — skeleton on the camera preview.
- **Log events to browser console** — `[airgesture]` messages.
- **Restart vision** — reopens the camera without reloading the page.
- **Reset air gesture** — factory defaults for this feature only.

---

## 5. Offline use

By default MediaPipe is loaded from jsDelivr (with unpkg as a fallback) and the hand
model from Google Storage:

- `https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@0.10.14/`
- `https://unpkg.com/@mediapipe/tasks-vision@0.10.14/` (tried if jsDelivr fails)
- `.../wasm/vision_wasm_internal.{js,wasm}` and the non-SIMD variants
- `https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task`

On a machine with internet, run:

```bash
cd Robot-main
python tools/fetch_airgesture_assets.py
```

It downloads the files into `vendor/airgesture/`, writes a `manifest.json` with sizes and
SHA-256 checksums, and verifies everything. Copy that folder to the same relative path on the
robot. `backend.py` serves it at `/vendor/airgesture/<file>`.

Then leave **Model files** on **Auto** (local files are preferred when present) or set it to
**Local /vendor/airgesture only** to guarantee no network request. Use `--check` to verify an
existing copy:

```bash
python tools/fetch_airgesture_assets.py --check
```

If the model cannot load and **Contour fallback tracker** is on, the contour engine starts
instead. It needs no model and no internet, but it is less precise. If you want the fallback
without MediaPipe at all, set **Vision engine** to **Contour tracker only**.

---

## 6. How it is built

### Files

| File | Purpose |
|---|---|
| `airgesture.js` | Camera, MediaPipe/contour tracking, gesture state machine, pointer, morph, sounds, settings UI, public API |
| `airgesture.css` | Glass pointer, orbit/blob/sheen animations, morph overlay, status pill, lab and settings styles |
| `airgesture.html` | Standalone lab page, also served at `/airgesture` |
| `kiosk.html` | Settings tab, script/CSS includes, `window.CodaKiosk` bridge |
| `backend.py` | `/airgesture`, `/omni/airgesture.*`, `/vendor/airgesture/*`, live-reload watch list |
| `tools/fetch_airgesture_assets.py` | Offline MediaPipe downloader and verifier |

### Runtime flow

1. `startCamera()` opens `getUserMedia` at the configured resolution and attaches a hidden
   `<video>`.
2. `loadLandmarker()` dynamically imports `vision_bundle.mjs`, resolves the WASM files, and
   creates a `HandLandmarker` in `VIDEO` mode. On GPU failure it retries with the CPU delegate.
3. A `requestAnimationFrame` loop runs the contour tracker, runs MediaPipe at `vision.fps`, and
   converts 21 landmarks into pinch metrics (normalised distances).
4. `updateGesture()` runs the activation/hold/click state machine.
5. `updatePointer()` applies a One Euro filter, screen mapping, edge clamping and the trail.
6. `updateTarget()` finds the element under the pointer, locks after the delay, hides the pointer
   when `pointerMorph` is on, and asks `Morph.show()` to start a tiny glass seed at the pointer
   and grow it into the target's rounded outline. `Morph.refresh()` keeps the outline in sync
   while sliders/cards resize.
7. `doClick()` calls the same DOM APIs a real pointer would (`click()`, `focus()`, range/select
   events) and dispatches an `airgesture:click` event. If no target is locked yet, it hit-tests
   once more at the click point before giving up.
8. Settings changes call `window.CodaKiosk.saveConfig()` so they are saved with the kiosk.

### Public API

`window.AirGesture` is available on the kiosk, the lab and any page that loads the script:

```js
AirGesture.start();                 // start camera
AirGesture.stop();                  // stop camera and pointer
AirGesture.startDemo(false);        // mouse demo (true = auto demo)
AirGesture.stopDemo();
AirGesture.config                   // live config.air object
AirGesture.save();                  // persist config
AirGesture.state                    // status, active, locked, clickCount, tap...
AirGesture.metrics()                // pinch metrics and contour data
AirGesture.pointerStyles()          // [{id, name}, ...] for the 12-style pack
AirGesture.setPointerStyle('ring'); // live style switch, persisted
AirGesture.click();                 // fire the current target (same path as a gesture)
AirGesture.diagnostics()            // full JSON-safe snapshot
AirGesture.attachPreview(canvas)    // draw the camera preview into a canvas
AirGesture.detachPreview(canvas)
AirGesture.learn('pinch' | 'click')
AirGesture.openSettings()           // open the kiosk settings tab
```

Fired on `document`:

- `airgesture:lock` — `{ type, label }`
- `airgesture:click` — `{ type, label, source }`
- `airgesture:select` — `{ label }` (cards/blocks)

`AirGesture.__test.feedPose('pen' | 'click', timestamp)` feeds a synthetic hand pose. It is
intended for automated tests; it does not open the camera.

### Config shape

```json
{
  "air": {
    "enabled": true,
    "autoStart": true,
    "startDelayMs": 1400,
    "reactFace": true,
    "statusPill": true,
    "vision":  { "source": "camera", "engine": "auto", "assets": "auto", "delegate": "GPU" },
    "gesture": { "pinchEnter": 0.78, "pinchExit": 1.1, "clickMode": "indexTap" },
    "tracker": { "point": "palm", "sensX": 1, "sensY": 1 },
    "pointer": {
      "size": 46, "style": "orb", "pointerMorph": true,
      "morphMode": "highlight", "morphExpandMs": 220, "sliderLive": true
    },
    "sound":   { "enabled": true, "style": "glass", "volume": 55 },
    "debug":   { "showOverlay": false, "drawLandmarks": true }
  }
}
```

`config.air` is merged over the defaults, so an older exported config without newer keys keeps
working.

---

## 7. Troubleshooting

| Symptom | Fix |
|---|---|
| No camera prompt / `AIR NO CAMERA` | Open via `localhost` or HTTPS. Check the OS camera permission and close other apps using the camera. Pick the camera explicitly in **Camera**. |
| `AIR CAM ERROR` | Open **Settings ▸ Air gesture**; the status line includes the engine error. Try **Compute = CPU**, **Vision engine = Contour tracker only**, or **Restart vision**. |
| MediaPipe stays on `AIR LOADING` | The CDN may be blocked. Vendor the assets (section 5) or use the contour engine. |
| Pointer never appears | Watch **Pinch T–I**, **Pinch T–M**, **Ring fold** and **Pinky fold** in the preview. They are normalised distances: smaller means closer/folded. Raise **Pinch enter threshold**, or press **Learn pinch** while holding the grip. |
| Pointer appears then vanishes | Raise **Pinch hold/release threshold** and **Frames to disappear**. Check that the ring/pinky requirement is not fighting your hand shape. |
| Clicks happen while forming the grip | Raise **Ignore clicks after appear** and **Extra lift needed above pen grip**. |
| Clicks are missed | Open Settings and watch the **Index tap** metric: if it stays `down` while you lift, lower **Extra lift needed above pen grip** (try `0.22`), lower **Index-up threshold**, or raise **Tap must finish within**. Tell the two halves apart with **Test click on current target**. Press **Learn click** with the index lifted. |
| The cursor shrinks instead of becoming the button | Turn on **Pointer becomes the target** and set **Morph style = iPad-style outline + highlight**. Ensure **Grow from pointer position** is on. |
| Pointer moves the wrong way | Turn off **Mirror camera**, or enable **Invert horizontal**. |
| Pointer sticks at the top-left / camera freezes when it appears | Update to the current build, then set **Rendering quality = Lite**. Older builds had a `NaN` vertical coordinate and used full-screen backdrop blur, which stalls the camera on phones. Also lower **Motion trail** and turn off **Sparkle particles** if needed. |
| Pointer starts at your hand instead of the centre | Set **Tracking mode = Wrist-relative**. It starts in the middle on every activation. Use **Wrist travel gain** to cover more or less screen. |
| Cannot reach screen edges | Increase **Horizontal/Vertical sensitivity**, raise **Wrist travel gain**, or (absolute mode) shrink the **Active box**. |
| Pointer jitters | Lower **Smoothing** (e.g. `1.0`), raise **Pixel deadzone**, or use the **palm** anchor. |
| Pointer lags | Raise **Smoothing**, raise **Speed responsiveness**, reduce **Capture resolution** or **Vision frame rate**. |
| Hot CPU / low FPS | Use `640x480` or `480x360`, lower **Vision frame rate**, disable **Sparkle particles** and **Motion trail**, turn off **Floating vision overlay**. |
| Morph covers the whole screen | Lower **Largest block (% of screen)** or turn off **Morph onto cards/blocks too**. |
| Slider jumps while passing over it | Turn off **Sliders follow the pointer live**. |
| Preview is mirrored | That is intentional (selfie view). Turn off **Mirror camera** to compare with the raw camera. |
| Sounds do not play | Browsers require a user gesture before audio. Click anywhere in the kiosk once, then test the sound again. Check **Air-gesture sounds** and the individual event toggles. |
| Settings disappeared after an update | The merged defaults restore missing keys, but a reset (**Reset air gesture**) is the cleanest fix. Use the normal settings export first if you want a backup. |

### Safe defaults if you get lost

Open **Settings ▸ Air gesture** and press **Reset air gesture** (or run this in the browser
console while the kiosk is open):

```js
localStorage.removeItem('soda_kiosk_config');
location.reload();
```

That resets **all** kiosk settings, not only air gesture. For only this feature, use the
**Reset air gesture** button.

---

## 8. Performance and privacy notes

- A 640×480 camera at 24 fps plus MediaPipe is comfortable on a modern laptop. On a phone or a
  weak TV stick, use 480×360 / 15–20 fps and the CPU delegate.
- The contour tracker runs at 12 fps by default and only supplies the hand position when the
  landmarker has no hand; it is not a second full-resolution pipeline.
- The video element is 1×1 px and invisible. Only the preview canvas is drawn.
- No frame, landmark, or image is sent to `backend.py`. The server only serves the static files.
- Camera permission is per-origin. Changing from `localhost` to a LAN IP requires granting it
  again.
