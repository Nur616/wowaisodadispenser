#!/usr/bin/env python3
"""Automatic library checker/installer. Run by start.sh and start.bat with the
project's virtualenv Python, so everything lands in .venv (never system Python).

Only the CORE libraries are installed by default. Everything heavy (browsers,
OCR, the Jarvis voice agent) is an *extra*: it is offered with a y/n question on
the first run on a machine and is never downloaded silently. Answers are kept in
.coda_extras, so later runs are quiet and instant.

  python deps.py                  check + install core (asks about extras once)
  python deps.py --force          reinstall the core libraries from scratch
  python deps.py --extras browser,imaging    also install these extras
  python deps.py --extras all     install every extra that fits this machine
  python deps.py --no-extras      core only; never ask
  python deps.py --ask-extras     ask the y/n questions again right now
  python deps.py --list-extras    show what is available and exit
  python deps.py --usb            (Termux) keep real-Arduino USB support installed

Change your answers at any time with:   bash start.sh setup --ask-extras
Env: SKIP_DEPS_CHECK=1 (skip everything), SKIP_BROWSER_DOWNLOAD=1,
     SKIP_CHROMIUM=1 (Termux: never pkg-install a browser),
     CODA_EXTRAS=browser,jarvis (install these without asking; same values as --extras).
"""
import hashlib
import importlib.util
import json
import os
import shutil
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
STAMP = os.path.join(sys.prefix, ".deps_stamp")
EXTRAS_FILE = os.path.join(HERE, ".coda_extras")
IS_WIN = sys.platform == "win32"
BROWSER = os.environ.get("CODA_BROWSER", "auto").strip().lower()  # auto | chrome | firefox (from the launcher)
IS_TERMUX = bool(os.environ.get("TERMUX_VERSION")) or "com.termux" in os.environ.get("PREFIX", "")

# --------------------------------------------------------------------------
# What is installed
# --------------------------------------------------------------------------

# CORE: always installed, small, needed for the robot to run at all.
CORE = {"flask": "flask", "flask_cors": "flask-cors", "serial": "pyserial"}
WIN = {"pycaw": "pycaw", "comtypes": "comtypes"} if IS_WIN else {}

# EXTRAS: never installed unless the user says yes (or passes --extras). Each
# entry lists what to do on a desktop and on Termux; missing pieces are skipped.
EXTRAS = {
    "browser": {
        "label": "Web browser automation — Playwright plus one browser engine",
        "size": "large, hundreds of MB",
        # Desktop: the Python package, then one Playwright browser download.
        "desktop_pip": ["playwright"],
        "playwright_browsers": True,
        # Termux: Playwright has no Android browser builds, so use the Termux one.
        "termux_pkgs": ["x11-repo"],
        "termux_browser": True,
    },
    "imaging": {
        "label": "Screenshot decoding + offline OCR for the ChatGPT reader",
        "size": "medium, tens of MB",
        "desktop_pip": ["pillow", "rapidocr-onnxruntime"],
        "termux_pkgs": ["tesseract"],
    },
    "usb": {
        "label": "Real Arduino over USB (Termux: termux-api + libusb)",
        "size": "small",
        "termux_only": True,
        "termux_pkgs": ["libusb", "termux-api"],
    },
    "jarvis": {
        "label": "Jarvis voice agent packages (uv sync in the jarvis project)",
        "size": "large, hundreds of MB",
        "uv_project": ("jarvis-voice-butler/jarvis_new",),
    },
}

# Aliases so people can name the thing they mean.
ALIASES = {
    "playwright": "browser",
    "chrome": "browser",
    "chromium": "browser",
    "firefox": "browser",
    "ocr": "imaging",
    "tesseract": "imaging",
    "pillow": "imaging",
    "termux-usb": "usb",
    "arduino": "usb",
    "voice": "jarvis",
}


def say(msg):
    print("[deps] " + msg, flush=True)


def have(mod):
    try:
        return importlib.util.find_spec(mod) is not None
    except (ImportError, ValueError):
        return False


def missing(group):
    return [pkg for mod, pkg in group.items() if not have(mod)]


def interactive():
    """Only ask questions when a human is actually watching.

    Note: the launcher pipes our stdout through 'tee', so stdout is never a TTY
    here — the prompt is written to stderr instead and only stdin is tested.
    """
    try:
        return sys.stdin.isatty()
    except (AttributeError, ValueError):
        return False


# --------------------------------------------------------------------------
# Extras: which exist here, which are chosen, how to ask
# --------------------------------------------------------------------------


def available(extra):
    """An extra that makes no sense on this machine is hidden, not offered."""
    spec = EXTRAS.get(extra)
    if not spec:
        return False
    if spec.get("termux_only") and not IS_TERMUX:
        return False
    return True


def available_extras():
    return [name for name in EXTRAS if available(name)]


def catalogue():
    print("Optional extras (nothing here is installed by default):")
    for name in available_extras():
        spec = EXTRAS[name]
        print("  %-9s %s  (%s)" % (name, spec["label"], spec.get("size", "")))
    hidden = [n for n in EXTRAS if not available(n)]
    if hidden:
        print("Not available on this machine: " + ", ".join(hidden))


def normalize_extras(spec):
    """Turn "browser,ocr" / "all" / "none" into a clean list of extra names."""
    text = (spec or "").strip().lower()
    if text in ("", "none", "no", "core", "off"):
        return []
    if text in ("all", "everything", "yes"):
        return available_extras()
    chosen = []
    for part in text.replace(";", ",").split(","):
        name = ALIASES.get(part.strip(), part.strip())
        if name in EXTRAS and available(name) and name not in chosen:
            chosen.append(name)
    return chosen


def parse_extras(argv):
    """Extras named on the command line, or None when the flag was not used."""
    for i, arg in enumerate(argv):
        if arg == "--extras":
            return normalize_extras(argv[i + 1] if i + 1 < len(argv) else "")
        if arg.startswith("--extras="):
            return normalize_extras(arg.split("=", 1)[1])
    return None


def load_extras():
    """The remembered answer, or None when this machine has never been asked."""
    try:
        with open(EXTRAS_FILE, encoding="utf-8") as handle:
            saved = json.load(handle)
        if isinstance(saved, list):
            return normalize_extras(",".join(str(x) for x in saved))
    except (OSError, ValueError):
        pass
    return None


def save_extras(chosen):
    try:
        with open(EXTRAS_FILE, "w", encoding="utf-8") as handle:
            json.dump(sorted(chosen), handle, indent=2)
    except OSError:
        pass


def ask_yes(question, default=False):
    hint = " [Y/n] " if default else " [y/N] "
    # stderr, not stdout: the launcher pipes stdout through 'tee', and we want the
    # question to appear on the terminal even when the log is being captured.
    sys.stderr.write("[deps] " + question + hint)
    sys.stderr.flush()
    try:
        line = sys.stdin.readline()
    except (EOFError, KeyboardInterrupt):
        sys.stderr.write("\n")
        return default
    if line == "":
        sys.stderr.write("\n")
        return default
    answer = line.strip().lower()
    if not answer:
        return default
    return answer in ("y", "yes")


def prompt_extras(current):
    """A y/n question per extra. Everything defaults to No."""
    print()
    say("Optional extras — press Enter to skip any of them.")
    say("The robot runs fine on core only. Change later:  bash start.sh setup --ask-extras")
    chosen = []
    for name in available_extras():
        spec = EXTRAS[name]
        question = "Install %s — %s (%s)?" % (name, spec["label"], spec.get("size", ""))
        if ask_yes(question, default=name in current):
            chosen.append(name)
    print()
    say("Chosen extras: " + (", ".join(chosen) if chosen else "none (core only)"))
    return chosen


# --------------------------------------------------------------------------
# Installing
# --------------------------------------------------------------------------


def pip(*args):
    cmd = [sys.executable, "-m", "pip", "install", "--disable-pip-version-check"] + list(args)
    for attempt in (1, 2):
        if subprocess.call(cmd) == 0:
            return True
        if attempt == 1:
            say("pip failed; retrying once...")
    return False


def termux_pkg(*names):
    if not IS_TERMUX or not shutil.which("pkg"):
        return False
    return subprocess.call(["pkg", "install", "-y"] + list(names)) == 0


def system_browser_binary():
    return (
        any(shutil.which(n) for n in ("google-chrome", "google-chrome-stable", "chrome", "chromium", "chromium-browser"))
        or any(
            os.path.exists(p)
            for p in (
                r"C:\Program Files\Google\Chrome\Application\chrome.exe",
                r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
                "/Applications/Google Chrome.app",
            )
        )
    )


def install_playwright_browsers():
    """One browser engine only — this is the big download people want to skip."""
    if IS_TERMUX or not have("playwright"):
        return True
    if os.environ.get("SKIP_BROWSER_DOWNLOAD") == "1":
        say("Browser download skipped (SKIP_BROWSER_DOWNLOAD=1).")
        return True
    want = []
    if BROWSER == "firefox":
        want = ["firefox"]
    elif BROWSER in ("chrome", "auto") and not system_browser_binary():
        want = ["chromium"]
    if not want:
        say("A system Chrome/Chromium/Firefox is already installed — no Playwright download needed.")
        return True
    say("Downloading the Playwright %s engine (one time, large)..." % want[0])
    if subprocess.call([sys.executable, "-m", "playwright", "install"] + want) != 0:
        say("Browser download failed (non-fatal). Install Chrome/Firefox yourself, or run this again later.")
        return False
    return True


def install_termux_browser():
    if not IS_TERMUX or os.environ.get("SKIP_CHROMIUM") == "1":
        return True
    want_firefox = BROWSER == "firefox"
    name = "firefox" if want_firefox else "chromium"
    found = shutil.which("firefox") if want_firefox else (shutil.which("chromium") or shutil.which("chromium-browser"))
    if found:
        return True
    say("Installing %s for the ChatGPT website provider (one time, large)..." % name)
    if not termux_pkg(name):
        say("Install failed (non-fatal). Run:  pkg install x11-repo %s" % name)
        return False
    return True


def find_uv():
    found = shutil.which("uv")
    if found:
        return found
    for rel in (".local/bin/uv", ".cargo/bin/uv"):
        candidate = os.path.join(os.path.expanduser("~"), rel)
        if os.path.isfile(candidate):
            return candidate
    return None


def install_uv_project(relatives):
    """Prepare the Jarvis voice agent's own virtualenv with uv."""
    project = None
    for rel in relatives:
        for base in (os.path.dirname(HERE), HERE):
            candidate = os.path.join(base, rel)
            if os.path.isfile(os.path.join(candidate, "pyproject.toml")):
                project = candidate
                break
        if project:
            break
    if not project:
        say("Jarvis project not found — skipped.")
        return True
    uv = find_uv()
    if not uv:
        say("'uv' is not installed, so Jarvis was skipped. Install it:  curl -LsSf https://astral.sh/uv/install.sh | sh")
        return False
    env = dict(os.environ)
    # Termux/FAT drives cannot hardlink across filesystems with uv's default.
    env.setdefault("UV_LINK_MODE", "copy")
    say("Preparing the Jarvis voice agent (uv sync) — this can take a while ...")
    if subprocess.call([uv, "sync"], cwd=project, env=env) != 0:
        say("Jarvis setup failed (non-fatal). Try:  cd %s && uv sync" % project)
        return False
    return True


def install_extra(name):
    """Install one extra. Returns True when nothing important failed."""
    spec = EXTRAS[name]
    ok = True
    say("Installing extra '%s' — %s" % (name, spec["label"]))
    if name == "usb":
        return ensure_termux_usb()
    if spec.get("uv_project"):
        return install_uv_project(spec["uv_project"])
    for pkg in (spec.get("desktop_pip", []) if not IS_TERMUX else []):
        if not pip(pkg):
            say("'%s' could not be installed (non-fatal)." % pkg)
            ok = False
    if spec.get("playwright_browsers"):
        ok = install_playwright_browsers() and ok
    if spec.get("termux_pkgs"):
        if not termux_pkg(*spec["termux_pkgs"]):
            say("Termux package install failed (non-fatal): %s" % " ".join(spec["termux_pkgs"]))
            ok = False
    if spec.get("termux_browser"):
        ok = install_termux_browser() and ok
    return ok


def ensure_termux_usb():
    """Make sure termux-api + libusb are present, without reinstalling them."""
    if not IS_TERMUX:
        return True
    import glob

    need = []
    if not glob.glob(os.path.join(os.environ.get("PREFIX", "/usr"), "lib", "libusb-1.0*")):
        need.append("libusb")
    if not shutil.which("termux-usb"):
        need.append("termux-api")
    if not need:
        return True
    say("Installing Termux packages: " + ", ".join(need))
    termux_pkg(*need)
    if not shutil.which("termux-usb"):
        say("Also install the Termux:API app (F-Droid) so Android can grant USB access.")
    return True


# --------------------------------------------------------------------------
# The run
# --------------------------------------------------------------------------


def digest(extras):
    h = hashlib.sha256()
    h.update(
        ("%d.%d|%s|%s|%s" % (sys.version_info[0], sys.version_info[1], sys.platform, BROWSER, ",".join(sorted(extras)))).encode()
    )
    for name in ("requirements.txt", "requirements-desktop.txt"):
        path = os.path.join(HERE, name)
        if os.path.exists(path):
            with open(path, "rb") as handle:
                h.update(handle.read())
    return h.hexdigest()


def usage():
    print(__doc__.strip())


def main():
    argv = sys.argv[1:]
    if "--help" in argv or "-h" in argv:
        usage()
        return 0
    if "--list-extras" in argv:
        catalogue()
        return 0
    if os.environ.get("SKIP_DEPS_CHECK") == "1":
        say("Skipped (SKIP_DEPS_CHECK=1).")
        return 0
    if sys.version_info < (3, 8):
        say("Python 3.8 or newer is required (found %d.%d)." % sys.version_info[:2])
        return 1
    if sys.prefix == getattr(sys, "base_prefix", sys.prefix):
        say("WARNING: not running inside the virtualenv; the launcher should have activated .venv.")

    force = "--force" in argv
    first_run = not os.path.exists(STAMP)

    # ---- decide the extras -------------------------------------------------
    explicit = parse_extras(argv)
    if explicit is None and os.environ.get("CODA_EXTRAS"):
        explicit = normalize_extras(os.environ["CODA_EXTRAS"])
    asked = False
    if explicit is not None:
        chosen = list(explicit)
    else:
        saved = load_extras()
        if saved is not None:
            chosen = saved
        elif interactive():
            # Never asked on this machine before: offer them once.
            chosen = prompt_extras([])
            asked = True
        else:
            chosen = []

    if "--no-extras" in argv:
        chosen = []
    if "--usb" in argv and available("usb") and "usb" not in chosen:
        chosen.append("usb")
    if "--ask-extras" in argv:
        if interactive():
            chosen = prompt_extras(chosen)
            asked = True
        else:
            say("--ask-extras was given but there is no terminal to ask on; keeping the saved choice.")
    if asked or explicit is not None or "--no-extras" in argv or "--usb" in argv:
        save_extras(chosen)

    stamp_ok = (not force) and (not first_run) and open(STAMP).read().strip() == digest(chosen)

    # ---- core --------------------------------------------------------------
    gaps = missing(CORE) + missing(WIN)
    if stamp_ok and not gaps:
        say("Core libraries present (.venv).")
    else:
        if gaps:
            say("Missing: " + ", ".join(gaps))
        else:
            say("Requirements changed or first run; syncing libraries.")
        if not os.path.exists(os.path.join(sys.prefix, ".pip_upgraded")):
            pip("--upgrade", "pip", "setuptools", "wheel")
            with open(os.path.join(sys.prefix, ".pip_upgraded"), "w") as handle:
                handle.write("1")
        if not pip("-r", os.path.join(HERE, "requirements.txt")):
            say("Core install failed. Check your internet connection and run the launcher again.")
        core_gaps = missing(CORE) + missing(WIN)
        if core_gaps:
            say("Could not install: " + ", ".join(core_gaps))
            say("Check your internet connection and run the launcher again (or: python deps.py --force).")
            return 1

    # ---- extras (only the chosen ones) -------------------------------------
    if not stamp_ok:
        for name in chosen:
            install_extra(name)
        with open(STAMP, "w") as handle:
            handle.write(digest(chosen))
    elif "--usb" in argv and available("usb"):
        ensure_termux_usb()

    say("Core ready. Extras on: " + (", ".join(chosen) if chosen else "none"))
    if not chosen:
        say("Add extras any time:  bash start.sh setup --ask-extras")
    return 0


if __name__ == "__main__":
    sys.exit(main())
