"""Queue + HTTP bridge that lets the Jarvis (Gemini Live) agent drive the
kiosk face and its floating hands.

This module is *additive*: it never touches the pump, recipe, or CODA agent
paths. It does one job — keep a small in-memory queue of motion commands:

* the kiosk polls ``GET /robot/motion?since=<id>`` while Jarvis is enabled and
  applies whatever comes back;
* Jarvis' robot tools (``robot_tools.py``) push commands through the ``POST``
  endpoints below.

Everything is best-effort: values are clamped, unknown keys are dropped, and a
bad payload can never raise into the request path. The queue is bounded so it
cannot grow without bound.
"""

from __future__ import annotations

import ipaddress
import math
import threading
from collections import deque

from flask import jsonify, request

# --------------------------------------------------------------------------
# Limits / allowed values (kept in the same shape the kiosk understands)
# --------------------------------------------------------------------------

_MAX_QUEUE = 500  # hard cap on retained commands (oldest dropped)
_MAX_RETURN = 50  # cap on commands returned by a single poll
_MAX_BODY = 64 * 1024  # reject oversized request bodies (defensive)

_MOODS = {
    "calm",
    "content",
    "happy",
    "glee",
    "love",
    "curious",
    "focused",
    "skeptical",
    "annoyed",
    "bored",
    "sad",
    "worried",
    "surprised",
    "scared",
    "exhausted",
    "sleepy",
    "angry",
    "excited",
    "proud",
    "confused",
    "laugh",
    "wink",
}
_ACTIONS = {
    "wave",
    "present",
    "give",
    "swipe",
    "point_at",
    "beckon",
    "thumbs_up",
    "tap",
    "shrug",
    "clap",
    "show",
    "hide",
}
_HANDS = {"left", "right", "both", "auto"}
_FINGERS = {"open", "fist", "point"}
# Actions the kiosk actually implements, plus the aliases it maps (Hands.ALIAS).
# NOTE: keep these sets in sync with kiosk.html — `GESTURES` keys + `Hands.ALIAS`
# for actions, the `moods`/`FV_MAP` tables for moods. A mismatch makes a valid
# action silently fall back to a wave, so treat kiosk.html as the source of truth.
_ACTION_ALIASES = {
    "hello",
    "offer",
    "point",
    "thumbsup",
    "peek",
    "hi",
    "wave_hello",
}
_APPEAR = {
    "fade",
    "slide-left",
    "slide-right",
    "slide-up",
    "slide-down",
    "scale",
    "none",
}
_TYPES = {"expression", "gesture", "hands", "hide"}

# --------------------------------------------------------------------------
# Module state
# --------------------------------------------------------------------------

_LOCK = threading.Lock()
_QUEUE: deque = deque(maxlen=_MAX_QUEUE)
_NEXT_ID = 1
_HELPERS: dict = {}


def _log(msg: str, *args) -> None:
    logger = _HELPERS.get("log")
    try:
        if logger:
            logger.info(msg, *args)
        else:
            print((msg % args) if args else msg)
    except Exception:  # logging must never raise
        pass


# --------------------------------------------------------------------------
# Sanitising helpers
# --------------------------------------------------------------------------


def _num(value, lo: float, hi: float):
    """Coerce to a finite float in [lo, hi]; return None when impossible."""
    try:
        number = float(value)
    except (TypeError, ValueError):
        return None
    if not math.isfinite(number):
        return None
    return max(lo, min(hi, number))


def _enum(value, allowed: set[str]):
    text = str(value or "").strip().lower().replace("_", "-")
    return text if text in allowed else None


def _sanitize_command(raw) -> dict | None:
    """Return a clean command dict, or None if it is unusable."""
    if not isinstance(raw, dict):
        return None

    out: dict = {}

    ctype = str(raw.get("type") or "").strip().lower()
    if ctype in _TYPES:
        out["type"] = ctype

    mood = "".join(
        ch for ch in str(raw.get("mood") or "").strip().lower() if ch.isalpha()
    )
    if mood in _MOODS:
        out["mood"] = mood

    action = (
        str(raw.get("action") or "").strip().lower().replace("-", "_").replace(" ", "_")
    )[:40]
    if action in _ACTIONS or action in _ACTION_ALIASES:
        out["action"] = action

    hand = str(raw.get("hand") or "").strip().lower()
    if hand in _HANDS:
        out["hand"] = hand

    for key, lo, hi in (
        ("x", 0.0, 100.0),
        ("y", 0.0, 100.0),
        ("size", 1.0, 300.0),
        ("rotation", -360.0, 360.0),
        ("speed", 0.25, 3.0),
        ("duration", 0.0, 120.0),
    ):
        if key in raw:
            number = _num(raw.get(key), lo, hi)
            if number is not None:
                out[key] = number

    fingers = raw.get("fingers")
    if isinstance(fingers, (list, tuple)):
        vals = []
        for item in list(fingers)[:5]:
            number = _num(item, -360.0, 360.0)
            if number is not None:
                vals.append(number)
        if vals:
            out["fingers"] = vals
    elif isinstance(fingers, str) and fingers.strip().lower() in _FINGERS:
        out["fingers"] = fingers.strip().lower()

    for key in ("appear", "exit"):
        value = _enum(raw.get(key), _APPEAR)
        if value is not None:
            out[key] = value

    if "sticky" in raw:
        value = raw["sticky"]
        if isinstance(value, str):
            value = value.strip().lower() in ("1", "true", "yes", "on")
        out["sticky"] = bool(value)

    # Infer a type when the caller omitted it.
    if not out.get("type"):
        if out.get("mood"):
            out["type"] = "expression"
        elif out.get("action") == "hide":
            out["type"] = "hide"
        elif out.get("action") == "show":
            out["type"] = "hands"
        elif out.get("action"):
            out["type"] = "gesture"
        else:
            return None  # nothing actionable (empty body / unknown action)

    # An expression is meaningless without a mood; a gesture needs an action
    # (unless the caller explicitly asked for a `hide`, which needs neither).
    if out["type"] == "expression" and not out.get("mood"):
        return None
    if out["type"] == "gesture" and not out.get("action"):
        return None

    return out


# --------------------------------------------------------------------------
# Queue operations
# --------------------------------------------------------------------------


def _enqueue(command: dict) -> int:
    global _NEXT_ID
    with _LOCK:
        cid = _NEXT_ID
        _NEXT_ID += 1
        record = dict(command)
        record["id"] = cid
        _QUEUE.append(record)
        return cid


def _status() -> dict:
    with _LOCK:
        return {"pending": len(_QUEUE), "cursor": _NEXT_ID - 1}


def _since(since: int) -> dict:
    with _LOCK:
        latest = _NEXT_ID - 1
        commands = [dict(c) for c in _QUEUE if int(c.get("id", 0)) > since]
    # Return the OLDEST unseen commands and advance the cursor only as far as we
    # actually returned, so a big burst is delivered over several polls instead
    # of the middle being skipped (which could drop a `hide`).
    if len(commands) > _MAX_RETURN:
        commands = commands[:_MAX_RETURN]
    cursor = int(commands[-1]["id"]) if commands else latest
    return {"cursor": cursor, "commands": commands}


def _local_only() -> bool:
    remote = request.remote_addr or ""
    try:
        if not ipaddress.ip_address(remote).is_loopback:
            return False
    except ValueError:
        return False
    origin = request.headers.get("Origin", "").rstrip("/")
    return not (origin and origin != request.host_url.rstrip("/"))


def _read_json() -> dict | None:
    """Parse an object body, or None for anything malformed/oversized/hostile.

    Never raises: ``get_json`` can raise on deeply-nested (RecursionError) or
    absurdly large bodies, and the module promises a bad payload stays out of
    the request path.
    """
    try:
        length = request.content_length
        if length is not None and length > _MAX_BODY:
            return None
        data = request.get_json(silent=True)
    except Exception:  # defensive: parsing must never raise
        return None
    return data if isinstance(data, dict) else None


# --------------------------------------------------------------------------
# Flask wiring
# --------------------------------------------------------------------------


def init(app, helpers: dict) -> None:
    """Register the ``/robot/*`` motion routes on the shared Flask app."""
    global _HELPERS
    _HELPERS = helpers or {}

    @app.route("/robot/motion", methods=["POST"])
    def robot_motion_post():
        if not _local_only():
            return jsonify(
                {"error": "Motion commands are only accepted on this device."}
            ), 403
        data = _read_json()
        if data is None:
            return jsonify({"error": "bad payload"}), 400
        if "seconds" in data and "duration" not in data:
            data = dict(data)
            data["duration"] = data["seconds"]
        command = _sanitize_command(data)
        if command is None:
            return jsonify({"error": "bad motion command"}), 400
        return jsonify({"queued": _enqueue(command)})

    @app.route("/robot/motion", methods=["GET"])
    def robot_motion_get():
        try:
            since = int(float(request.args.get("since", 0) or 0))
        except (TypeError, ValueError, OverflowError):
            since = 0
        return jsonify(_since(max(0, since)))

    @app.route("/robot/motion/status", methods=["GET"])
    def robot_motion_status():
        return jsonify(_status())

    @app.route("/robot/expression", methods=["POST"])
    def robot_expression():
        if not _local_only():
            return jsonify(
                {"error": "Expression commands are only accepted on this device."}
            ), 403
        data = _read_json()
        if data is None:
            return jsonify({"error": "bad payload"}), 400
        raw = dict(data)
        raw["type"] = "expression"
        if "seconds" in raw and "duration" not in raw:
            raw["duration"] = raw["seconds"]
        command = _sanitize_command(raw)
        if command is None:
            return jsonify({"error": "bad expression command"}), 400
        return jsonify({"queued": _enqueue(command)})

    @app.route("/robot/gesture", methods=["POST"])
    def robot_gesture():
        if not _local_only():
            return jsonify(
                {"error": "Gesture commands are only accepted on this device."}
            ), 403
        data = _read_json()
        if data is None:
            return jsonify({"error": "bad payload"}), 400
        raw = dict(data)
        raw["type"] = "gesture"
        if "seconds" in raw and "duration" not in raw:
            raw["duration"] = raw["seconds"]
        command = _sanitize_command(raw)
        if command is None:
            return jsonify({"error": "bad gesture command"}), 400
        return jsonify({"queued": _enqueue(command)})

    _log("Motion bridge ready (queue cap %d)", _MAX_QUEUE)
