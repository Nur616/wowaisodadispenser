#!/usr/bin/env python3
"""Download the MediaPipe files used by the air-gesture pointer.

The kiosk works out of the box by loading MediaPipe from jsDelivr and the hand
model from Google Storage. That needs internet the first time. Run this script
on a machine with internet, copy the resulting ``vendor/airgesture`` folder to
the robot, and vision will start with no network at all.

Usage
-----
    python tools/fetch_airgesture_assets.py
    python tools/fetch_airgesture_assets.py --check
    python tools/fetch_airgesture_assets.py --version 0.10.14 --force
    python tools/fetch_airgesture_assets.py --dest /media/usb/coda/vendor/airgesture

The client looks in ``/vendor/airgesture`` (served by backend.py). Leave
Settings > Air gesture > Model files on "Auto" and it will prefer these local
files whenever they exist.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import os
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path

DEFAULT_VERSION = "0.10.14"
MODEL_URL = (
    "https://storage.googleapis.com/mediapipe-models/hand_landmarker/"
    "hand_landmarker/float16/1/hand_landmarker.task"
)
MODEL_NAME = "hand_landmarker.task"
CDN_TEMPLATE = "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@{version}/{path}"

# Smallest sensible size for each file. A truncated download or an HTML error
# page must never overwrite a good local copy.
MIN_BYTES = {
    "vision_bundle.mjs": 100_000,
    "wasm/vision_wasm_internal.js": 10_000,
    "wasm/vision_wasm_internal.wasm": 500_000,
    "wasm/vision_wasm_nosimd_internal.js": 10_000,
    "wasm/vision_wasm_nosimd_internal.wasm": 500_000,
    MODEL_NAME: 1_000_000,
}

USER_AGENT = "coda-airgesture-assets/1.0 (+https://github.com/tenvyre/gi)"


def repo_root() -> Path:
    return Path(__file__).resolve().parent.parent


def default_dest() -> Path:
    return repo_root() / "vendor" / "airgesture"


def asset_list(version: str, include_model: bool) -> list[tuple[str, str]]:
    items = [
        (name, CDN_TEMPLATE.format(version=version, path=name))
        for name in MIN_BYTES
        if name != MODEL_NAME
    ]
    if include_model:
        items.append((MODEL_NAME, MODEL_URL))
    return items


def human(n: int) -> str:
    if n >= 1_000_000:
        return f"{n / 1_000_000:.1f} MB"
    if n >= 1_000:
        return f"{n / 1_000:.0f} KB"
    return f"{n} B"


def download(url: str, target: Path, timeout: float, retries: int = 3) -> tuple[int, str]:
    """Download *url* atomically and return (size, sha256)."""
    target.parent.mkdir(parents=True, exist_ok=True)
    last_error: Exception | None = None
    for attempt in range(1, retries + 1):
        tmp_path = None
        try:
            req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(req, timeout=timeout) as response:
                status = getattr(response, "status", 200)
                if status != 200:
                    raise urllib.error.HTTPError(url, status, f"HTTP {status}", response.headers, None)
                digest = hashlib.sha256()
                total = 0
                fd, tmp_name = tempfile.mkstemp(prefix=target.name + ".", suffix=".part", dir=str(target.parent))
                tmp_path = Path(tmp_name)
                with os.fdopen(fd, "wb") as out:
                    while True:
                        chunk = response.read(1024 * 256)
                        if not chunk:
                            break
                        out.write(chunk)
                        digest.update(chunk)
                        total += len(chunk)
            tmp_path.replace(target)
            return total, digest.hexdigest()
        except Exception as exc:  # network, disk, bad HTTP status
            last_error = exc
            if tmp_path is not None:
                try:
                    tmp_path.unlink(missing_ok=True)
                except OSError:
                    pass
            if attempt < retries:
                wait = attempt * 1.5
                print(f"  retry {attempt}/{retries - 1} in {wait:.1f}s: {exc}", file=sys.stderr)
                time.sleep(wait)
    raise RuntimeError(f"could not download {url}: {last_error}")


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 256), b""):
            digest.update(chunk)
    return digest.hexdigest()


def load_manifest(path: Path) -> dict:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        return {}


def verify(dest: Path, include_model: bool) -> tuple[bool, list[str]]:
    problems: list[str] = []
    for name, minimum in MIN_BYTES.items():
        if name == MODEL_NAME and not include_model:
            continue
        path = dest / name
        if not path.is_file():
            problems.append(f"missing {name}")
            continue
        size = path.stat().st_size
        if size < minimum:
            problems.append(f"{name} is only {human(size)} (expected at least {human(minimum)})")
    manifest_path = dest / "manifest.json"
    manifest = load_manifest(manifest_path)
    if not manifest:
        problems.append("missing or unreadable manifest.json")
    else:
        for name, meta in (manifest.get("files") or {}).items():
            if name == MODEL_NAME and not include_model:
                continue
            path = dest / name
            if path.is_file() and meta.get("sha256") and file_sha256(path) != meta["sha256"]:
                problems.append(f"checksum mismatch for {name}")
    return not problems, problems


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Vendor MediaPipe for the Coda air-gesture pointer.")
    parser.add_argument("--version", default=DEFAULT_VERSION, help=f"@mediapipe/tasks-vision version (default {DEFAULT_VERSION})")
    parser.add_argument("--dest", type=Path, default=default_dest(), help="destination folder (default: Robot-main/vendor/airgesture)")
    parser.add_argument("--force", action="store_true", help="download even if a valid manifest already exists")
    parser.add_argument("--check", action="store_true", help="only verify an existing folder; do not download")
    parser.add_argument("--no-model", action="store_true", help="skip hand_landmarker.task (keep an existing model if present)")
    parser.add_argument("--timeout", type=float, default=90.0, help="per-request timeout in seconds (default 90)")
    args = parser.parse_args(argv)

    dest = args.dest.expanduser().resolve()
    include_model = not args.no_model
    dest.mkdir(parents=True, exist_ok=True)

    print(f"MediaPipe tasks-vision {args.version}")
    print(f"Destination: {dest}")

    if args.check:
        ok, problems = verify(dest, include_model=include_model)
        if ok:
            print("OK: every expected file is present and matches manifest.json")
            return 0
        print("Not ready:")
        for problem in problems:
            print(f"  - {problem}")
        return 1

    manifest_path = dest / "manifest.json"
    old_manifest = load_manifest(manifest_path)
    if not args.force and old_manifest.get("version") == args.version:
        ok, problems = verify(dest, include_model=include_model)
        if ok:
            print("Already downloaded and verified. Use --force to fetch again.")
            return 0
        print("Existing copy is incomplete; repairing:")
        for problem in problems:
            print(f"  - {problem}")

    files: dict[str, dict] = {}
    failures: list[str] = []
    for index, (name, url) in enumerate(asset_list(args.version, include_model), start=1):
        target = dest / name
        minimum = MIN_BYTES[name]
        if args.force or not target.is_file() or target.stat().st_size < minimum:
            print(f"[{index}/{len(asset_list(args.version, include_model))}] {name}  <- {url}")
            try:
                size, sha = download(url, target, args.timeout)
            except Exception as exc:
                print(f"  FAILED: {exc}", file=sys.stderr)
                failures.append(name)
                continue
            if size < minimum:
                print(f"  FAILED: got only {human(size)}", file=sys.stderr)
                try:
                    target.unlink(missing_ok=True)
                except OSError:
                    pass
                failures.append(name)
                continue
            print(f"  {human(size)}  sha256 {sha[:16]}…")
        else:
            size = target.stat().st_size
            sha = file_sha256(target)
            print(f"[{index}/{len(asset_list(args.version, include_model))}] {name}  (already present, {human(size)})")
        files[name] = {
            "bytes": size,
            "sha256": sha,
            "url": url,
        }

    if failures:
        print("\nSome files failed. Nothing was deleted; re-run to retry just the missing ones.", file=sys.stderr)
        return 2

    manifest = {
        "version": args.version,
        "generated_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source": "https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision",
        "model": MODEL_URL if include_model else None,
        "files": files,
    }
    tmp = manifest_path.with_suffix(".json.part")
    tmp.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
    tmp.replace(manifest_path)

    ok, problems = verify(dest, include_model=include_model)
    if not ok:
        print("Verification failed after download:", file=sys.stderr)
        for problem in problems:
            print(f"  - {problem}", file=sys.stderr)
        return 3

    total = sum(item["bytes"] for item in files.values())
    print(f"\nDone: {len(files)} files, {human(total)}.")
    print("Settings > Air gesture > Model files = Auto (local first) is ready to use.")
    print("For a fully offline robot, copy this folder to the same path on the robot:")
    print(f"  {dest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
