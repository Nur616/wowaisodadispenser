/* ui.js — shared UI layer for the kiosk.
 *   - icon set (inline SVG, one stroke style)
 *   - interface settings (accent, radius, blur, text size, motion level/speed) stored in localStorage
 *   - a reusable settings drawer that other modules (the music player) register tabs into
 *   - toasts, button ripples, boot sequence, text-change animations
 *   - animated function graph + worked equations (ported from help-me-main, made smoother)
 */
(function () {
  'use strict';
  const $ = (s, r) => (r || document).querySelector(s);
  const root = document.documentElement;
  const frame = document.getElementById('frame');

  /* ================================================================ icons */
  const P = {
    play: '<polygon points="7 4 20 12 7 20 7 4"/>',
    pause: '<rect x="6" y="4" width="4" height="16" rx="1"/><rect x="14" y="4" width="4" height="16" rx="1"/>',
    stop: '<rect x="6" y="6" width="12" height="12" rx="2"/>',
    next: '<polygon points="5 4 15 12 5 20 5 4"/><line x1="19" y1="5" x2="19" y2="19"/>',
    prev: '<polygon points="19 20 9 12 19 4 19 20"/><line x1="5" y1="19" x2="5" y2="5"/>',
    volume: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M15.5 8.5a5 5 0 0 1 0 7"/><path d="M19 5a10 10 0 0 1 0 14"/>',
    mute: '<polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="22" y1="9" x2="16" y2="15"/><line x1="16" y1="9" x2="22" y2="15"/>',
    music: '<path d="M9 18V5l12-2v13"/><circle cx="6" cy="18" r="3"/><circle cx="18" cy="16" r="3"/>',
    globe: '<circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/>',
    layout: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/>',
    sliders: '<line x1="4" y1="21" x2="4" y2="14"/><line x1="4" y1="10" x2="4" y2="3"/><line x1="12" y1="21" x2="12" y2="12"/><line x1="12" y1="8" x2="12" y2="3"/><line x1="20" y1="21" x2="20" y2="16"/><line x1="20" y1="12" x2="20" y2="3"/><line x1="1" y1="14" x2="7" y2="14"/><line x1="9" y1="8" x2="15" y2="8"/><line x1="17" y1="16" x2="23" y2="16"/>',
    gear: '<circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/>',
    x: '<line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/>',
    maximize: '<path d="M8 3H5a2 2 0 0 0-2 2v3m18 0V5a2 2 0 0 0-2-2h-3m0 18h3a2 2 0 0 0 2-2v-3M3 16v3a2 2 0 0 0 2 2h3"/>',
    repeat: '<path d="m17 2 4 4-4 4"/><path d="M3 11v-1a4 4 0 0 1 4-4h14"/><path d="m7 22-4-4 4-4"/><path d="M21 13v1a4 4 0 0 1-4 4H3"/>',
    search: '<circle cx="11" cy="11" r="7"/><line x1="21" y1="21" x2="16.65" y2="16.65"/>',
    scissors: '<circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/>',
    mic: '<path d="M12 2a3 3 0 0 0-3 3v7a3 3 0 0 0 6 0V5a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="22"/>',
    send: '<line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>',
    panelL: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="9" y1="3" x2="9" y2="21"/>',
    panelR: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="15" y1="3" x2="15" y2="21"/>',
    panelT: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="9" x2="21" y2="9"/>',
    panelB: '<rect x="3" y="3" width="18" height="18" rx="2"/><line x1="3" y1="15" x2="21" y2="15"/>',
    float: '<rect x="3" y="3" width="18" height="18" rx="2" stroke-dasharray="3 3"/><rect x="8" y="8" width="10" height="10" rx="2"/>',
    mini: '<rect x="3" y="9" width="18" height="6" rx="3"/>',
    disc: '<circle cx="12" cy="12" r="10"/><circle cx="12" cy="12" r="3"/>',
    eye: '<path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"/><circle cx="12" cy="12" r="3"/>',
    eyeOff: '<path d="M17.94 17.94A10.07 10.07 0 0 1 12 19c-6.5 0-10-7-10-7a18.5 18.5 0 0 1 5.06-5.94"/><path d="M9.9 4.24A9.12 9.12 0 0 1 12 5c6.5 0 10 7 10 7a18.5 18.5 0 0 1-2.16 3.19"/><line x1="1" y1="1" x2="23" y2="23"/>',
    reset: '<path d="M3 12a9 9 0 1 0 3-6.7L3 8"/><path d="M3 3v5h5"/>',
    left: '<path d="m15 18-6-6 6-6"/>', right: '<path d="m9 18 6-6-6-6"/>',
    up: '<path d="m18 15-6-6-6 6"/>', down: '<path d="m6 9 6 6 6-6"/>',
    check: '<path d="M20 6 9 17l-5-5"/>',
    shield: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>',
    image: '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="m21 15-5-5L5 21"/>',
    video: '<polygon points="23 7 16 12 23 17 23 7"/><rect x="1" y="5" width="15" height="14" rx="2"/>',
    download: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="7 10 12 15 17 10"/><line x1="12" y1="15" x2="12" y2="3"/>',
    upload: '<path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/>',
    wave: '<polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>',
    palette: '<circle cx="13.5" cy="6.5" r="1"/><circle cx="17.5" cy="10.5" r="1"/><circle cx="8.5" cy="7.5" r="1"/><circle cx="6.5" cy="12.5" r="1"/><path d="M12 2a10 10 0 0 0 0 20c1.1 0 2-.9 2-2 0-.5-.2-1-.5-1.3-.3-.4-.5-.8-.5-1.3 0-1.1.9-2 2-2h2.3A4.9 4.9 0 0 0 22 10.9C22 6 17.5 2 12 2z"/>',
    play2: '<polygon points="7 4 20 12 7 20 7 4"/>',
    list: '<line x1="8" y1="6" x2="21" y2="6"/><line x1="8" y1="12" x2="21" y2="12"/><line x1="8" y1="18" x2="21" y2="18"/><line x1="3" y1="6" x2="3.01" y2="6"/><line x1="3" y1="12" x2="3.01" y2="12"/><line x1="3" y1="18" x2="3.01" y2="18"/>',
    zap: '<polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"/>'
  };
  const FILLED = { play: 1, pause: 1, stop: 1, next: 1, prev: 1, play2: 1 };
  function icon(name, cls) {
    return '<svg class="ico' + (FILLED[name] ? ' fill' : '') + (cls ? ' ' + cls : '') + '" viewBox="0 0 24 24" aria-hidden="true">' + (P[name] || '') + '</svg>';
  }

  /* ================================================================ storage */
  function store(key, defaults) {
    let data = {};
    try { data = JSON.parse(localStorage.getItem(key) || '{}') || {}; } catch (e) { data = {}; }
    const api = {
      defaults, data: Object.assign({}, defaults, data), listeners: [],
      get(k) { return api.data[k]; },
      set(k, v) { api.data[k] = v; api.save(); api.listeners.forEach(f => f(k, v)); },
      save() { try { localStorage.setItem(key, JSON.stringify(api.data)); } catch (e) {} },
      reset() { api.data = Object.assign({}, defaults); api.save(); api.listeners.forEach(f => f(null, null)); },
      resetKeys(keys) { keys.forEach(k => { api.data[k] = defaults[k]; }); api.save(); api.listeners.forEach(f => f(null, null)); },
      onChange(f) { api.listeners.push(f); },
      exportJSON() { return JSON.stringify(api.data, null, 2); },
      importJSON(text) {
        const obj = JSON.parse(text);
        Object.keys(defaults).forEach(k => { if (k in obj && typeof obj[k] === typeof defaults[k]) api.data[k] = obj[k]; });
        api.save(); api.listeners.forEach(f => f(null, null));
      }
    };
    return api;
  }

  /* ================================================================ interface settings */
  const cfg = store('ui.cfg', {
    accent: '#76c9bb', radius: 10, blur: 16, textScale: 100,
    motion: 'full', speed: 100, ambient: true, grid: true, ripple: true, bootAnim: true
  });
  function applyCfg() {
    const c = cfg.data;
    root.style.setProperty('--ui-accent', c.accent);
    root.style.setProperty('--ui-radius', c.radius + 'px');
    root.style.setProperty('--ui-blur', c.blur + 'px');
    root.style.setProperty('--ui-scale', String(c.textScale / 100));
    root.style.setProperty('--ui-speed', String(100 / Math.max(25, c.speed)));
    root.setAttribute('data-motion', c.motion);
    root.setAttribute('data-ambient', c.ambient ? 'on' : 'off');
    root.setAttribute('data-grid', c.grid ? 'on' : 'off');
    root.style.setProperty('--eye-ui', c.accent);
  }
  cfg.onChange(applyCfg);
  applyCfg();
  const reducedMotion = () => cfg.data.motion === 'off' || (cfg.data.motion === 'auto' && matchMedia('(prefers-reduced-motion: reduce)').matches);

  /* ================================================================ toasts */
  const toastHost = document.createElement('div');
  toastHost.id = 'uiToasts';
  (frame || document.body).appendChild(toastHost);
  function toast(text, iconName, ms) {
    const t = document.createElement('div');
    t.className = 'uiToast';
    t.innerHTML = (iconName ? icon(iconName) : '') + '<span></span>';
    t.lastChild.textContent = text;
    toastHost.appendChild(t);
    while (toastHost.children.length > 3) toastHost.firstChild.remove();
    setTimeout(() => { t.classList.add('out'); setTimeout(() => t.remove(), 360); }, ms || 2600);
  }

  /* ================================================================ HUD buttons */
  const hudRight = document.getElementById('hudRight');
  function hudButton(opts) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = 'iconBtn'; b.id = opts.id || '';
    b.title = opts.label; b.setAttribute('aria-label', opts.label);
    b.innerHTML = icon(opts.icon) + '<i class="dot"></i>';
    b.addEventListener('click', opts.onClick);
    const settings = document.getElementById('settingsBtn');
    if (hudRight) hudRight.insertBefore(b, opts.last ? null : settings);
    return b;
  }

  /* ================================================================ settings drawer */
  const sheet = document.createElement('aside');
  sheet.id = 'uiSheet'; sheet.setAttribute('data-side', 'left'); sheet.setAttribute('aria-label', 'Customize');
  sheet.innerHTML = '<div class="shHead"><h3>Customize</h3><button type="button" class="iconBtn" id="shClose" aria-label="Close">' + icon('x') + '</button></div>' +
    '<div class="shTabs" role="tablist"><i class="shInk"></i></div><div class="shBody"></div>';
  (frame || document.body).appendChild(sheet);
  const shTabs = $('.shTabs', sheet), shBody = $('.shBody', sheet), shInk = $('.shInk', sheet);
  const tabs = {};
  let activeTab = null;

  function moveInk() {
    const b = $('button.active', shTabs);
    if (!b) return;
    shInk.style.left = b.offsetLeft + 'px'; shInk.style.width = b.offsetWidth + 'px';
  }

  function register(tab) {
    tabs[tab.id] = tab;
    const b = document.createElement('button');
    b.type = 'button'; b.dataset.tab = tab.id; b.setAttribute('role', 'tab');
    b.innerHTML = icon(tab.icon || 'sliders') + '<span>' + tab.title + '</span>';
    b.addEventListener('click', () => show(tab.id));
    shTabs.insertBefore(b, shInk);
    tab.btn = b;
  }

  function row(item, st, tab, i) {
    const r = document.createElement('div');
    r.className = 'shRow'; r.style.setProperty('--i', i);
    const id = 'sh_' + tab.id + '_' + item.k;
    const lab = document.createElement('label');
    lab.setAttribute('for', id);
    lab.textContent = item.label;
    if (item.hint) { const s = document.createElement('small'); s.textContent = item.hint; lab.appendChild(s); }
    const ctl = document.createElement('div'); ctl.className = 'ctl';
    const val = st.get(item.k);
    const commit = v => { st.set(item.k, v); refreshWhen(tab); };
    if (item.t === 'toggle') {
      const w = document.createElement('span'); w.className = 'shSw';
      w.innerHTML = '<input type="checkbox" id="' + id + '"><i></i>';
      const inp = $('input', w); inp.checked = !!val;
      inp.addEventListener('change', () => commit(inp.checked));
      ctl.appendChild(w);
    } else if (item.t === 'range') {
      const inp = document.createElement('input'); inp.type = 'range'; inp.id = id;
      inp.min = item.min; inp.max = item.max; inp.step = item.step || 1; inp.value = val;
      const out = document.createElement('output'); out.textContent = val + (item.unit || '');
      inp.addEventListener('input', () => { out.textContent = inp.value + (item.unit || ''); commit(+inp.value); });
      ctl.append(inp, out);
    } else if (item.t === 'select') {
      const sel = document.createElement('select'); sel.id = id;
      item.opts.forEach(o => { const op = document.createElement('option'); op.value = o[0]; op.textContent = o[1]; sel.appendChild(op); });
      sel.value = val;
      sel.addEventListener('change', () => commit(sel.value));
      ctl.appendChild(sel);
    } else if (item.t === 'seg') {
      const sg = document.createElement('div'); sg.className = 'shSeg'; sg.setAttribute('role', 'radiogroup');
      item.opts.forEach(o => {
        const b = document.createElement('button'); b.type = 'button'; b.dataset.v = o[0]; b.title = o[1]; b.setAttribute('aria-label', o[1]);
        b.innerHTML = o[2] ? icon(o[2]) : o[1];
        if (String(val) === String(o[0])) b.classList.add('active');
        b.addEventListener('click', () => { sg.querySelectorAll('button').forEach(x => x.classList.toggle('active', x === b)); commit(o[0]); });
        sg.appendChild(b);
      });
      ctl.appendChild(sg);
    } else if (item.t === 'color') {
      const inp = document.createElement('input'); inp.type = 'color'; inp.id = id; inp.value = val;
      inp.addEventListener('input', () => commit(inp.value));
      ctl.appendChild(inp);
    } else if (item.t === 'number') {
      const inp = document.createElement('input'); inp.type = 'number'; inp.id = id; inp.value = val;
      inp.min = item.min; inp.max = item.max; inp.step = item.step || 1;
      inp.addEventListener('change', () => commit(Math.max(item.min, Math.min(item.max, +inp.value || 0))));
      ctl.appendChild(inp);
    } else if (item.t === 'text') {
      const inp = document.createElement('input'); inp.type = 'text'; inp.id = id; inp.value = val;
      inp.addEventListener('change', () => commit(inp.value));
      ctl.appendChild(inp);
    }
    r.append(lab, ctl);
    r._when = item.when; r._item = item;
    return r;
  }

  function refreshWhen(tab) {
    const st = tab.store;
    shBody.querySelectorAll('.shRow').forEach(r => { if (r._when) r.hidden = !r._when(st.data); });
  }

  function show(id) {
    const tab = tabs[id]; if (!tab) return;
    activeTab = id;
    Object.values(tabs).forEach(t => { t.btn.classList.toggle('active', t === tab); t.btn.setAttribute('aria-selected', t === tab); });
    shBody.innerHTML = '';
    const pane = document.createElement('div'); pane.className = 'shPane';
    let i = 0;
    tab.schema.forEach(item => {
      if (item.g) { const g = document.createElement('div'); g.className = 'shGroup'; g.textContent = item.g; pane.appendChild(g); return; }
      if (item.t === 'note') { const n = document.createElement('p'); n.className = 'shNote'; n.textContent = item.label; pane.appendChild(n); return; }
      pane.appendChild(row(item, tab.store, tab, i++));
    });
    const btns = document.createElement('div'); btns.className = 'shBtns';
    const mk = (ic, text, fn) => { const b = document.createElement('button'); b.type = 'button'; b.innerHTML = icon(ic) + '<span>' + text + '</span>'; b.addEventListener('click', fn); btns.appendChild(b); };
    mk('reset', 'Reset this tab', () => { tab.store.resetKeys(tab.schema.filter(i => i.k).map(i => i.k)); show(id); toast(tab.title + ' reset', 'reset'); });
    mk('download', 'Copy all', () => {
      const text = tab.store.exportJSON();
      (navigator.clipboard ? navigator.clipboard.writeText(text) : Promise.reject()).then(() => toast('Settings copied', 'check'), () => { window.prompt('Copy your settings:', text); });
    });
    mk('upload', 'Paste all', () => {
      const text = window.prompt('Paste settings JSON');
      if (!text) return;
      try { tab.store.importJSON(text); show(id); toast('Settings applied', 'check'); } catch (e) { toast('That is not valid settings JSON', 'x'); }
    });
    pane.appendChild(btns);
    shBody.appendChild(pane);
    refreshWhen(tab);
    requestAnimationFrame(moveInk);
    if (tab.onShow) tab.onShow();
  }

  const Sheet = {
    side(s) { sheet.setAttribute('data-side', s === 'right' ? 'right' : 'left'); },
    open(id) {
      if (!Object.keys(tabs).length) return;
      sheet.classList.add('open');
      show(id && tabs[id] ? id : (activeTab || Object.keys(tabs)[0]));
      if (Sheet.onOpen) Sheet.onOpen();
    },
    close() { sheet.classList.remove('open'); if (Sheet.onClose) Sheet.onClose(); },
    toggle(id) { sheet.classList.contains('open') && (!id || activeTab === id) ? Sheet.close() : Sheet.open(id); },
    get isOpen() { return sheet.classList.contains('open'); },
    register
  };
  $('#shClose', sheet).addEventListener('click', () => Sheet.close());
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && Sheet.isOpen) Sheet.close(); });
  window.addEventListener('resize', moveInk);

  register({
    id: 'interface', title: 'Interface', icon: 'palette', store: cfg,
    schema: [
      { g: 'Look' },
      { k: 'accent', t: 'color', label: 'Accent color' },
      { k: 'radius', t: 'range', label: 'Corner roundness', min: 0, max: 24, unit: 'px' },
      { k: 'blur', t: 'range', label: 'Glass blur', min: 0, max: 40, unit: 'px' },
      { k: 'textScale', t: 'range', label: 'Text size', min: 80, max: 140, unit: '%' },
      { k: 'grid', t: 'toggle', label: 'Background grid' },
      { k: 'ambient', t: 'toggle', label: 'Ambient glow', hint: 'Slow drifting light behind the face' },
      { g: 'Motion' },
      { k: 'motion', t: 'select', label: 'Animations', opts: [['full', 'Full'], ['subtle', 'Subtle'], ['auto', 'Follow system'], ['off', 'Off']], hint: 'Subtle stops looping effects. Use it on a slow TV.' },
      { k: 'speed', t: 'range', label: 'Animation speed', min: 50, max: 200, step: 10, unit: '%' },
      { k: 'ripple', t: 'toggle', label: 'Button ripples' },
      { k: 'bootAnim', t: 'toggle', label: 'Entrance sequence on load' }
    ]
  });

  /* ================================================================ motion hooks */
  // ripple on press
  document.addEventListener('pointerdown', e => {
    if (!cfg.data.ripple || reducedMotion()) return;
    const b = e.target.closest && e.target.closest('button, .tab');
    if (!b || b.disabled || b.classList.contains('plr-noripple')) return;
    const r = b.getBoundingClientRect(), d = Math.max(r.width, r.height) * 2;
    const s = document.createElement('span'); s.className = 'ui-ripple';
    s.style.cssText = 'width:' + d + 'px;height:' + d + 'px;left:' + (e.clientX - r.left - d / 2) + 'px;top:' + (e.clientY - r.top - d / 2) + 'px;';
    b.appendChild(s); setTimeout(() => s.remove(), 620);
  }, { passive: true });

  // restart a short animation whenever an element's text changes
  function watchSwap(el) {
    if (!el) return;
    let last = el.textContent;
    new MutationObserver(() => {
      const now = el.textContent;
      if (now === last || !now) { last = now; return; }
      last = now;
      el.classList.remove('swap'); void el.offsetWidth; el.classList.add('swap');
    }).observe(el, { childList: true, characterData: true, subtree: true });
  }
  ['statePill'].forEach(id => watchSwap(document.getElementById(id)));

  // ambient light behind everything
  if (frame) {
    const w = document.createElement('div'); w.className = 'ui-ambient-wrap';
    w.innerHTML = '<div class="ui-ambient ui-loop a"></div><div class="ui-ambient ui-loop b"></div>';
    frame.insertBefore(w, frame.firstChild);
  }

  // staggered entrance
  function boot() {
    if (!cfg.data.bootAnim) return;
    let i = 0;
    const seq = ['#hwBadge', '#hudRight', '#quickMixes button', '#talkBtn', '#drinkForm'];
    seq.forEach(sel => document.querySelectorAll(sel).forEach(el => { el.style.setProperty('--i', i++); el.classList.add('ui-enter'); }));
    setTimeout(() => document.querySelectorAll('.ui-enter').forEach(el => el.classList.remove('ui-enter')), 2600);
  }

  // swap the kiosk's text buttons for icons
  const settingsBtn = document.getElementById('settingsBtn');
  if (settingsBtn) { settingsBtn.classList.add('iconBtn'); settingsBtn.innerHTML = icon('gear'); settingsBtn.title = 'Settings'; settingsBtn.setAttribute('aria-label', 'Settings'); }
  const talk = document.getElementById('talkBtn');
  if (talk) { talk.innerHTML = icon('mic') + '<span style="margin-left:6px">Talk</span>'; talk.style.display = 'inline-flex'; talk.style.alignItems = 'center'; }
  const make = document.getElementById('generateBtn');
  if (make) { make.innerHTML = icon('send'); make.setAttribute('aria-label', 'Make drink'); make.style.cssText += ';display:grid;place-items:center;'; }
  const keepTalkLabel = new MutationObserver(() => {
    if (talk && !talk.querySelector('svg')) { const t = talk.textContent.trim(); talk.innerHTML = icon('mic') + '<span style="margin-left:6px"></span>'; talk.lastChild.textContent = t; }
  });
  if (talk) keepTalkLabel.observe(talk, { childList: true });

  hudButton({ id: 'uiBtn', icon: 'sliders', label: 'Customize interface', onClick: () => Sheet.toggle('interface') });

  /* ================================================================ animated graph + worked equations */
  const study = document.createElement('section');
  study.id = 'studyView'; study.setAttribute('aria-live', 'polite');
  study.innerHTML = '<button class="iconBtn" id="closeStudy" type="button" aria-label="Close">' + icon('x') + '</button><h2 id="studyTitle"></h2><p id="studyExplanation"></p><ol id="studySteps"></ol><canvas id="mathGraph" aria-label="Function graph"></canvas>';
  (frame || document.body).appendChild(study);
  const mathGraph = $('#mathGraph'), gctx = mathGraph.getContext('2d');
  let currentGraph = null, graphToken = 0, hoverX = null;

  function closeStudy() {
    if (!frame.classList.contains('study-mode')) return;
    graphToken++;
    if (frame.classList.contains('solved-mode')) {
      frame.classList.add('closing');
      setTimeout(() => frame.classList.remove('closing', 'study-mode', 'solved-mode'), 230);
    } else {
      study.style.transition = 'opacity .22s, transform .22s'; study.style.opacity = '0'; study.style.transform = 'translateY(10px)';
      setTimeout(() => { frame.classList.remove('study-mode'); study.style.opacity = study.style.transform = study.style.transition = ''; }, 230);
    }
  }
  $('#closeStudy').addEventListener('click', closeStudy);
  document.addEventListener('keydown', e => { if (e.key === 'Escape' && !Sheet.isOpen) closeStudy(); });
  frame.addEventListener('click', e => { if (e.target === frame && frame.classList.contains('solved-mode')) closeStudy(); });

  const fmt = n => (Math.abs(n) >= 1000 || (Math.abs(n) < .01 && n !== 0)) ? n.toExponential(1) : String(Math.round(n * 100) / 100);
  function geometry() {
    const rect = mathGraph.getBoundingClientRect(), dpr = window.devicePixelRatio || 1;
    mathGraph.width = Math.max(1, Math.round(rect.width * dpr)); mathGraph.height = Math.max(1, Math.round(rect.height * dpr));
    const w = rect.width, h = rect.height, range = 10, scaleX = w / (range * 2), x0 = w / 2, vals = [];
    gctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    const fn = currentGraph.fn;
    for (let px = 0; px <= w; px += Math.max(1, Math.floor(w / 500))) { const y = fn((px - x0) / scaleX); if (Number.isFinite(y)) vals.push(Math.abs(y)); }
    const yRange = Math.max(1.5, Math.min(100, Math.max(...vals, 1) * 1.15));
    let yStep = 0.5;
    if (yRange >= 3) { const raw = yRange / 4, mag = Math.pow(10, Math.floor(Math.log10(raw))), norm = raw / mag; yStep = (norm < 1.5 ? 1 : norm < 3.5 ? 2 : norm < 7.5 ? 5 : 10) * mag; }
    return { w, h, scaleX, x0, y0: h / 2, scaleY: h / (yRange * 2), yRange, yStep };
  }
  function paintGraph(g, progress, hx) {
    const ctx = gctx, { w, h, scaleX, x0, y0, scaleY, yRange, yStep } = g, fn = currentGraph.fn;
    const acc = getComputedStyle(root).getPropertyValue('--ui-accent').trim() || '#76c9bb';
    ctx.clearRect(0, 0, w, h);
    // grid
    ctx.lineWidth = 1; ctx.strokeStyle = 'rgba(120,190,165,.10)';
    for (let n = -10; n <= 10; n++) { const x = x0 + n * scaleX; ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
    const ny = Math.ceil(yRange / yStep);
    for (let n = -ny; n <= ny; n++) { const y = y0 - n * yStep * scaleY; ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }
    // axes
    ctx.strokeStyle = 'rgba(160,215,190,.55)'; ctx.lineWidth = 1.4; ctx.beginPath(); ctx.moveTo(0, y0); ctx.lineTo(w, y0); ctx.moveTo(x0, 0); ctx.lineTo(x0, h); ctx.stroke();
    ctx.fillStyle = 'rgba(160,205,185,.65)'; ctx.font = '10px system-ui,sans-serif';
    ctx.textAlign = 'center'; ctx.textBaseline = 'top';
    for (let n = -8; n <= 8; n += 2) if (n) ctx.fillText(n, x0 + n * scaleX, y0 + 4);
    ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    for (let n = -ny; n <= ny; n++) if (n) ctx.fillText(fmt(n * yStep), x0 + 5, y0 - n * yStep * scaleY - 7);
    // curve up to progress (eased in caller)
    const end = w * progress, pts = [];
    let drawing = false, lastPt = null;
    const curve = new Path2D(), area = new Path2D();
    for (let px = 0; px <= end; px++) {
      const y = fn((px - x0) / scaleX), py = y0 - y * scaleY;
      if (Number.isFinite(py) && Math.abs(py) < h * 3) {
        if (!drawing) { curve.moveTo(px, py); drawing = true; } else curve.lineTo(px, py);
        lastPt = [px, py];
      } else drawing = false;
    }
    ctx.save();
    ctx.lineJoin = 'round'; ctx.lineCap = 'round';
    ctx.shadowColor = 'rgba(241,189,112,.55)'; ctx.shadowBlur = 14;
    ctx.strokeStyle = '#f1bd70'; ctx.lineWidth = 2.6; ctx.stroke(curve);
    ctx.restore();
    if (lastPt && progress < 1) {
      ctx.fillStyle = '#fff3d6'; ctx.beginPath(); ctx.arc(lastPt[0], lastPt[1], 4.2, 0, 7); ctx.fill();
      ctx.strokeStyle = 'rgba(241,189,112,.5)'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(lastPt[0], lastPt[1], 4.2 + 6 * (1 - progress), 0, 7); ctx.stroke();
    }
    // hover tracer (after the draw-in finishes)
    if (progress >= 1 && hx != null) {
      const x = (hx - x0) / scaleX, y = fn(x), py = y0 - y * scaleY;
      ctx.strokeStyle = 'rgba(180,230,210,.3)'; ctx.setLineDash([4, 4]); ctx.beginPath(); ctx.moveTo(hx, 0); ctx.lineTo(hx, h); ctx.stroke(); ctx.setLineDash([]);
      if (Number.isFinite(py)) {
        ctx.fillStyle = acc; ctx.beginPath(); ctx.arc(hx, py, 5, 0, 7); ctx.fill();
        const label = 'x ' + fmt(x) + '   y ' + fmt(y);
        ctx.font = '12px system-ui,sans-serif'; const tw = ctx.measureText(label).width + 16;
        const bx = Math.min(w - tw - 6, Math.max(6, hx + 12)), by = Math.max(6, Math.min(h - 28, py - 34));
        ctx.fillStyle = 'rgba(8,18,15,.92)'; ctx.strokeStyle = 'rgba(120,200,175,.35)';
        ctx.beginPath(); ctx.roundRect ? ctx.roundRect(bx, by, tw, 24, 8) : ctx.rect(bx, by, tw, 24); ctx.fill(); ctx.stroke();
        ctx.fillStyle = '#e9f0ed'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle'; ctx.fillText(label, bx + 8, by + 12);
      }
    }
  }
  let geo = null;
  function drawFunctionGraph(fn, label) {
    currentGraph = { fn, label };
    geo = geometry();
    $('#studyTitle').textContent = label;
    const token = ++graphToken, started = performance.now(), dur = reducedMotion() ? 1 : 1500 * (100 / Math.max(25, cfg.data.speed));
    (function frameLoop(now) {
      if (token !== graphToken) return;
      const p = Math.min(1, (now - started) / dur), eased = 1 - Math.pow(1 - p, 3);
      paintGraph(geo, eased, hoverX);
      if (p < 1) requestAnimationFrame(frameLoop);
    })(started);
  }
  function repaintHover() { if (currentGraph && geo) requestAnimationFrame(() => paintGraph(geo, 1, hoverX)); }
  mathGraph.addEventListener('pointermove', e => { const r = mathGraph.getBoundingClientRect(); hoverX = e.clientX - r.left; repaintHover(); });
  mathGraph.addEventListener('pointerleave', () => { hoverX = null; repaintHover(); });

  function openStudy(expression, explanation) {
    frame.classList.remove('drink-mode', 'solved-mode', 'answer-mode', 'closing');
    frame.classList.add('study-mode');
    $('#studyExplanation').textContent = explanation;
    const normalized = expression.toLowerCase()
      .replace(/\b(sine|cosine|tangent)\b/g, (_, w) => ({ sine: 'sin', cosine: 'cos', tangent: 'tan' }[w]))
      .replace(/\b(sin|cos|tan|ln|log|exp|sqrt|abs)\s+x\b/g, '$1(x)');
    const safe = normalized.replace(/π/g, 'pi').replace(/\^/g, '**').replace(/\bpi\b/g, 'Math.PI').replace(/\be\b/g, 'Math.E')
      .replace(/\b(sin|cos|tan|sqrt|abs|exp)\b/g, 'Math.$1').replace(/\b(ln|log)\b/g, 'Math.log');
    if (!/^[0-9x+*/().\s*-]+$/.test(safe.replace(/Math\.(?:PI|E|sin|cos|tan|sqrt|abs|exp|log)/g, ''))) { frame.classList.remove('study-mode'); return false; }
    let fn;
    try { fn = new Function('x', 'return ' + safe); fn(1); } catch (_) { frame.classList.remove('study-mode'); return false; }
    mathGraph.style.display = 'block'; $('#studySteps').replaceChildren();
    requestAnimationFrame(() => drawFunctionGraph(fn, 'y = ' + normalized));
    return true;
  }
  function handleMathRequest(prompt) {
    prompt = String(prompt || '');
    const trig = prompt.match(/\b(sine|sin|cosine|cos|tangent|tan)\b/i);
    if (trig && /\b(graph|plot|draw|show)\b/i.test(prompt) && !/\b(and|vs|versus)\b/i.test(prompt)) {
      const f = trig[1].toLowerCase().replace('sine', 'sin').replace('cosine', 'cos').replace('tangent', 'tan');
      return openStudy(f + '(x)', 'A live graph of ' + f + '(x). Move over the graph to read values.');
    }
    const graph = prompt.match(/(?:graph|plot|draw|show)\s+(?:me\s+)?(?:the\s+)?(?:graph\s+of\s+)?(?:y\s*=\s*)?(.+?)(?:\s+(?:from|between)\s+.*)?$/i);
    if (graph && !/\b(and|vs|versus|on the same)\b/i.test(prompt)) {
      const expr = graph[1].replace(/[?.!]+$/, '').trim().replace(/^(?:a|the)\s+/i, '').replace(/\s+graph$/i, '');
      if (openStudy(expr, 'A live graph of your function. Move over the graph to read values.')) return true;
    }
    const eq = prompt.match(/(?:(?:solve|what is|find(?: the value of)?)\s+)?(?:for\s+x:?\s*)?(-?(?:\d+(?:\.\d*)?|\.\d+)?)[ \t]*x\s*(?:([+-])\s*(\d*\.?\d*))?\s*=\s*(-?\d+\.?\d*)/i);
    if (eq && (/\b(?:solve|what is|find)\b/i.test(prompt) || (/x/i.test(prompt) && prompt.includes('=')))) {
      const a = eq[1] === '-' ? -1 : Number(eq[1] || 1), b = Number(eq[3] || 0) * (eq[2] === '-' ? -1 : 1), c = Number(eq[4]), x = (c - b) / a;
      if (!Number.isFinite(x) || a === 0) return false;
      frame.classList.remove('drink-mode', 'answer-mode', 'closing'); frame.classList.add('study-mode', 'solved-mode');
      $('#studyTitle').textContent = 'Solution'; $('#studyExplanation').textContent = ''; mathGraph.style.display = 'none';
      const steps = $('#studySteps'); steps.replaceChildren();
      const ax = (a === 1 ? '' : a === -1 ? '−' : a) + 'x';
      const rows = ['Solve ' + ax + (b === 0 ? '' : b < 0 ? ' − ' + Math.abs(b) : ' + ' + b) + ' = ' + c];
      if (b !== 0) rows.push((b > 0 ? 'Subtract ' + b : 'Add ' + Math.abs(b)) + ' from both sides:  ' + ax + ' = ' + (c - b));
      rows.push('Divide both sides by ' + Math.abs(a) + ':  x = ' + (Number.isInteger(x) ? x : Number(x.toFixed(4))));
      rows.forEach((text, index) => { const li = document.createElement('li'); li.textContent = text; li.style.animationDelay = (index * 420 * (100 / Math.max(25, cfg.data.speed))) + 'ms'; if (index === rows.length - 1) li.classList.add('math-final'); steps.appendChild(li); });
      return true;
    }
    return false;
  }
  window.addEventListener('resize', () => { if (frame.classList.contains('study-mode') && currentGraph) { geo = geometry(); paintGraph(geo, 1, hoverX); } });

  /* ================================================================ public API */
  window.UI = { icon, store, cfg, sheet: Sheet, toast, hudButton, reducedMotion, math: { handle: handleMathRequest, close: closeStudy } };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot); else boot();
})();
