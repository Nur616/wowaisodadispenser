TASKS FOLDER — SODA / Coda kiosk
================================
Plain-text work log. Keep these files current on every work session.

  DOING.txt  - what is being worked on right now, current state, how to verify
  TODO.txt   - what will be done next (ordered, with file paths)
  DONE.txt   - finished work, newest first, with dates and verification

Rules:
  - Move items from TODO.txt to DONE.txt only after they are actually verified.
  - Keep entries short; include file:line or command when useful.
  - Date format: YYYY-MM-DD (today's sessions are 2026-10-27).
