@echo off
REM One-command first-time setup for Windows.  Hands over to start.bat setup.
REM
REM   setup.bat                    core libraries; asks one y/n question per extra (first run)
REM   setup.bat --extras all       core + every optional library
REM   setup.bat --extras browser,jarvis
REM   setup.bat --no-extras        core only, never ask
REM   setup.bat --ask-extras       change an earlier answer
REM   setup.bat --list-extras      show what is optional on this PC
REM   setup.bat --reinstall        reinstall the core libraries from scratch
setlocal
cd /d "%~dp0"
call start.bat setup %*
