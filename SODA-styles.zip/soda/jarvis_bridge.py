"""Jarvis (Gemini Live) integration for the CODA robot kiosk.

This module is *additive*: it never touches the pump, recipe, or CODA agent
paths. It does four jobs:

1. Persist Jarvis settings written by the kiosk (``data/jarvis_settings.json``).
2. Translate those settings into the JSON file the Jarvis agent reads at boot.
3. Supervise the Jarvis sidecar process (``uv run src/agent.py start``).
4. Mint short-lived LiveKit room tokens so the kiosk browser can join the room
   and talk to Gemini Live over WebRTC.

It is deliberately dependency-free: tokens are signed with the stdlib so the
robot's own virtualenv stays exactly as it was.

Everything is guarded — if ``uv`` or the Jarvis project is missing, the routes
still answer and simply report ``available: false``. Nothing here can take the
robot backend down.
"""

from __future__ import annotations

import base64
import contextlib
import hashlib
import hmac
import ipaddress
import json
import os
import shutil
import subprocess
import threading
import time
from pathlib import Path

from flask import jsonify, request

# --------------------------------------------------------------------------
# Settings schema
# --------------------------------------------------------------------------

# Every key the kiosk may set. ``_AGENT_FIELDS`` are forwarded verbatim to the
# Jarvis agent config; the rest are robot-side controls.
_AGENT_FIELDS = (
    "model",
    "voice",
    "language",
    "agent_name",
    "persona_name",
    "greeting",
    "sarcasm",
    "extra_instructions",
    "browsing_enabled",
    "browser_headless",
    "browser_start_url",
    "browser_timeout_ms",
    "max_web_chars",
    "turn_detector_enabled",
    "interruption_mode",
    "preemptive_generation",
    "noise_cancellation",
    "video_input",
    "robot_tools_enabled",
    "robot_base_url",
    "allow_pour",
    "face_control_enabled",
    "hands_control_enabled",
)

_SECRET_FIELDS = ("livekit_api_key", "livekit_api_secret", "google_api_key")

# --------------------------------------------------------------------------
# Models, languages and what each model can actually do
# --------------------------------------------------------------------------

# Gemini-API Live models accepted by livekit-plugins-google. Anything else
# either connects then drops silently, or needs a Vertex service account.
LIVE_MODELS: tuple[str, ...] = (
    "gemini-2.5-flash-native-audio-preview-12-2025",
    "gemini-3.1-flash-live-preview",
)

# Language codes each model actually accepts, verified against the Live API.
# The native-audio model is much stricter than the 3.1 preview: it rejects
# en-GB / en-AU / en-IN / es-ES / zh-CN / ar-SA … with Live error 1007
# "Unsupported language code", which otherwise kills the whole session.
_NATIVE_AUDIO_LANGUAGES: tuple[str, ...] = (
    "en-US",
    "es-US",
    "fr-FR",
    "de-DE",
    "it-IT",
    "pt-BR",
    "nl-NL",
    "hi-IN",
    "ja-JP",
    "ko-KR",
    "ru-RU",
    "tr-TR",
    "pl-PL",
    "id-ID",
    "th-TH",
    "vi-VN",
)
MODEL_LANGUAGES: dict[str, tuple[str, ...]] = {
    "gemini-2.5-flash-native-audio-preview-12-2025": _NATIVE_AUDIO_LANGUAGES,
    "gemini-3.1-flash-live-preview": (
        "en-US",
        "en-GB",
        "en-AU",
        "en-IN",
        "es-US",
        "es-ES",
        "fr-FR",
        "de-DE",
        "it-IT",
        "pt-BR",
        "nl-NL",
        "hi-IN",
        "bn-BD",
        "ar-SA",
        "ja-JP",
        "ko-KR",
        "zh-CN",
        "ru-RU",
        "tr-TR",
        "pl-PL",
        "sv-SE",
        "id-ID",
        "th-TH",
        "vi-VN",
    ),
}
MODEL_DEFAULT_LANGUAGE = "en-US"

# The 2.5 native-audio model keeps a mutable chat context, so AgentSession can
# inject the text bar's message with session.generate_reply(). The 3.1 live
# preview cannot, so typed input is refused there instead of hanging on
# "Thinking" forever — voice still works on both.
MODEL_ACCEPTS_TEXT: dict[str, bool] = {
    "gemini-2.5-flash-native-audio-preview-12-2025": True,
    "gemini-3.1-flash-live-preview": False,
}

DEFAULT_SETTINGS: dict = {
    "enabled": False,  # master switch: should the sidecar run?
    "brain": "coda",  # which voice brain the kiosk TALK button uses
    "auto_start": False,  # start the sidecar when the backend boots
    "room_name": "jarvis-room",
    "project_dir": "",  # blank = auto-detect jarvis_new
    "livekit_url": "",
    "livekit_api_key": "",
    "livekit_api_secret": "",
    "google_api_key": "",  # Gemini / Google AI Studio key for the Live model
    "token_ttl_minutes": 60,
    # agent config
    "model": "gemini-2.5-flash-native-audio-preview-12-2025",
    "voice": "Enceladus",
    "language": "en-US",
    "agent_name": "my-agent",
    "persona_name": "Jarvis",
    "greeting": "Good day, Sir",
    "sarcasm": True,
    "extra_instructions": "",
    "browsing_enabled": True,
    "browser_headless": False,
    "browser_start_url": "",
    "browser_timeout_ms": 15000,
    "max_web_chars": 12000,
    "turn_detector_enabled": True,
    "interruption_mode": "adaptive",
    "preemptive_generation": True,
    "noise_cancellation": True,
    "video_input": True,
    "robot_tools_enabled": False,
    "robot_base_url": "http://127.0.0.1:5005",
    "allow_pour": False,
    "face_control_enabled": True,
    "hands_control_enabled": True,
    # Bumped whenever a stored value must be repaired on load (see load_settings).
    "schema_version": 2,
}

_BOOL_KEYS = {
    "enabled",
    "auto_start",
    "sarcasm",
    "browsing_enabled",
    "browser_headless",
    "turn_detector_enabled",
    "preemptive_generation",
    "noise_cancellation",
    "video_input",
    "robot_tools_enabled",
    "allow_pour",
    "face_control_enabled",
    "hands_control_enabled",
}
_INT_KEYS = {
    "browser_timeout_ms",
    "max_web_chars",
    "token_ttl_minutes",
    "schema_version",
}
_STR_LIMITS = {
    "model": 120,
    "voice": 120,
    "language": 80,
    "agent_name": 80,
    "persona_name": 80,
    "greeting": 200,
    "extra_instructions": 4000,
    "browser_start_url": 500,
    "robot_base_url": 300,
    "room_name": 120,
    "project_dir": 500,
    "livekit_url": 300,
}

# --------------------------------------------------------------------------
# Module state
# --------------------------------------------------------------------------

_LOCK = threading.RLock()
_CFG: dict = dict(DEFAULT_SETTINGS)
_HELPERS: dict = {}
_SETTINGS_PATH: Path | None = None
_AGENT_CONFIG_PATH: Path | None = None
_LOG_PATH: Path | None = None

_PROC: subprocess.Popen | None = None
_STARTED_AT: float | None = None
_LAST_ERROR: str | None = None
_MAX_LOG_BYTES = 64_000


def _log(msg: str, *args) -> None:
    logger = _HELPERS.get("log")
    try:
        if logger:
            logger.info(msg, *args)
        else:
            print((msg % args) if args else msg)
    except Exception:  # logging must never raise
        pass


# --------------------------------------------------------------------------
# Paths & settings IO
# --------------------------------------------------------------------------


def _atomic_write(path: Path, data: dict, secret: bool = False) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = str(path) + ".tmp"
    # Honour CODA_SAVE_KEYS=0 by not persisting secrets at all.
    payload = dict(data)
    if secret and os.environ.get("CODA_SAVE_KEYS", "1") == "0":
        for key in _SECRET_FIELDS:
            payload[key] = ""
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
    os.replace(tmp, str(path))
    if secret:
        with contextlib.suppress(OSError):
            os.chmod(path, 0o600)


def load_settings() -> dict:
    """Merge the saved settings over the defaults. Never raises."""
    cfg = dict(DEFAULT_SETTINGS)
    saved: dict = {}
    if _SETTINGS_PATH and _SETTINGS_PATH.is_file():
        try:
            raw = json.loads(_SETTINGS_PATH.read_text(encoding="utf-8"))
            if isinstance(raw, dict):
                saved = raw
                for key in DEFAULT_SETTINGS:
                    if key in raw:
                        cfg[key] = raw[key]
        except (OSError, json.JSONDecodeError):
            pass
    # One-time repair. The pre-2 schema shipped model="gemini-3.1-flash-live-
    # preview" with language="en-GB": the 3.1 preview cannot accept typed text
    # (so the text bar hung on "Thinking") and the native-audio model rejects
    # en-GB with a Live 1007 error. Move such installs onto a combination that
    # actually opens a session; the user can pick anything afterwards.
    if saved.get("schema_version", 1) < DEFAULT_SETTINGS["schema_version"]:
        if saved:
            cfg["model"] = DEFAULT_SETTINGS["model"]
            cfg["language"] = DEFAULT_SETTINGS["language"]
    cfg["schema_version"] = DEFAULT_SETTINGS["schema_version"]
    return _sanitize(cfg)


def save_settings(cfg: dict) -> dict:
    clean = _sanitize(cfg)
    if _SETTINGS_PATH:
        _atomic_write(_SETTINGS_PATH, clean, secret=True)
    return clean


def _sanitize(cfg: dict) -> dict:
    """Coerce types and clamp lengths so a bad value can never reach the agent."""
    out = dict(DEFAULT_SETTINGS)
    for key, value in cfg.items():
        if key not in DEFAULT_SETTINGS:
            continue
        if key in _BOOL_KEYS:
            if isinstance(value, str):
                value = value.strip().lower() in ("1", "true", "yes", "on")
            out[key] = bool(value)
        elif key in _INT_KEYS:
            try:
                out[key] = int(value)
            except (TypeError, ValueError):
                out[key] = DEFAULT_SETTINGS[key]
        else:
            text = "" if value is None else str(value)
            out[key] = text[: _STR_LIMITS.get(key, 400)]
    # Enum guards.
    if out["brain"] not in ("coda", "jarvis"):
        out["brain"] = "coda"
    if out["interruption_mode"] not in ("adaptive", "strict"):
        out["interruption_mode"] = "adaptive"
    # Keep the model and language in a combination the Live API will accept.
    # A native-audio model + en-GB (or any unsupported code) dies with a 1007
    # the moment the agent joins, so snap back to a language that boots.
    if out["model"] not in LIVE_MODELS:
        out["model"] = DEFAULT_SETTINGS["model"]
    allowed_languages = MODEL_LANGUAGES.get(out["model"], ())
    if allowed_languages and out["language"] not in allowed_languages:
        out["language"] = (
            MODEL_DEFAULT_LANGUAGE
            if MODEL_DEFAULT_LANGUAGE in allowed_languages
            else allowed_languages[0]
        )
    out["browser_timeout_ms"] = max(2000, min(120000, out["browser_timeout_ms"]))
    out["max_web_chars"] = max(1000, min(60000, out["max_web_chars"]))
    out["token_ttl_minutes"] = max(5, min(1440, out["token_ttl_minutes"]))
    out["robot_base_url"] = (out["robot_base_url"] or "").rstrip("/")
    return out


# --------------------------------------------------------------------------
# Project discovery / environment
# --------------------------------------------------------------------------


def _find_project_dir(cfg: dict) -> Path | None:
    candidates: list[Path] = []
    if cfg.get("project_dir"):
        candidates.append(Path(cfg["project_dir"]).expanduser())
    env_dir = os.environ.get("JARVIS_PROJECT_DIR")
    if env_dir:
        candidates.append(Path(env_dir).expanduser())
    base = Path(_HELPERS.get("base_dir") or os.getcwd())
    for rel in (
        "jarvis-voice-butler/jarvis_new",
        "../jarvis-voice-butler/jarvis_new",
        "jarvis_new",
    ):
        candidates.append((base / rel).resolve())
        candidates.append((base.parent / rel).resolve())
    for path in candidates:
        try:
            if (path / "src" / "agent.py").is_file():
                return path
        except OSError:
            continue
    return None


def _find_uv() -> str | None:
    found = shutil.which("uv")
    if found:
        return found
    for rel in (".local/bin/uv", ".cargo/bin/uv"):
        candidate = Path.home() / rel
        if candidate.is_file():
            return str(candidate)
    return None


def _read_env_file(path: Path) -> dict:
    values: dict = {}
    if not path.is_file():
        return values
    try:
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, value = line.partition("=")
            values[key.strip()] = value.strip().strip('"').strip("'")
    except OSError:
        pass
    return values


def _livekit_creds(cfg: dict, project_dir: Path | None) -> tuple[str, str, str]:
    env = _read_env_file(project_dir / ".env.local") if project_dir else {}
    url = (
        cfg.get("livekit_url")
        or os.environ.get("LIVEKIT_URL")
        or env.get("LIVEKIT_URL", "")
    )
    key = (
        cfg.get("livekit_api_key")
        or os.environ.get("LIVEKIT_API_KEY")
        or env.get("LIVEKIT_API_KEY", "")
    )
    secret = (
        cfg.get("livekit_api_secret")
        or os.environ.get("LIVEKIT_API_SECRET")
        or env.get("LIVEKIT_API_SECRET", "")
    )
    return url.strip(), key.strip(), secret.strip()


def _google_api_key(cfg: dict, project_dir: Path | None) -> str:
    """Gemini key from kiosk settings, then the environment, then .env.local."""
    env = _read_env_file(project_dir / ".env.local") if project_dir else {}
    return (
        cfg.get("google_api_key")
        or os.environ.get("GOOGLE_API_KEY")
        or env.get("GOOGLE_API_KEY", "")
    ).strip()


# --------------------------------------------------------------------------
# LiveKit token (stdlib HS256 JWT — no extra dependency)
# --------------------------------------------------------------------------


def _b64url(raw: bytes) -> bytes:
    return base64.urlsafe_b64encode(raw).rstrip(b"=")


def mint_token(
    api_key: str,
    api_secret: str,
    *,
    identity: str,
    room: str,
    agent_name: str = "",
    ttl_seconds: int = 3600,
) -> str:
    header = {"alg": "HS256", "typ": "JWT"}
    now = int(time.time())
    payload: dict = {
        "name": identity,
        "video": {
            "roomJoin": True,
            "room": room,
            "canPublish": True,
            "canSubscribe": True,
            "canPublishData": True,
        },
        "sub": identity,
        "iss": api_key,
        "nbf": now - 5,
        "exp": now + ttl_seconds,
    }
    if agent_name:
        payload["roomConfig"] = {"agents": [{"agentName": agent_name}]}
    signing_input = (
        _b64url(json.dumps(header, separators=(",", ":")).encode())
        + b"."
        + _b64url(json.dumps(payload, separators=(",", ":")).encode())
    )
    signature = hmac.new(api_secret.encode(), signing_input, hashlib.sha256).digest()
    return (signing_input + b"." + _b64url(signature)).decode()


# --------------------------------------------------------------------------
# Agent config file + process supervision
# --------------------------------------------------------------------------


def _write_agent_config(cfg: dict) -> Path | None:
    if not _AGENT_CONFIG_PATH:
        return None
    agent_cfg = {key: cfg[key] for key in _AGENT_FIELDS}
    _atomic_write(_AGENT_CONFIG_PATH, agent_cfg)
    return _AGENT_CONFIG_PATH


def _process_running() -> bool:
    return _PROC is not None and _PROC.poll() is None


def start(restart: bool = False) -> dict:
    """Launch the Jarvis sidecar. Returns a status dict; never raises."""
    global _PROC, _STARTED_AT, _LAST_ERROR
    with _LOCK:
        cfg = load_settings()
        if not cfg["enabled"]:
            return {"ok": False, "error": "Jarvis is disabled in kiosk settings."}
        if _process_running() and not restart:
            return {"ok": True, "already_running": True, "status": status()}

        project_dir = _find_project_dir(cfg)
        uv = _find_uv()
        if project_dir is None:
            _LAST_ERROR = (
                "Jarvis project not found (a folder containing src/agent.py). "
                "The kiosk's 'Live vision (direct)' button needs only the free Gemini key, "
                "so you can use that instead of the sidecar."
            )
            return {"ok": False, "error": _LAST_ERROR}
        if not uv:
            _LAST_ERROR = "The 'uv' runner was not found on this computer."
            return {"ok": False, "error": _LAST_ERROR}

        if _process_running():
            _stop_locked()

        _write_agent_config(cfg)
        url, key, secret = _livekit_creds(cfg, project_dir)
        if not (url and key and secret):
            _LAST_ERROR = (
                "LiveKit credentials are missing (set them on the Jarvis tab)."
            )
            return {"ok": False, "error": _LAST_ERROR}

        google_key = _google_api_key(cfg, project_dir)
        if not google_key:
            _LAST_ERROR = (
                "Gemini API key is missing (paste it on the Jarvis tab → "
                "'Google Gemini API key')."
            )
            return {"ok": False, "error": _LAST_ERROR}

        env = dict(os.environ)
        env.update(
            {
                "JARVIS_CONFIG": str(_AGENT_CONFIG_PATH),
                "LIVEKIT_URL": url,
                "LIVEKIT_API_KEY": key,
                "LIVEKIT_API_SECRET": secret,
                "GOOGLE_API_KEY": google_key,
                "PYTHONUNBUFFERED": "1",
                # On Android/Termux the uv cache and the project venv can live on
                # different filesystems, so uv's default hardlink strategy fails
                # with "Operation not permitted" and the sidecar never boots.
                # Copying uses more disk but always works.
                "UV_LINK_MODE": "copy",
            }
        )
        log_path = _LOG_PATH
        try:
            log_handle = open(log_path, "a", encoding="utf-8")  # noqa: SIM115 - must outlive Popen
        except OSError:
            log_handle = subprocess.DEVNULL  # type: ignore[assignment]
        # Prefer the project's own interpreter: it skips ``uv``'s sync step
        # entirely and starts faster. Fall back to ``uv run`` when the venv
        # hasn't been created yet.
        venv_python = project_dir / ".venv" / "bin" / "python"
        argv = (
            [str(venv_python), "src/agent.py", "start"]
            if venv_python.is_file()
            else [uv, "run", "src/agent.py", "start"]
        )
        try:
            _PROC = subprocess.Popen(
                argv,
                cwd=str(project_dir),
                env=env,
                stdout=log_handle,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )
        except OSError as exc:
            _LAST_ERROR = f"Could not start Jarvis: {exc}"
            return {"ok": False, "error": _LAST_ERROR}
        finally:
            if hasattr(log_handle, "close"):
                # Keep the handle in the child; close our copy.
                with contextlib.suppress(OSError):
                    log_handle.close()
        _STARTED_AT = time.time()
        _LAST_ERROR = None
        _log("Jarvis sidecar started (pid %s) from %s", _PROC.pid, project_dir)
        return {"ok": True, "status": status()}


def _stop_locked() -> None:
    global _PROC, _STARTED_AT
    if _PROC is None:
        return
    try:
        if _PROC.poll() is None:
            _PROC.terminate()
            try:
                _PROC.wait(timeout=10)
            except subprocess.TimeoutExpired:
                _PROC.kill()
                _PROC.wait(timeout=5)
    except Exception as exc:  # process cleanup must never raise
        _log("Error stopping Jarvis: %s", exc)
    finally:
        _PROC = None
        _STARTED_AT = None


def stop() -> dict:
    with _LOCK:
        _stop_locked()
        _log("Jarvis sidecar stopped")
        return {"ok": True, "status": status()}


def status() -> dict:
    cfg = load_settings()
    project_dir = _find_project_dir(cfg)
    running = _process_running()
    url, key, secret = _livekit_creds(cfg, project_dir)
    info: dict = {
        "enabled": cfg["enabled"],
        "brain": cfg["brain"],
        "running": running,
        "pid": _PROC.pid if running and _PROC else None,
        "uptime": int(time.time() - _STARTED_AT) if running and _STARTED_AT else 0,
        "available": bool(project_dir and _find_uv()),
        "project_dir": str(project_dir) if project_dir else "",
        "livekit_configured": bool(url and key and secret),
        "livekit_url": url,
        "google_configured": bool(_google_api_key(cfg, project_dir)),
        "agent_name": cfg["agent_name"],
        "last_error": _LAST_ERROR,
        "settings": _public_settings(cfg),
        "capabilities": {
            "models": list(LIVE_MODELS),
            "model_languages": {m: list(v) for m, v in MODEL_LANGUAGES.items()},
            "model_accepts_text": dict(MODEL_ACCEPTS_TEXT),
            "default_language": MODEL_DEFAULT_LANGUAGE,
        },
    }
    return info


def _public_settings(cfg: dict) -> dict:
    """Settings safe to show in the browser (secrets masked to a boolean)."""
    public = dict(cfg)
    for key in _SECRET_FIELDS:
        public[key] = ""
    public["livekit_api_key_set"] = bool(cfg.get("livekit_api_key"))
    public["livekit_api_secret_set"] = bool(cfg.get("livekit_api_secret"))
    public["google_api_key_set"] = bool(cfg.get("google_api_key"))
    return public


def log_tail(max_bytes: int = _MAX_LOG_BYTES) -> str:
    if not _LOG_PATH or not _LOG_PATH.is_file():
        return ""
    try:
        size = _LOG_PATH.stat().st_size
        with open(_LOG_PATH, "rb") as handle:
            if size > max_bytes:
                handle.seek(size - max_bytes)
            return handle.read().decode("utf-8", "replace")
    except OSError:
        return ""


# --------------------------------------------------------------------------
# Flask wiring
# --------------------------------------------------------------------------


def _local_only() -> bool:
    remote = request.remote_addr or ""
    try:
        if not ipaddress.ip_address(remote).is_loopback:
            return False
    except ValueError:
        return False
    origin = request.headers.get("Origin", "").rstrip("/")
    return not (origin and origin != request.host_url.rstrip("/"))


def init(app, helpers: dict) -> None:
    """Register the /jarvis/* routes on the shared Flask app."""
    global _HELPERS, _SETTINGS_PATH, _AGENT_CONFIG_PATH, _LOG_PATH
    _HELPERS = helpers
    base_dir = Path(helpers.get("base_dir") or os.getcwd())
    data_dir = Path(helpers.get("data_dir") or (base_dir / "data"))
    _SETTINGS_PATH = data_dir / "jarvis_settings.json"
    _AGENT_CONFIG_PATH = data_dir / "jarvis_agent_config.json"
    _LOG_PATH = data_dir / "jarvis_agent.log"

    globals()["_CFG"] = load_settings()

    @app.route("/jarvis/status", methods=["GET"])
    def jarvis_status():
        return jsonify(status())

    @app.route("/jarvis/control", methods=["POST"])
    def jarvis_control():
        if not _local_only():
            return jsonify(
                {"error": "Jarvis control is only available on this device."}
            ), 403
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "bad payload"}), 400
        action = str(data.get("action", "")).strip().lower()
        if action == "start":
            return jsonify(start())
        if action == "stop":
            return jsonify(stop())
        if action == "restart":
            return jsonify(start(restart=True))
        return jsonify({"error": "action must be start, stop, or restart."}), 400

    @app.route("/jarvis/settings", methods=["GET"])
    def jarvis_settings_get():
        return jsonify(
            {
                "settings": _public_settings(load_settings()),
                "defaults": _public_settings(dict(DEFAULT_SETTINGS)),
                "capabilities": {
                    "models": list(LIVE_MODELS),
                    "model_languages": {
                        m: list(v) for m, v in MODEL_LANGUAGES.items()
                    },
                    "model_accepts_text": dict(MODEL_ACCEPTS_TEXT),
                    "default_language": MODEL_DEFAULT_LANGUAGE,
                },
            }
        )

    @app.route("/jarvis/settings", methods=["POST"])
    def jarvis_settings_post():
        if not _local_only():
            return jsonify(
                {"error": "Jarvis settings are only available on this device."}
            ), 403
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "bad payload"}), 400
        current = load_settings()
        # Empty secret fields mean "keep the existing value".
        for key in _SECRET_FIELDS:
            if key in data and not str(data[key]).strip():
                data[key] = current.get(key, "")
        if data.pop("clear_secrets", False):
            for key in _SECRET_FIELDS:
                data[key] = ""
            data["livekit_url"] = ""
        merged = _sanitize({**current, **data})
        save_settings(merged)
        _write_agent_config(merged)
        restarted = False
        if _process_running() and data.get("apply_now", True):
            start(restart=True)
            restarted = True
        return jsonify(
            {
                "saved": True,
                "restarted": restarted,
                "settings": _public_settings(merged),
            }
        )

    @app.route("/jarvis/log", methods=["GET"])
    def jarvis_log():
        return jsonify({"log": log_tail()})

    @app.route("/jarvis/token", methods=["POST"])
    def jarvis_token():
        if not _local_only():
            return jsonify({"error": "Tokens are only issued on this device."}), 403
        cfg = load_settings()
        project_dir = _find_project_dir(cfg)
        url, key, secret = _livekit_creds(cfg, project_dir)
        if not (url and key and secret):
            return jsonify({"error": "LiveKit is not configured yet."}), 409
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return jsonify({"error": "bad payload"}), 400
        room = str(data.get("room") or cfg["room_name"] or "jarvis-room")[:120]
        identity = str(data.get("identity") or "kiosk")[:120]
        agent_name = cfg["agent_name"] if data.get("dispatch", True) else ""
        try:
            token = mint_token(
                key,
                secret,
                identity=identity,
                room=room,
                agent_name=agent_name,
                ttl_seconds=cfg["token_ttl_minutes"] * 60,
            )
        except Exception as exc:
            return jsonify({"error": f"Could not mint a token: {exc}"}), 500
        return jsonify(
            {"url": url, "token": token, "room": room, "agent_name": agent_name}
        )

    @app.route("/jarvis/google-key", methods=["GET"])
    def jarvis_google_key():
        """Hand the Gemini key to this device's kiosk page only.

        The direct Gemini Live path (no LiveKit, no sidecar) runs in the kiosk
        browser; it needs the key to open the official Live WebSocket. The key
        is never exposed to any non-loopback origin, and never lands in
        localStorage (the settings mirror strips it).
        """
        if not _local_only():
            return jsonify({"error": "The Gemini key is only available on this device."}), 403
        cfg = load_settings()
        key = _google_api_key(cfg, _find_project_dir(cfg))
        if not key:
            return jsonify({"error": "Paste a free Google Gemini API key on the Jarvis tab first."}), 404
        return jsonify({"key": key, "model": cfg["model"]})

    @app.route("/jarvis/health", methods=["GET"])
    def jarvis_health():
        return jsonify({"ok": True})

    if _CFG.get("enabled") and _CFG.get("auto_start"):
        try:
            start()
        except Exception as exc:  # boot must never fail on this
            _log("Jarvis autostart skipped: %s", exc)

    _log(
        "Jarvis bridge ready (enabled=%s, brain=%s)",
        _CFG.get("enabled"),
        _CFG.get("brain"),
    )
