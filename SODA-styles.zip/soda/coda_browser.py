"""Which browser should the ChatGPT integration and the AI browser use?

Chosen by start.sh / start.bat (they ask you) and passed in as CODA_BROWSER:
    chrome | chromium | edge  -> Chromium family   (driven with DevTools / Playwright)
    firefox                   -> Mozilla Firefox   (driven with Marionette / Playwright)
    default | auto            -> whatever the operating system's default browser is
                                 (falls back to Chrome/Chromium when that isn't supported)

    python coda_browser.py --detect     show what is installed / the system default
"""
import os, shutil, subprocess, sys

CHROME_NAMES = ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome", "microsoft-edge")
FIREFOX_NAMES = ("firefox", "firefox-esr")


def is_termux():
    return bool(os.environ.get("TERMUX_VERSION")) or "com.termux" in os.environ.get("PREFIX", "")


def _first(names, extra=()):
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    for p in extra:
        if os.path.exists(p):
            return p
    return None


def find_binary(kind):
    """Path of the installed browser of that kind, or None."""
    if os.environ.get("CHATGPT_BROWSER") and kind == preferred_raw():
        return os.environ["CHATGPT_BROWSER"]
    pf = os.environ.get("ProgramFiles", r"C:\Program Files")
    pf86 = os.environ.get("ProgramFiles(x86)", r"C:\Program Files (x86)")
    if kind == "firefox":
        return _first(FIREFOX_NAMES, (pf + r"\Mozilla Firefox\firefox.exe", pf86 + r"\Mozilla Firefox\firefox.exe",
                                      "/Applications/Firefox.app/Contents/MacOS/firefox"))
    return _first(CHROME_NAMES, (pf + r"\Google\Chrome\Application\chrome.exe", pf86 + r"\Google\Chrome\Application\chrome.exe",
                                 pf + r"\Microsoft\Edge\Application\msedge.exe", pf86 + r"\Microsoft\Edge\Application\msedge.exe",
                                 "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                                 "/Applications/Chromium.app/Contents/MacOS/Chromium"))


def default_system_browser():
    """'firefox', 'chrome' (any Chromium-based browser) or None when it can't be determined."""
    try:
        if sys.platform == "win32":
            out = subprocess.run(["reg", "query", r"HKCU\Software\Microsoft\Windows\Shell\Associations\UrlAssociations\https\UserChoice",
                                  "/v", "ProgId"], capture_output=True, text=True, timeout=5).stdout.lower()
            if "firefox" in out:
                return "firefox"
            if any(k in out for k in ("chrome", "msedge", "edge", "brave", "opera")):
                return "chrome"
        elif sys.platform == "darwin":
            out = subprocess.run(["defaults", "read", "com.apple.LaunchServices/com.apple.launchservices.secure", "LSHandlers"],
                                 capture_output=True, text=True, timeout=5).stdout.lower()
            i = out.find("x-scheme-handler/https") if "x-scheme-handler/https" in out else out.find("https")
            seg = out[max(0, i - 200):i + 200]
            if "firefox" in seg:
                return "firefox"
            if "chrome" in seg or "edge" in seg:
                return "chrome"
        elif not is_termux():
            out = subprocess.run(["xdg-settings", "get", "default-web-browser"], capture_output=True, text=True,
                                 timeout=5).stdout.lower()
            if "firefox" in out:
                return "firefox"
            if any(k in out for k in ("chrome", "chromium", "edge", "brave")):
                return "chrome"
    except Exception:
        pass
    return None


def preferred_raw():
    v = os.environ.get("CODA_BROWSER", "auto").strip().lower()
    if v in ("firefox", "ff"):
        return "firefox"
    if v in ("chrome", "chromium", "edge", "google-chrome"):
        return "chrome"
    return "auto"


def preferred():
    """'firefox' or 'chrome' according to CODA_BROWSER (auto = the system default if usable)."""
    raw = preferred_raw()
    if raw != "auto":
        return raw
    d = default_system_browser()
    if d == "firefox" and find_binary("firefox"):
        return "firefox"
    return "chrome"


if __name__ == "__main__":
    if "--detect" in sys.argv:
        d = default_system_browser()
        print("default=%s chrome=%s firefox=%s" % (d or "unknown", find_binary("chrome") or "-", find_binary("firefox") or "-"))
    else:
        print(preferred())
