#!/usr/bin/env bash
# Starts the pump backend and opens the controller UI.
#
#   bash start.sh            -> simulated Arduino on the TV (Termux); auto-detect on a laptop
#   bash start.sh mock       -> simulated Arduino (no hardware)
#   bash start.sh servermock -> everything simulated: pumps + canned AI replies/voice,
#                              no API keys needed — a full offline demo of the kiosk
#   bash start.sh termux     -> REAL Arduino over USB from Termux (Android TV / phone)
#   bash start.sh serial     -> REAL Arduino via a normal serial port (laptop)
#   bash start.sh probe      -> (Termux) show what USB devices Android can see
#   bash start.sh setup      -> only create .venv and install the core libraries, then exit
#   bash start.sh setup --ask-extras  -> choose which optional libraries to install
#   bash start.sh --reinstall [mode]  -> force a clean library reinstall first
#   bash start.sh --browser firefox   -> skip the question: chrome | firefox | default
#   bash start.sh --lan               -> serve on 0.0.0.0 so other devices on the same WiFi can open the kiosk
#   bash start.sh --allow             -> other devices may also drive the ChatGPT browser / web provider
#   bash start.sh --no-browser        -> never ask the browser question or auto-open the UI
#   bash start.sh help       -> list every command, option and environment variable
#
# First run creates a private Python virtualenv in .venv-<os>, activates it, and installs
# the CORE libraries (requirements.txt) via deps.py. Heavy optional libraries (browsers,
# OCR, the Jarvis voice agent) are asked about with a y/n question — once per computer,
# all defaulting to No — and the answers are remembered in .coda_extras. Later runs only
# re-check (fast) and install anything that is missing or newly added.
#
# All output is captured to logs/ so nothing is lost if the terminal closes.

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cd "$DIR"
mkdir -p logs
LANURL=""
RUN_LOG="logs/start_$(date +"%Y%m%d_%H%M%S").log"
PORT="${PUMP_PORT:-5005}"

log() { echo "[$(date +%T)] $*" | tee -a "$RUN_LOG"; }

is_termux() { [ -n "${TERMUX_VERSION:-}" ] || [[ "${PREFIX:-}" == *com.termux* ]]; }

show_help() {
cat <<'HELP'
CODA start script

USAGE
  bash start.sh [options] [mode]

MODES (what talks to the pumps)
  (none)            Termux: simulated Arduino.  Laptop: auto-detect the Arduino's serial port
  mock              Simulated Arduino, no hardware needed
  servermock        Everything simulated: mock pumps + canned AI replies and a silent
                    demo voice (CODA_SERVERMOCK) — the whole kiosk offline, no keys
  auto | serial     Real Arduino on a normal serial port (laptop)
  termux            Real Arduino over USB from Termux (Android TV / phone)
  probe             Termux: list the USB devices Android can see, then exit
  setup             Create .venv and install the core libraries, then exit (no backend started)

OPTIONS
  help, -h, --help  Show this text
  --servermock      Same as the servermock mode, wherever options are wanted
  --mock-ai         Mock only the AI (chat, recipes, voice) for ANY transport mode:
                    canned local replies, no API keys or ChatGPT browser needed
  --no-browser      Skip the browser question and never auto-open the controller UI
  --lan             Bind 0.0.0.0 so every device on the same WiFi can open the
                    kiosk (http://<this computer's IP>:5005/). Respects a
                    PUMP_HOST you set yourself. Warning: with REAL pumps anyone
                    on the WiFi could pour drinks.
  --allow           Let other devices on the network use EVERYTHING: drive the
                    ChatGPT browser / web provider, change AI providers, keys
                    and models, and reset the e-stop (those are normally
                    local-machine-only protections). Combine with --lan.
                    WARNING: anyone on the WiFi can then control the kiosk
                    and your logged-in ChatGPT session.
  --browser NAME    Browser for ChatGPT and the AI browser, without asking:
                      default  the operating system's default browser (auto-detected)
                      chrome   Google Chrome / Chromium / Edge
                      firefox  Mozilla Firefox
  --ask             Ask which browser even if a choice is saved or CODA_BROWSER is set
  --no-ask          Never ask; use --browser / CODA_BROWSER / your last choice (default: default)
  --reinstall       Force a clean reinstall of every library before starting
  --extras LIST     Install these optional libraries too, without asking. LIST is a
                    comma-separated list, or "all", or "none":
                      browser   Playwright + one browser engine (large download)
                      imaging   Screenshot decoding + offline OCR
                      usb       Termux only: termux-api + libusb for a real Arduino
                      jarvis    The Jarvis voice agent's own packages (uv sync)
  --no-extras       Install core libraries only; never ask about the optional ones
  --ask-extras      Ask the y/n questions again now (to change an earlier answer)
  --list-extras     Show the optional libraries for this machine, then exit

OPTIONAL LIBRARIES (never downloaded unless you say yes)
  Only the CORE libraries are installed by default (flask, flask-cors, pyserial,
  plus pycaw/comtypes on Windows). Everything heavy is an extra, and the first run on
  a computer asks one y/n question per extra — all default to No. Your answers are
  remembered in .coda_extras, so later runs are instant. Change them any time with:
      bash start.sh setup --ask-extras

BROWSER QUESTION
  Asked on the first run on a computer, or whenever you pass --ask. Press Enter to
  keep the last choice. The answer is remembered in .coda_browser and passed on as
  CODA_BROWSER.

EXAMPLES
  bash start.sh                     start (asks on the first run)
  bash start.sh mock --no-ask       simulated Arduino, no questions
  bash start.sh servermock          full offline demo: everything simulated, no keys
  bash start.sh mock --mock-ai      same demo, stated explicitly
  bash start.sh --no-browser serial real Arduino, never opens the UI
  bash start.sh servermock --lan    offline demo open to every device on the same WiFi
  bash start.sh termux --browser firefox
  bash start.sh setup               install core only and exit
  bash start.sh setup --extras browser,imaging
  bash start.sh setup --ask-extras  change which extras are installed
  bash start.sh --reinstall mock

ENVIRONMENT VARIABLES (all optional)
  Flags            CODA_SERVERMOCK=1 (mock the AI)   CODA_NO_BROWSER=1 (never auto-open)
                   CODA_LAN=1 (same as --lan)
  Backend     PUMP_TRANSPORT  PUMP_HOST  PUMP_PORT (5005)  PUMP_SERIAL_PORT  FLOW_SENSOR_PORT  PUMP_USB_DEVICE
  AI          GROQ_API_KEY  GROQ_PROXY  OMNIROUTE_BASE_URL  ELEVENLABS_API_KEY  ELEVENLABS_VOICE_ID
  Browser     CODA_BROWSER (default|chrome|firefox)  CHATGPT_BROWSER (path to the binary)  CHATGPT_HEADLESS (1|0)
  ChatGPT     CHATGPT_URL  CHATGPT_DRIVER (playwright|cdp)  CHATGPT_CAPTURE (auto|dom|screenshot)
              CHATGPT_TIMEOUT (seconds, default 75)  CHATGPT_DEBUG_DIR (save the screenshot it analysed)
              CHATGPT_CDP_URL  CHATGPT_BRIDGE_URL  CHATGPT_BRIDGE_TOKEN
  AI browser  BROWSER_ENGINE (auto|full|lite)  BROWSER_REMOTE  BROWSER_TOKEN  BROWSER_ALLOW_PRIVATE
  Setup       SKIP_DEPS_CHECK=1  SKIP_BROWSER_DOWNLOAD=1  SKIP_CHROMIUM=1
              CODA_EXTRAS=browser,jarvis  (install these extras without asking)
PORTABLE (USB stick)
  Everything lives in this folder: data/ (API keys, settings, ChatGPT login), .venv-<os>/ (libraries, one per
  operating system), logs/. Copy or carry the whole folder. Python itself must be installed on each computer.
  Use `bash start.sh` (FAT/exFAT sticks can't mark files executable, so ./start.sh may be refused).

AFTER IT STARTS
  Kiosk  http://localhost:5005/     Pump test  /test     LCD settings  /display     Logs  logs/
  Stop with Ctrl+C (not Ctrl+Z).   Termux shortcut after termux_setup.sh:  coda [mode]
HELP
}

FORCE_DEPS=""; ASK=1; BROWSER_ARG=""; MODE_ARG=""
EXTRAS_ARG=""; NO_EXTRAS=0; ASK_EXTRAS=0; LIST_EXTRAS=0
NO_BROWSER=0; MOCK_AI=0; LANSERVE=0; ALLOW_REMOTE=0
[ -n "${CODA_NO_BROWSER:-}" ] && NO_BROWSER=1
[ -n "${CODA_SERVERMOCK:-}" ] && MOCK_AI=1
[ -n "${CODA_LAN:-}" ] && LANSERVE=1
[ -n "${CODA_ALLOW_REMOTE:-}" ] && ALLOW_REMOTE=1
while [ $# -gt 0 ]; do
  case "$1" in
    help|-h|--help) show_help; exit 0 ;;
    --reinstall) FORCE_DEPS="--force" ;;
    --browser) BROWSER_ARG="${2:-}"; shift ;;
    --browser=*) BROWSER_ARG="${1#*=}" ;;
    --ask) ASK=2 ;;
    --no-ask) ASK=0 ;;
    --no-browser) NO_BROWSER=1 ;;
    --mock-ai) MOCK_AI=1 ;;
    --servermock) MOCK_AI=1; MODE_ARG="mock" ;;
    --lan) LANSERVE=1 ;;
    --allow) ALLOW_REMOTE=1 ;;
    --extras) EXTRAS_ARG="${2:-}"; shift ;;
    --extras=*) EXTRAS_ARG="${1#*=}" ;;
    --no-extras) NO_EXTRAS=1 ;;
    --ask-extras) ASK_EXTRAS=1 ;;
    --list-extras) LIST_EXTRAS=1 ;;
    -*) echo "Unknown option: $1   (try: bash start.sh help)"; exit 1 ;;
    *) MODE_ARG="$1" ;;
  esac
  shift
done
set -- ${MODE_ARG:+"$MODE_ARG"}
if [ "${1:-}" = "servermock" ]; then   # one-word "everything simulated"
  MOCK_AI=1; MODE_ARG="mock"
  [ "$ASK" = 1 ] && ASK=0              # the ChatGPT browser question is pointless in mock mode
  set -- mock
fi

# ---------------- Python venv + automatic library checker ----------------
if is_termux && ! command -v python >/dev/null 2>&1 && ! command -v python3 >/dev/null 2>&1; then
  log "Installing Python (pkg)..."; pkg install -y python || true
fi
PY0=""
for c in python3 python; do command -v "$c" >/dev/null 2>&1 && { PY0="$c"; break; }; done
if [ -z "$PY0" ]; then
  echo "Python 3 was not found. Install it (Debian/Ubuntu: sudo apt install python3 python3-venv; macOS: brew install python; Termux: pkg install python)."
  exit 1
fi

if [ "$LIST_EXTRAS" = 1 ]; then
  "$PY0" "$DIR/deps.py" --list-extras
  exit 0
fi

# ---------------- where the libraries live + is this the first run? ----------------
# One virtualenv per operating system (a venv can't be shared between Windows / Linux / macOS / Termux), so the
# same folder on a USB stick works on every machine: .venv-win, .venv-linux, .venv-mac, .venv-termux.
case "$(uname -s 2>/dev/null)" in
  Darwin) OSTAG=mac ;;
  *) if is_termux; then OSTAG=termux; else OSTAG=linux; fi ;;
esac
VENV="$DIR/.venv-$OSTAG"
FIRST_RUN=1
[ -f "$VENV/.deps_stamp" ] && FIRST_RUN=0

# ---------------- which browser for ChatGPT + the AI browser? ----------------
normalize_browser() {
  case "$(echo "$1" | tr 'A-Z' 'a-z')" in
    1|default|auto|system|"") echo auto ;;
    2|chrome|chromium|edge|google-chrome) echo chrome ;;
    3|firefox|ff) echo firefox ;;
    *) echo "" ;;
  esac
}
SAVED=""; [ -f "$DIR/.coda_browser" ] && SAVED="$(normalize_browser "$(cat "$DIR/.coda_browser" 2>/dev/null)")"
CHOICE=""
if [ -n "$BROWSER_ARG" ]; then
  CHOICE="$(normalize_browser "$BROWSER_ARG")"
  [ -z "$CHOICE" ] && { echo "Unknown browser '$BROWSER_ARG' (use default, chrome or firefox)."; exit 1; }
elif [ -n "${CODA_BROWSER:-}" ] && [ "$ASK" != 2 ]; then
  CHOICE="$(normalize_browser "$CODA_BROWSER")"
elif [ "$ASK" != 0 ] && [ "$NO_BROWSER" != 1 ] && [ -t 0 ] && [ -t 1 ] && { [ "$ASK" = 2 ] || [ "$FIRST_RUN" = 1 ]; }; then
  INFO="$("$PY0" "$DIR/coda_browser.py" --detect 2>/dev/null)"
  D_DEF="$(echo "$INFO" | sed -n 's/.*default=\([^ ]*\).*/\1/p')"
  D_CH="$(echo "$INFO" | sed -n 's/.*chrome=\([^ ]*\).*/\1/p')"
  D_FF="$(echo "$INFO" | sed -n 's/.*firefox=\([^ ]*\).*/\1/p')"
  [ "$D_CH" = "-" ] && D_CH="not installed" ; [ "$D_FF" = "-" ] && D_FF="not installed"
  case "$SAVED" in firefox) DEFNUM=3 ;; chrome) DEFNUM=2 ;; *) DEFNUM=1 ;; esac
  echo
  echo "Which browser should ChatGPT and the AI browser use?"
  echo "  1) System default browser   (detected: ${D_DEF:-unknown})"
  echo "  2) Google Chrome / Chromium (${D_CH:-not installed})"
  echo "  3) Mozilla Firefox          (${D_FF:-not installed})"
  printf "Choose 1-3 [Enter = %s]: " "$DEFNUM"
  read -r ANS || ANS=""
  [ -z "$ANS" ] && ANS="$DEFNUM"
  CHOICE="$(normalize_browser "$ANS")"
  [ -z "$CHOICE" ] && { echo "Not understood, using the system default."; CHOICE=auto; }
else
  CHOICE="${SAVED:-auto}"
fi
export CODA_BROWSER="$CHOICE"
echo "$CHOICE" > "$DIR/.coda_browser" 2>/dev/null || true
log "Browser for ChatGPT / AI browser: $( [ "$CHOICE" = auto ] && echo 'system default' || echo "$CHOICE" )"
[ "$NO_BROWSER" = 1 ] && log "The controller UI will not auto-open (--no-browser)."
[ "$MOCK_AI" = 1 ] && log "AI replies will be locally mocked (no API keys needed)."
# (OSTAG and VENV were resolved before the browser question, so we could tell it was a first run.)
if [ -x "$VENV/bin/python" ] && ! "$VENV/bin/python" -c "import sys" >/dev/null 2>&1; then
  log "The virtualenv is broken (Python moved?) — recreating it."
  rm -rf "$VENV"
fi
if [ ! -x "$VENV/bin/python" ]; then
  log "Creating virtualenv in .venv-$OSTAG (first run on this computer) ..."
  if ! "$PY0" -m venv --copies "$VENV" >> "$RUN_LOG" 2>&1; then      # --copies: FAT/exFAT sticks have no symlinks
    rm -rf "$VENV"
    echo "Could not create a virtualenv. On Debian/Ubuntu run:  sudo apt install python3-venv   (then retry)."
    echo "If the drive is read-only or full, copy the folder to a writable place."
    exit 1
  fi
fi
# shellcheck disable=SC1091
. "$VENV/bin/activate"        # automatic enabler: everything below runs inside .venv
PY="$VENV/bin/python"
DEPS_ARGS="$FORCE_DEPS"
[ -n "$EXTRAS_ARG" ] && DEPS_ARGS="$DEPS_ARGS --extras $EXTRAS_ARG"
[ "$NO_EXTRAS" = 1 ] && DEPS_ARGS="$DEPS_ARGS --no-extras"
[ "$ASK_EXTRAS" = 1 ] && DEPS_ARGS="$DEPS_ARGS --ask-extras"
if [ "$NO_EXTRAS" = 0 ] && [ -z "$EXTRAS_ARG" ] && [ "$ASK_EXTRAS" = 0 ] && [ -z "${CODA_EXTRAS:-}" ] \
   && [ ! -f "$DIR/.coda_extras" ] && [ -t 0 ]; then
  log "First run on this computer — asking which optional libraries to install (Enter = core only)."
fi
log "Checking libraries..."
# shellcheck disable=SC2086
"$PY" "$DIR/deps.py" $DEPS_ARGS 2>&1 | tee -a "$RUN_LOG"
if [ "${PIPESTATUS[0]}" -ne 0 ]; then
  echo "Library setup failed — see above."; exit 1
fi

if is_termux; then DEFAULT_MODE=mock; else DEFAULT_MODE=auto; fi
MODE="${1:-${PUMP_TRANSPORT:-$DEFAULT_MODE}}"
if [ "$MODE" = "auto" ] && is_termux; then MODE=termux; fi

# ---------------- Termux USB helpers ----------------

need_termux_usb() {
  if ! command -v termux-usb >/dev/null 2>&1; then
    echo ""
    echo "termux-usb isn't installed. One-time setup:"
    echo "  1. Install the 'Termux:API' app (same source you got Termux from, e.g. F-Droid)"
    echo "  2. In Termux run:   pkg install termux-api libusb python"
    echo "Then run this again."
    exit 1
  fi
}

usb_devices() {
  termux-usb -l 2>/dev/null | $PY -c '
import sys, json
try:
    for d in json.load(sys.stdin): print(d)
except Exception:
    pass'
}

make_wrapper() {   # $1 = file to write, $2 = the command it should exec
  printf '#!%s/bin/bash\nexec %s "$@"\n' "$PREFIX" "$2" > "$1"
  chmod +x "$1"
}

probe_device() {   # $1 = usb device path
  make_wrapper "$DIR/.usb_probe.sh" "$PY $DIR/usb_transport.py --probe"
  termux-usb -r -e "$DIR/.usb_probe.sh" "$1" 2>&1
}

pick_usb_device() {
  if [ -n "${PUMP_USB_DEVICE:-}" ]; then echo "$PUMP_USB_DEVICE"; return; fi
  mapfile -t DEVS < <(usb_devices)
  if [ "${#DEVS[@]}" -eq 0 ]; then
    echo "" >&2
    echo "Android reports no USB devices. Check: OTG/USB cable, Arduino plugged in," >&2
    echo "and that nothing else (like ArduinoDroid) is holding it." >&2
    return 1
  fi
  if [ "${#DEVS[@]}" -eq 1 ]; then echo "${DEVS[0]}"; return; fi

  echo "Several USB devices found — checking which one is the Arduino..." >&2
  for d in "${DEVS[@]}"; do
    echo "  probing $d (tap OK if Android asks)" >&2
    if probe_device "$d" | grep -q "ARDUINO=yes"; then echo "$d"; return; fi
  done
  echo "Couldn't tell automatically. Devices:" >&2
  i=1; for d in "${DEVS[@]}"; do echo "  $i) $d" >&2; i=$((i+1)); done
  read -r -p "Which number is the Arduino? " n
  echo "${DEVS[$((n-1))]}"
}

# ---------------- probe mode ----------------

if [ "$MODE" = "setup" ]; then
  log "Setup complete. Start the robot with: bash start.sh"
  exit 0
fi

if [ "$MODE" = "probe" ] || [ "$MODE" = "termux" ]; then
  "$PY" "$DIR/deps.py" --usb 2>&1 | tee -a "$RUN_LOG" >/dev/null
fi

if [ "$MODE" = "probe" ]; then
  need_termux_usb
  mapfile -t DEVS < <(usb_devices)
  [ "${#DEVS[@]}" -eq 0 ] && { echo "No USB devices visible to Termux."; exit 1; }
  for d in "${DEVS[@]}"; do
    echo "=== $d ==="
    probe_device "$d"
    echo ""
  done
  exit 0
fi

# ---------------- launch ----------------

if [ "$LANSERVE" = 1 ]; then
  export PUMP_HOST="${PUMP_HOST:-0.0.0.0}"          # a PUMP_HOST you set yourself always wins
  log "LAN serving: bound to $PUMP_HOST — other devices on this WiFi can open the kiosk."
  case "$MODE" in
    mock|termux) ;;                                  # simulated pumps: no real pours to worry about
    *) log "WARNING: with REAL pumps, anyone on the WiFi could pour drinks. Put the kiosk on a private network." ;;
  esac
else
  export PUMP_HOST="${PUMP_HOST:-127.0.0.1}"         # unchanged default: loopback only
fi

export PUMP_TRANSPORT="$MODE"
log "Transport mode: $MODE"
if [ "$ALLOW_REMOTE" = 1 ]; then
  export CODA_ALLOW_REMOTE=1
  log "Remote control FULLY ALLOWED: network devices may change AI settings/models and drive the ChatGPT browser (--allow)."
  log "  WARNING: anyone on this WiFi can control the kiosk and your logged-in ChatGPT session while it runs."
fi
if [ "$MOCK_AI" = 1 ]; then
  export CODA_SERVERMOCK=1
  log "Servermock: chat / recipes / voice answer locally with canned demo replies."
fi

if [ "$MODE" = "termux" ]; then
  need_termux_usb
  DEV="$(pick_usb_device)" || exit 1
  log "Using USB device: $DEV"
  log ">>> If Android shows a USB permission popup, tap OK <<<"
  make_wrapper "$DIR/.usb_launch.sh" "$PY $DIR/backend.py"
  termux-usb -r -e "$DIR/.usb_launch.sh" "$DEV" >> "$RUN_LOG" 2>&1 &
else
  "$PY" backend.py >> "$RUN_LOG" 2>&1 &
fi
BACKEND_PID=$!
log "Backend started (PID $BACKEND_PID)"

# Stop everything on exit/Ctrl+C. (In termux mode the real server is a child
# of termux-usb, so kill by name too — otherwise it keeps port $PORT busy.)
cleanup() {
  log "Stopping backend..."
  kill "$BACKEND_PID" 2>/dev/null
  pkill -f "backend.py" 2>/dev/null
}
trap cleanup EXIT

log "Waiting for the backend to respond..."
UP=0
for i in $(seq 1 60); do
  if "$PY" -c "import urllib.request,sys;urllib.request.urlopen('http://localhost:${PORT}/hardware',timeout=1)" >/dev/null 2>&1; then UP=1; break; fi
  sleep 0.5
done

if [ "$UP" -ne 1 ]; then
  log "The backend did not start. Last lines of the log:"
  tail -n 15 "$RUN_LOG"
  exit 1
fi
log "Backend is up."

# Say in plain words what the Arduino link looks like
"$PY" -c "import urllib.request;print(urllib.request.urlopen('http://localhost:${PORT}/hardware',timeout=3).read().decode())" 2>/dev/null | "$PY" -c '
import sys, json
try:
    h = json.load(sys.stdin)
except Exception:
    sys.exit()
if h.get("mock"):
    print("  Arduino: SIMULATED (no hardware in use)")
elif h.get("connected"):
    print("  Arduino: CONNECTED  ->  " + str(h.get("detail")))
else:
    print("  Arduino: NOT FOUND  ->  " + str(h.get("error")))
' | tee -a "$RUN_LOG"

URL="http://localhost:${PORT}/"
log "Opening controller UI: $URL"
if [ "$LANSERVE" = 1 ]; then
  # Find this machine's LAN address by asking the routing table (UDP trick sends
  # no packets); fall back through a few methods so it works on any OS.
  LANIP="$("$PY" -c "
import socket
for probe in (('8.8.8.8', 80), ('1.1.1.1', 80), ('192.168.1.1', 80)):
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM); s.settimeout(1)
        s.connect(probe); ip = s.getsockname()[0]; s.close()
        if ip and not ip.startswith('127.'): print(ip); break
    except OSError:
        pass
else:
    try: print(socket.gethostbyname(socket.gethostname()))
    except Exception: pass
" 2>/dev/null | head -n 1)"
  LANURL=""
  if [ -n "$LANIP" ] && [ "$LANIP" != "127.0.0.1" ]; then
    LANURL="http://${LANIP}:${PORT}/"
    log "LAN URL:  ${LANURL}  ← on other devices (same WiFi)"
  else
    log "Could not detect the LAN address — use this computer's local IP, e.g. http://192.168.1.42:${PORT}/"
  fi
fi
if [ "$NO_BROWSER" = 1 ]; then
  echo "No auto-open (--no-browser) — open this manually: $URL"
elif command -v termux-open-url >/dev/null 2>&1; then
  termux-open-url "$URL" >/dev/null 2>&1
elif command -v xdg-open >/dev/null 2>&1; then
  xdg-open "$URL" >/dev/null 2>&1
elif command -v open >/dev/null 2>&1; then
  open "$URL"
else
  echo "Could not auto-open a browser — open this manually: $URL"
fi

echo ""
echo "Controller UI:   $URL"
echo "Test dashboard:  ${URL}test"
[ -n "$LANURL" ] && echo "Other devices:   $LANURL"
[ "$ALLOW_REMOTE" = 1 ] && echo "Remote access:   FULL (--allow) — AI settings/models + ChatGPT browser + e-stop reset from the network"
[ "$MOCK_AI" = 1 ] && echo "AI:              SERVERMOCK — canned replies, no keys needed"
echo "Run log:         $RUN_LOG"
echo "Server log:      logs/server.log"
echo ""
echo "Press Ctrl+C to stop (not Ctrl+Z)."

wait "$BACKEND_PID"
