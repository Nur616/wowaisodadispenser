"""Recipe safety layer for the drink machine.

The AI is allowed to be creative; it is not allowed to decide what is safe.
This module takes a proposed recipe plus the configured pumps and returns a
recipe that is diluted, dosed, and labelled within conservative limits derived
from docs/drink-science.md and docs/allergen-labeling.md.

Design rules
------------
* The LLM never supplies allergen or ABV facts.  Those come from the pump
  configuration (supplier data) or from a built-in flavour catalogue.
* An unknown flavour is *not* assumed safe.  It raises an "allergen status
  unknown" warning and requires an explicit acknowledgment.
* Safety adjustments are deterministic and idempotent: assessing an already
  adjusted recipe returns the same recipe, so the hash a customer acknowledged
  still matches when the dispense request arrives.
* A hard block is used for genuinely dangerous requests (forbidden botanicals,
  too much ethanol, a pump that is too fast to dose safely, a declared allergy
  conflict).  A warning plus acknowledgment is used for uncertainty.

No Arduino or network access is required.
"""

from __future__ import annotations

import hashlib
import json
import math
import re
from typing import Any

POLICY_VERSION = "1.0.0"

WATER_PUMP_ID = 9

# Conservative limits (see docs/drink-science.md, section 11).
MAX_EXTRACT_ML_PER_100ML = {
    "citrus": 0.50,
    "mint": 0.15,
    "vanilla": 1.20,
    "warm_spice": 0.20,
    "berry_fruit": 1.00,
    "herbal_tea": 0.60,
    "floral": 0.08,
    "coffee_cocoa_bitter": 0.50,
    "unknown": 0.30,
}
MAX_TOTAL_EXTRACT_ML = 5.0
MAX_TOTAL_EXTRACT_PCT = 1.2
MAX_SINGLE_PUMP_ML = 2.0
MIN_WATER_ML_PER_ML_EXTRACT = 40.0
MAX_ETHANOL_PCT = 0.5
MAX_ETHANOL_ML = 1.5
# Leave a margin under the hard 0.5 % line so rounding and calibration error
# cannot push a served drink over it.
ETHANOL_TARGET_PCT = 0.40
MAX_FINAL_ML = 500.0
DEFAULT_CUP_ML = 355.0
DEFAULT_FLAVOR_FLOW = 2.0      # ml/s, conservative upper bound when a pump is not calibrated
DEFAULT_WATER_FLOW = 20.0      # ml/s, typical high-flow water pump
MIN_FLAVOR_SECONDS = 0.1
MAX_WATER_SECONDS = 120

ALLERGEN_LABELS = {
    "milk": "milk",
    "egg": "egg",
    "fish": "fish",
    "crustacean_shellfish": "crustacean shellfish",
    "tree_nut": "tree nuts",
    "peanut": "peanuts",
    "wheat": "wheat",
    "soybean": "soy",
    "sesame": "sesame",
    "gluten_cereal": "gluten",
    "celery": "celery",
    "mustard": "mustard",
    "sulphites": "sulphites",
    "lupin": "lupin",
    "molluscs": "molluscs",
    "alcohol": "alcohol",
    "caffeine": "caffeine",
    "other": "other",
}

# Words that must never be dispensed in this machine, even if a pump is named
# after them.  The list comes from the toxicology section of drink-science.md.
FORBIDDEN = (
    "wintergreen oil",
    "wintergreen",
    "methyl salicylate",
    "sassafras",
    "safrole",
    "cassia",
    "licorice root",
    "liquorice root",
    "quinine",
    "guarana",
    "ephedra",
    "kava",
    "comfrey",
    "wormwood",
    "essential oil",
    "pure oil",
    "caffeine powder",
)

# A compact catalogue of common soda flavours.  Each entry:
#   family: palatability family
#   allergens: {allergen_id: "contains" | "may_contain"}
#   specific: optional specific nut/fish name for the label
#   abv: percent ethanol in the concentrate (0 when it is a syrup)
#   extract: True when the product is a concentrated flavour extract
FLAVORS: dict[str, dict[str, Any]] = {
    # nuts
    "peanut": {"family": "berry_fruit", "allergens": {"peanut": "contains"}},
    "groundnut": {"family": "berry_fruit", "allergens": {"peanut": "contains"}},
    "almond": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "almond"},
    "hazelnut": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "hazelnut"},
    "filbert": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "hazelnut"},
    "cashew": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "cashew"},
    "pistachio": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "pistachio"},
    "walnut": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "walnut"},
    "pecan": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "pecan"},
    "macadamia": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "macadamia"},
    "brazil nut": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "brazil nut"},
    "coconut": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}, "specific": "coconut"},
    "nut": {"family": "berry_fruit", "allergens": {"tree_nut": "contains"}},
    # dairy / egg / grain / soy / sesame
    "milk": {"family": "vanilla", "allergens": {"milk": "contains"}},
    "cream": {"family": "vanilla", "allergens": {"milk": "contains"}},
    "dairy": {"family": "vanilla", "allergens": {"milk": "contains"}},
    "butter": {"family": "vanilla", "allergens": {"milk": "contains"}},
    "cheese": {"family": "coffee_cocoa_bitter", "allergens": {"milk": "contains"}},
    "yogurt": {"family": "berry_fruit", "allergens": {"milk": "contains"}},
    "egg": {"family": "vanilla", "allergens": {"egg": "contains"}},
    "wheat": {"family": "coffee_cocoa_bitter", "allergens": {"wheat": "contains", "gluten_cereal": "contains"}},
    "gluten": {"family": "coffee_cocoa_bitter", "allergens": {"gluten_cereal": "contains", "wheat": "contains"}},
    "barley": {"family": "coffee_cocoa_bitter", "allergens": {"gluten_cereal": "contains"}},
    "malt": {"family": "coffee_cocoa_bitter", "allergens": {"gluten_cereal": "contains"}},
    "rye": {"family": "coffee_cocoa_bitter", "allergens": {"gluten_cereal": "contains"}},
    "oat": {"family": "coffee_cocoa_bitter", "allergens": {"gluten_cereal": "may_contain"}},
    "soy": {"family": "coffee_cocoa_bitter", "allergens": {"soybean": "contains"}},
    "soya": {"family": "coffee_cocoa_bitter", "allergens": {"soybean": "contains"}},
    "soybean": {"family": "coffee_cocoa_bitter", "allergens": {"soybean": "contains"}},
    "sesame": {"family": "warm_spice", "allergens": {"sesame": "contains"}},
    "tahini": {"family": "warm_spice", "allergens": {"sesame": "contains"}},
    "mustard": {"family": "warm_spice", "allergens": {"mustard": "contains"}},
    "celery": {"family": "herbal_tea", "allergens": {"celery": "contains"}},
    "lupin": {"family": "herbal_tea", "allergens": {"lupin": "contains"}},
    "fish": {"family": "coffee_cocoa_bitter", "allergens": {"fish": "contains"}},
    "oyster": {"family": "coffee_cocoa_bitter", "allergens": {"molluscs": "contains"}},
    "clam": {"family": "coffee_cocoa_bitter", "allergens": {"molluscs": "contains"}},
    "shrimp": {"family": "coffee_cocoa_bitter", "allergens": {"crustacean_shellfish": "contains"}},
    "crab": {"family": "coffee_cocoa_bitter", "allergens": {"crustacean_shellfish": "contains"}},
    "lobster": {"family": "coffee_cocoa_bitter", "allergens": {"crustacean_shellfish": "contains"}},
    # chocolate and caramel are cross-contact risks
    "chocolate": {"family": "coffee_cocoa_bitter", "allergens": {"milk": "may_contain", "soybean": "may_contain"}},
    "cocoa": {"family": "coffee_cocoa_bitter", "allergens": {"milk": "may_contain", "soybean": "may_contain"}},
    "caramel": {"family": "vanilla", "allergens": {"milk": "may_contain"}},
    "toffee": {"family": "vanilla", "allergens": {"milk": "may_contain"}},
    # citrus
    "lemon": {"family": "citrus"},
    "lime": {"family": "citrus"},
    "orange": {"family": "citrus"},
    "grapefruit": {"family": "citrus", "note": "grapefruit can interact with some medicines"},
    "tangerine": {"family": "citrus"},
    "mandarin": {"family": "citrus"},
    "bergamot": {"family": "citrus"},
    "yuzu": {"family": "citrus"},
    # mint
    "mint": {"family": "mint"},
    "peppermint": {"family": "mint"},
    "spearmint": {"family": "mint"},
    "menthol": {"family": "mint"},
    # vanilla
    "vanilla": {"family": "vanilla", "extract": True, "abv": 35.0},
    "vanillin": {"family": "vanilla", "extract": True, "abv": 0.0},
    "custard": {"family": "vanilla", "allergens": {"milk": "may_contain", "egg": "may_contain"}},
    # warm spice
    "cinnamon": {"family": "warm_spice", "note": "most cinnamon is cassia; use Ceylon cinnamon"},
    "clove": {"family": "warm_spice"},
    "nutmeg": {"family": "warm_spice"},
    "ginger": {"family": "warm_spice"},
    "allspice": {"family": "warm_spice"},
    "cardamom": {"family": "warm_spice"},
    "anise": {"family": "warm_spice"},
    "fennel": {"family": "warm_spice"},
    "chai": {"family": "warm_spice", "allergens": {"milk": "may_contain"}},
    "pumpkin spice": {"family": "warm_spice"},
    # fruit / berry
    "strawberry": {"family": "berry_fruit"},
    "raspberry": {"family": "berry_fruit"},
    "blueberry": {"family": "berry_fruit"},
    "blackberry": {"family": "berry_fruit"},
    "cherry": {"family": "berry_fruit"},
    "grape": {"family": "berry_fruit"},
    "peach": {"family": "berry_fruit"},
    "mango": {"family": "berry_fruit"},
    "pineapple": {"family": "berry_fruit"},
    "apple": {"family": "berry_fruit"},
    "pear": {"family": "berry_fruit"},
    "watermelon": {"family": "berry_fruit"},
    "melon": {"family": "berry_fruit"},
    "banana": {"family": "berry_fruit"},
    "tropical": {"family": "berry_fruit"},
    "fruit punch": {"family": "berry_fruit"},
    "cranberry": {"family": "berry_fruit"},
    "pomegranate": {"family": "berry_fruit"},
    "passionfruit": {"family": "berry_fruit"},
    "passion fruit": {"family": "berry_fruit"},
    "lychee": {"family": "berry_fruit"},
    "kiwi": {"family": "berry_fruit"},
    "apricot": {"family": "berry_fruit"},
    "plum": {"family": "berry_fruit"},
    "fig": {"family": "berry_fruit"},
    "berry": {"family": "berry_fruit"},
    "fruit": {"family": "berry_fruit"},
    # herbal / tea / floral
    "tea": {"family": "herbal_tea"},
    "chamomile": {"family": "herbal_tea"},
    "hibiscus": {"family": "herbal_tea"},
    "rooibos": {"family": "herbal_tea"},
    "elderflower": {"family": "herbal_tea"},
    "jasmine": {"family": "herbal_tea"},
    "yerba": {"family": "herbal_tea"},
    "mate": {"family": "herbal_tea"},
    "rose": {"family": "floral"},
    "lavender": {"family": "floral"},
    "orange blossom": {"family": "floral"},
    "violet": {"family": "floral"},
    "honeysuckle": {"family": "floral"},
    # coffee / cocoa / bitter / soda
    "coffee": {"family": "coffee_cocoa_bitter", "caffeine": True},
    "espresso": {"family": "coffee_cocoa_bitter", "caffeine": True},
    "mocha": {"family": "coffee_cocoa_bitter", "caffeine": True, "allergens": {"milk": "may_contain"}},
    "chicory": {"family": "coffee_cocoa_bitter"},
    "hops": {"family": "coffee_cocoa_bitter"},
    "beer": {"family": "coffee_cocoa_bitter", "allergens": {"gluten_cereal": "contains"}, "abv": 5.0},
    "wine": {"family": "berry_fruit", "allergens": {"sulphites": "contains"}, "abv": 12.0},
    "root beer": {"family": "coffee_cocoa_bitter"},
    "cola": {"family": "coffee_cocoa_bitter", "caffeine": True},
    "tonic": {"family": "coffee_cocoa_bitter", "note": "tonic contains quinine; avoid in pregnancy and with some medicines"},
    "bitters": {"family": "coffee_cocoa_bitter", "abv": 44.0},
    "soda": {"family": "coffee_cocoa_bitter"},
    # neutral
    "sparkling water": {"family": "unknown", "water": True},
    "water": {"family": "unknown", "water": True},
}

def _norm(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _has_word(text: str, word: str) -> bool:
    return re.search(r"(?<![a-z0-9])" + re.escape(word) + r"(?![a-z0-9])", text) is not None


def _number(value: Any, default: float | None = None) -> float | None:
    try:
        if isinstance(value, bool) or value is None or value == "":
            return default
        number = float(value)
    except (TypeError, ValueError):
        return default
    if not math.isfinite(number):
        return default
    return number


def _parse_allergen_override(raw: Any) -> dict[str, str] | None:
    """Parse a per-pump allergen field.

    Accepts a list like ``["peanut", "may:tree_nut", "unknown"]`` or a dict
    like ``{"peanut": "contains"}``.  Returns None when the field is absent so
    the catalogue can be used instead.
    """
    if raw is None or raw == "":
        return None
    tags: dict[str, str] = {}
    if isinstance(raw, dict):
        items = list(raw.items())
    elif isinstance(raw, str):
        items = [(part, None) for part in raw.split(",")]
    elif isinstance(raw, list):
        items = [(part, None) for part in raw]
    else:
        return {allergen: "unknown" for allergen in ALLERGEN_LABELS}
    for key, value in items:
        name = _norm(key).replace("-", "_").replace(" ", "_")
        if not name:
            continue
        prefix = None
        if ":" in name:
            prefix, name = name.split(":", 1)
        presence = _norm(value) if value is not None else (prefix or "contains")
        if presence in ("may", "may_contain", "possible", "cross_contact"):
            presence = "may_contain"
        elif presence not in ("contains", "may_contain", "unknown", "absent"):
            presence = "unknown"
        if name in ("sulfites", "sulphite"):
            name = "sulphites"
        if name in ("nuts", "nut", "tree_nuts"):
            name = "tree_nut"
        if name in ("shellfish", "crustacean"):
            name = "crustacean_shellfish"
        if name == "soy":
            name = "soybean"
        tags[name] = presence
    return tags or None


def identify(flavor: str, pump: dict[str, Any] | None = None) -> dict[str, Any]:
    """Resolve a configured flavour name to a safety profile.

    Per-pump supplier data (``allergens``, ``abv``, ``family``, ``extract``)
    always wins over the catalogue.  Unknown flavours are marked unknown.
    """
    pump = pump or {}
    name = _norm(flavor)
    profile: dict[str, Any] = {"family": "unknown", "allergens": {}, "specific": None,
                               "abv": 0.0, "extract": False, "caffeine": False,
                               "water": False, "blocked": None, "note": None,
                               "unknown": False, "source": "catalogue"}

    if not name:
        profile.update(unknown=True, source="empty")
        return profile

    # A phrase like "cream soda" is not dairy and "root beer" is not beer.
    # Resolve those phrases before the word-by-word catalogue.
    phrase_override = None
    if _has_word(name, "cream soda"):
        phrase_override = {"family": "vanilla", "allergens": {"milk": "may_contain"}}
    elif _has_word(name, "root beer"):
        phrase_override = {"family": "coffee_cocoa_bitter"}
    elif _has_word(name, "ginger beer"):
        phrase_override = {"family": "warm_spice"}
    elif _has_word(name, "butterfly pea"):
        phrase_override = {"family": "herbal_tea"}

    # Forbidden botanicals are checked first and are never dispensed.
    for bad in FORBIDDEN:
        if _has_word(name, bad):
            profile["blocked"] = "The flavour %s is not safe to dispense (%s)." % (flavor, bad)
            return profile

    if phrase_override is not None:
        profile.update(phrase_override)
    else:
        for keyword, data in FLAVORS.items():
            if _has_word(name, keyword):
                profile.update(data)
                profile["source"] = "catalogue"
                break
        else:
            profile["unknown"] = True

    # Free text like "vanilla extract" carries the standard 35 % ABV.
    if "alcohol free" in name or "alcohol-free" in name or "non-alcoholic" in name:
        profile["abv"] = 0.0
    elif "extract" in name and not profile.get("water"):
        profile.setdefault("abv", 35.0)
        profile["extract"] = True
        if profile["abv"] is None:
            profile["abv"] = 35.0
    if "wine" in name and not profile.get("abv"):
        profile["abv"] = 12.0
    if "bitters" in name:
        profile["abv"] = 44.0
    if "syrup" in name or "puree" in name or "juice" in name:
        profile["abv"] = 0.0
        profile["extract"] = False

    # Explicit pump configuration overrides the catalogue.
    override_tags = _parse_allergen_override(pump.get("allergens"))
    if override_tags is not None:
        explicit_unknown = override_tags.pop("unknown", None) is not None
        profile["allergens"] = {k: v for k, v in override_tags.items() if v != "absent"}
        profile["unknown"] = explicit_unknown
        profile["source"] = "pump config"
    family = _norm(pump.get("family"))
    if family in MAX_EXTRACT_ML_PER_100ML:
        profile["family"] = family
    abv = _number(pump.get("abv"))
    if abv is not None:
        profile["abv"] = max(0.0, min(95.0, abv))
    if "extract" in pump:
        profile["extract"] = bool(pump.get("extract"))

    # Unknown status means we cannot claim any allergen is absent.
    if profile["unknown"]:
        profile["allergens"] = {allergen: "unknown" for allergen in ALLERGEN_LABELS
                                if allergen not in ("alcohol", "caffeine", "other")}
    return profile


def _label(allergen: str, specific: str | None = None) -> str:
    if allergen == "tree_nut" and specific:
        return "%s (tree nut)" % specific
    return ALLERGEN_LABELS.get(allergen, allergen.replace("_", " "))


def _canonical(recipe: dict[str, Any], cup_ml: float, pump_profiles: dict[str, Any] | None = None) -> str:
    payload = {
        "policy": POLICY_VERSION,
        "cup_ml": round(cup_ml, 1),
        "pumps": pump_profiles or {},
        "ingredients": [
            {
                "pump_id": int(item["pump_id"]),
                "seconds": round(float(item["seconds"]), 2),
                "speed": int(item.get("speed", 0)),
                "flavor": _norm(item.get("flavor")),
            }
            for item in sorted(recipe.get("ingredients", []), key=lambda item: item["pump_id"])
        ],
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode()).hexdigest()


def _flow(pump: dict[str, Any], water: bool = False) -> tuple[float, bool]:
    raw = _number(pump.get("flow_ml_per_second", pump.get("flowMlPerSecond")))
    if raw is not None and raw > 0:
        return raw, True
    return (DEFAULT_WATER_FLOW if water else DEFAULT_FLAVOR_FLOW), False


def assess(
    recipe: dict[str, Any],
    available: dict[int, dict[str, Any]],
    cup_ml: float = DEFAULT_CUP_ML,
    strength: str = "balanced",
    declared_allergens: list[str] | None = None,
) -> dict[str, Any]:
    """Return a safety-adjusted copy of ``recipe`` and a ``safety`` report.

    ``available`` maps pump id -> pump configuration.  ``recipe`` must already
    have passed structural validation.  The returned dict has the shape::

        {"recipe": {...}, "safety": {...}}
    """
    cup_ml = max(150.0, min(700.0, _number(cup_ml, DEFAULT_CUP_ML) or DEFAULT_CUP_ML))
    declared = {_norm(item).replace(" ", "_") for item in (declared_allergens or [])}
    ingredients = [dict(item) for item in recipe.get("ingredients", [])]
    adjustments: list[str] = []
    blocked_reasons: list[str] = []

    flavor_items = []
    water_item = None
    for item in ingredients:
        pump_id = int(item["pump_id"])
        if pump_id == WATER_PUMP_ID:
            water_item = item
            continue
        pump = available.get(pump_id, {})
        profile = identify(item.get("flavor") or pump.get("flavor", ""), pump)
        flow, calibrated = _flow(pump)
        item["_profile"] = profile
        item["_flow"] = flow
        item["_calibrated"] = calibrated
        item["_ml"] = max(0.0, float(item.get("seconds", 0))) * flow
        flavor_items.append(item)
        if profile.get("blocked"):
            blocked_reasons.append(profile["blocked"])

    # Per-pump and per-family ceilings, then the total cap.
    max_total_ml = min(MAX_TOTAL_EXTRACT_ML, MAX_TOTAL_EXTRACT_PCT / 100.0 * cup_ml)
    for item in flavor_items:
        profile = item["_profile"]
        family = profile.get("family", "unknown")
        max_ml = min(MAX_SINGLE_PUMP_ML,
                     MAX_EXTRACT_ML_PER_100ML.get(family, MAX_EXTRACT_ML_PER_100ML["unknown"]) / 100.0 * cup_ml)
        if item["_ml"] > max_ml:
            adjustments.append("%s reduced from %.1f ml to %.1f ml for a balanced dose." %
                               (item.get("flavor", "flavour"), item["_ml"], max_ml))
            item["_ml"] = max_ml
    total_ml = sum(item["_ml"] for item in flavor_items)
    if total_ml > max_total_ml and total_ml > 0:
        scale = max_total_ml / total_ml
        for item in flavor_items:
            item["_ml"] *= scale
        adjustments.append("Total flavour reduced to %.1f ml to keep the drink palatable." % max_total_ml)
        total_ml = max_total_ml

    # Ethanol ceiling.  Clamp before converting back to seconds.
    ethanol_ml = sum(item["_ml"] * max(0.0, float(item["_profile"].get("abv") or 0.0)) / 100.0
                     for item in flavor_items)
    ethanol_cap = min(MAX_ETHANOL_ML, cup_ml * ETHANOL_TARGET_PCT / 100.0)
    if ethanol_ml > ethanol_cap and ethanol_ml > 0:
        scale = ethanol_cap / ethanol_ml
        for item in flavor_items:
            if item["_profile"].get("abv"):
                item["_ml"] *= scale
        adjustments.append("Alcohol-containing extract reduced to keep the drink under %.1f%% ABV." %
                           ETHANOL_TARGET_PCT)
        total_ml = sum(item["_ml"] for item in flavor_items)

    # Convert millilitres back to integer seconds.  Round down so a 1-second
    # minimum cannot silently exceed the dose ceiling.
    for item in flavor_items:
        flow = item["_flow"]
        seconds = math.floor(item["_ml"] / flow * 10 + 1e-9) / 10 if flow > 0 else MIN_FLAVOR_SECONDS
        item["seconds"] = max(MIN_FLAVOR_SECONDS, round(seconds, 1))
        item["_ml"] = item["seconds"] * flow
        if flow > MAX_SINGLE_PUMP_ML:
            blocked_reasons.append(
                "%s flows at %.1f ml/s; even a short dose exceeds the %.1f ml safe dose. "
                "Lower that pump's speed or calibrate it." % (item.get("flavor", "Pump"), flow, MAX_SINGLE_PUMP_ML))
        if not item["_calibrated"]:
            adjustments.append("%s is not calibrated; its volume is an estimate." % item.get("flavor", "Pump"))

    total_ml = sum(item["_ml"] for item in flavor_items)

    # Water is the base liquid, not an optional garnish.  Keep at least 40 ml
    # of water per 1 ml of extract and fill toward the cup size.
    no_water = water_item is None and WATER_PUMP_ID not in available
    if no_water and total_ml > 1.0:
        scale = 1.0 / total_ml
        for item in flavor_items:
            item["_ml"] *= scale
            item["seconds"] = max(MIN_FLAVOR_SECONDS,
                                  round(math.floor(item["_ml"] / item["_flow"] * 10 + 1e-9) / 10, 1))
            item["_ml"] = item["seconds"] * item["_flow"]
        total_ml = sum(item["_ml"] for item in flavor_items)
        adjustments.append("Flavour capped to a 1 ml concentrate because no water pump is configured. "
                           "Add 250-350 ml of water before drinking.")

    required_water_ml = max(cup_ml - total_ml, MIN_WATER_ML_PER_ML_EXTRACT * total_ml)
    required_water_ml = max(0.0, min(MAX_FINAL_ML, required_water_ml))
    water_ml = 0.0
    if WATER_PUMP_ID in available and (water_item is not None or total_ml > 0):
        water_pump = available[WATER_PUMP_ID]
        water_flow, water_calibrated = _flow(water_pump, water=True)
        water_seconds = int(math.ceil(required_water_ml / water_flow)) if water_flow > 0 else 1
        water_seconds = max(1, min(MAX_WATER_SECONDS, water_seconds))
        water_ml = water_seconds * water_flow
        if water_item is None:
            water_item = {
                "pump_id": WATER_PUMP_ID,
                "flavor": water_pump.get("flavor", "Sparkling water"),
                "seconds": water_seconds,
                "speed": int(water_pump.get("speed", 100)),
            }
            ingredients.append(water_item)
            adjustments.append("Added %.0f ml of sparkling water to dilute the flavour." % water_ml)
        else:
            water_item["seconds"] = water_seconds
            water_item["speed"] = int(water_pump.get("speed", water_item.get("speed", 100)))
            water_ml = water_seconds * water_flow
        if not water_calibrated:
            adjustments.append("The water pump is not calibrated; the final volume is an estimate.")

    # Recompute ethanol with the final volumes.
    total_volume = total_ml + water_ml
    ethanol_ml = sum(item["_ml"] * max(0.0, float(item["_profile"].get("abv") or 0.0)) / 100.0
                     for item in flavor_items)
    abv = (ethanol_ml / total_volume * 100.0) if total_volume > 0 else 0.0
    if abv >= MAX_ETHANOL_PCT:
        blocked_reasons.append("This recipe would contain %.2f%% alcohol, above the %.1f%% limit. "
                               "Choose a non-alcoholic flavour." % (abv, MAX_ETHANOL_PCT))

    # Build the allergen report.
    contains: list[str] = []
    may_contain: list[str] = []
    unknown: list[str] = []
    notes: list[str] = []
    for item in flavor_items:
        profile = item["_profile"]
        specific = profile.get("specific")
        for allergen, presence in (profile.get("allergens") or {}).items():
            label = _label(allergen, specific)
            if presence == "contains" and label not in contains:
                contains.append(label)
            elif presence == "may_contain" and label not in may_contain:
                may_contain.append(label)
            elif presence == "unknown" and item.get("flavor") not in unknown:
                unknown.append(item.get("flavor", "an ingredient"))
        if profile.get("note"):
            notes.append("%s: %s." % (item.get("flavor", "Ingredient"), profile["note"]))
        if profile.get("unknown") and item.get("flavor") not in unknown:
            unknown.append(item.get("flavor", "an ingredient"))

    if declared:
        conflict = set(declared) & ({a for a in contains} | {a for a in may_contain} | set(unknown))
        # Declared allergies are also compared against the raw ids, not labels.
        for item in flavor_items:
            ids = set((item["_profile"].get("allergens") or {}).keys())
            if declared & ids:
                conflict |= declared & ids
        if conflict:
            blocked_reasons.append("The recipe conflicts with a declared allergy (%s)." %
                                   ", ".join(sorted(conflict)))

    warnings = []
    severity = "L0"
    rank = {"L0": 0, "L4": 1, "L1": 2, "L2": 3, "L3": 4}
    if contains:
        severity = "L2" if rank["L2"] > rank[severity] else severity
        warnings.append({"level": "L2", "kind": "contains",
                         "text": "Allergy warning: contains %s." % ", ".join(contains),
                         "allergens": contains})
    if may_contain:
        severity = "L1" if rank["L1"] > rank[severity] else severity
        warnings.append({"level": "L1", "kind": "may_contain",
                         "text": "Allergy warning: may contain %s. This machine uses shared pumps and nozzles." %
                                 ", ".join(may_contain),
                         "allergens": may_contain})
    if unknown:
        severity = "L3" if rank["L3"] > rank[severity] else severity
        warnings.append({"level": "L3", "kind": "unknown",
                         "text": "Allergy warning: allergen status unknown for %s. "
                                 "Do not drink this if you have a food allergy." % ", ".join(unknown),
                         "allergens": unknown})
    if abv > 0:
        severity = "L4" if rank["L4"] > rank[severity] else severity
        warnings.append({"level": "L4", "kind": "alcohol",
                         "text": "Contains alcohol: about %.2f%% ABV from flavour extracts." % abv,
                         "allergens": ["alcohol"]})
    if not warnings:
        warnings.append({"level": "L0", "kind": "none",
                         "text": "No major allergens are listed for this recipe.",
                         "allergens": []})
    warnings.extend({"level": "NOTE", "kind": "note", "text": note, "allergens": []} for note in notes)
    if adjustments:
        warnings.extend({"level": "NOTE", "kind": "adjustment", "text": text, "allergens": []}
                        for text in adjustments)

    blocked = bool(blocked_reasons)
    if blocked:
        severity = "BLOCKED"
        warnings.insert(0, {
            "level": "BLOCKED",
            "kind": "blocked",
            "text": "We cannot make this drink safely. " + " ".join(blocked_reasons),
            "allergens": [],
        })

    clean_ingredients = []
    for item in ingredients:
        pump_id = int(item["pump_id"])
        if pump_id == WATER_PUMP_ID and water_item is None:
            continue
        clean_ingredients.append({
            "pump_id": pump_id,
            "flavor": item.get("flavor") or available.get(pump_id, {}).get("flavor", ""),
            "seconds": round(float(item["seconds"]), 1),
            "speed": int(item.get("speed", available.get(pump_id, {}).get("speed", 100))),
        })
    clean_ingredients.sort(key=lambda item: item["pump_id"])

    safe_recipe = {
        "name": recipe.get("name", "AI Soda"),
        "reply": recipe.get("reply", "Your drink is ready to review."),
        "ingredients": clean_ingredients,
    }
    # Bind the acknowledgment to the supplier data and calibration that produced
    # the warning.  If an operator edits a pump's allergen or ABV data, or
    # recalibrates it, an old acknowledgment must no longer match.
    pump_profiles = {}
    for item in flavor_items:
        profile = item["_profile"]
        pump_profiles[str(item["pump_id"])] = {
            "family": profile.get("family"),
            "abv": round(float(profile.get("abv") or 0.0), 3),
            "allergens": dict(sorted((profile.get("allergens") or {}).items())),
            "specific": profile.get("specific"),
            "unknown": bool(profile.get("unknown")),
            "flow": round(float(item["_flow"]), 3),
        }
    safety = {
        "policy_version": POLICY_VERSION,
        "severity": severity,
        "blocked": blocked,
        "ack_required": severity not in ("L0", "BLOCKED") and not blocked,
        "warnings": warnings,
        "allergens": {"contains": contains, "may_contain": may_contain, "unknown": unknown},
        "abv_percent": round(abv, 3),
        "estimated_flavor_ml": round(total_ml, 2),
        "estimated_water_ml": round(water_ml, 1),
        "estimated_total_ml": round(total_volume, 1),
        "concentration_percent": round(total_ml / total_volume * 100.0, 3) if total_volume else 0.0,
        "calibrated": all(item["_calibrated"] for item in flavor_items),
        "adjustments": adjustments,
        "recipe_hash": _canonical(safe_recipe, cup_ml, pump_profiles),
        "cup_ml": round(cup_ml, 1),
        "strength": strength if strength in ("light", "balanced", "bold") else "balanced",
        "declared_allergens": sorted(declared),
    }
    return {"recipe": safe_recipe, "safety": safety}
