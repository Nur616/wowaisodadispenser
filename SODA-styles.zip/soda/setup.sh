#!/usr/bin/env bash
# One-command first-time setup for Linux, macOS and Termux.
#
#   bash setup.sh                 core libraries; asks one y/n question per extra (first run)
#   bash setup.sh --extras all    core + every optional library
#   bash setup.sh --extras browser,jarvis
#   bash setup.sh --no-extras     core only, never ask
#   bash setup.sh --ask-extras    change an earlier answer
#   bash setup.sh --list-extras   show what is optional on this machine
#   bash setup.sh --reinstall     reinstall the core libraries from scratch
#
# It works on every device because start.sh detects the operating system, keeps one
# virtualenv per OS (.venv-linux / .venv-mac / .venv-termux) and only ever installs
# the CORE libraries unless you ask for more. Windows: run  setup.bat
set -e
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
exec bash "$DIR/start.sh" setup "$@"
