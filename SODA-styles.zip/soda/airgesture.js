/* airgesture.js — webcam air-gesture pointer for the Coda kiosk.
 *
 * Two vision engines run together:
 *   1. MediaPipe HandLandmarker (21 landmarks) — precise 3-finger pen-grip + index tap.
 *   2. A dependency-free skin/contour tracker — "constant tracker" that keeps the hand
 *      located when landmarks drop, and works with no internet if MediaPipe cannot load.
 *
 * The pointer is a CSS/Canvas glass object with a 12-style pack. When it settles on a
 * button, slider or block it grows from the pointer into a rounded glass outline around
 * that target — the pointer itself becomes the target shape (it does not use CSS :hover).
 *
 * Everything lives in config.air (saved inside soda_kiosk_config):
 *   Settings ▸ Air gesture          live tuning + camera preview
 *   /airgesture                     full camera/gesture lab and test targets
 *
 * Public API: window.AirGesture
 */
(function () {
  'use strict';

  const VERSION = '1.0.0';
  const MP_VERSION = '0.10.14';
  const MP_CDN = 'https://cdn.jsdelivr.net/npm/@mediapipe/tasks-vision@' + MP_VERSION;
  const MP_UNPKG = 'https://unpkg.com/@mediapipe/tasks-vision@' + MP_VERSION;
  const MP_MODEL = 'https://storage.googleapis.com/mediapipe-models/hand_landmarker/hand_landmarker/float16/1/hand_landmarker.task';
  const LOCAL_BASE = '/vendor/airgesture';
  const POINTER_STYLES = [
    ['orb', 'Glass orb'], ['dot', 'Minimal dot'], ['ring', 'Hollow ring'],
    ['crosshair', 'Crosshair'], ['comet', 'Comet'], ['star', 'Star'],
    ['bubble', 'Soap bubble'], ['neon', 'Neon reticle'], ['pixel', 'Pixel'],
    ['arrow', 'Classic arrow'], ['petal', 'Petal'], ['ink', 'Ink drop']
  ];

  const IS_MOBILE = (() => {
    try {
      return /Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent || '') ||
        (window.matchMedia && matchMedia('(pointer: coarse)').matches);
    } catch (e) { return false; }
  })();

  const AIR_DEF = {
    enabled: true,
    autoStart: true,
    startDelayMs: 1400,
    reactFace: true,
    statusPill: true,
    vision: {
      source: 'camera',              // camera | demo
      engine: 'auto',                // auto | landmarker | contour
      deviceId: '',
      resolution: '640x480',
      fps: 24,
      mirror: true,
      assets: 'auto',                // auto | cdn | local
      delegate: 'GPU',               // GPU | CPU
      maxHands: 1,
      minHandConfidence: 0.45,
      minPresenceConfidence: 0.45,
      minTrackingConfidence: 0.40,
      contourFallback: true,
      contourFps: 12,
      pauseWhenHidden: true,
      privacyIndicator: true,
      skinTolerance: 55,
      skinMinArea: 0.006,
      contourMaxPeaks: 3,
      contourMinSolidity: 0.30,
      contourActivateFrames: 3,
      contourReleaseFrames: 6
    },
    gesture: {
      pinchEnter: 0.78,
      pinchExit: 1.10,
      requireFolded: true,
      ringFoldMax: 0.95,
      pinkyFoldMax: 0.90,
      activationFrames: 4,
      releaseFrames: 8,
      settleMs: 350,
      clickMode: 'indexTap',         // indexTap | dwell | manual
      clickUp: 1.05,
      clickDown: 0.72,
      clickLiftDelta: 0.18,          // adaptive lift distance above the pen-grip baseline
      clickDropDelta: 0.18,          // how far the index must fall from its peak to finish a tap
      tapWindowMs: 1000,
      dwellMs: 850,
      confidenceMin: 0.30,
      handedness: 'any'              // any | Left | Right
    },
    tracker: {
      mode: 'relative',              // relative (wrist like a mouse) | absolute (point at screen)
      point: 'palm',                 // palm | index | middle | pinch
      sensX: 1.0,
      sensY: 1.0,
      relativeGain: 2.2,
      invertX: false,
      invertY: false,
      boxLeft: 0.10,
      boxTop: 0.10,
      boxRight: 0.90,
      boxBottom: 0.90,
      deadzone: 1.5,
      smoothMinCutoff: 1.6,
      smoothBeta: 0.025,
      predictionMs: 28,
      lostHoldMs: 420,
      hideDelayMs: 180,
      edgeClamp: true
    },
    pointer: {
      size: 46,
      core: 13,
      style: 'orb',                  // orb | dot | ring | crosshair | comet | star | bubble | neon | pixel | arrow | petal | ink
      quality: 'auto',               // auto | full | lite (lite is default on phones)
      primary: '#7ef7d4',
      secondary: '#ff8bd1',
      accent: '#73a6ff',
      glass: 0.34,
      blur: 12,
      border: 1.2,
      glow: 80,
      hueShift: 0,
      spin: 14,
      trail: 55,
      trailWidth: 3,
      particles: true,
      particleCount: 18,
      lockScale: 0.42,
      pointerMorph: true,            // hide the dot and let the glass shape become the target
      morphFromPointer: true,        // grow the outline from the pointer position
      morphExpandMs: 220,
      morphMode: 'highlight',        // highlight (iPad-style) | clone | label | outline | none
      morphVersion: 2,               // bump when the morph behaviour changes
      morphPad: 7,
      morphOpacity: 0.86,
      snapRadius: 30,
      lockDelayMs: 85,
      unlockDelayMs: 140,
      blockTargets: true,
      blockMaxAreaPct: 32,
      sliderLive: true,
      edgeScroll: true,
      edgeScrollPx: 26,
      edgeScrollSpeed: 9,
      hideSystemCursor: false,
      highContrast: false,
      reducedMotion: false
    },
    sound: {
      enabled: true,
      volume: 55,
      style: 'glass',                // glass | soft | synth | retro
      events: { appear: true, lock: true, click: true, release: true, error: true, calibrate: true, tick: false }
    },
    debug: {
      showOverlay: false,
      drawLandmarks: true,
      logToConsole: false
    }
  };

  const clone = v => JSON.parse(JSON.stringify(v));
  function merge(base, over) {
    const out = clone(base);
    if (over && typeof over === 'object' && !Array.isArray(over)) {
      Object.keys(over).forEach(k => {
        if (over[k] && typeof over[k] === 'object' && !Array.isArray(over[k]) && out[k] && typeof out[k] === 'object') out[k] = merge(out[k], over[k]);
        else if (over[k] !== undefined) out[k] = over[k];
      });
    }
    return out;
  }
  const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
  const lerp = (a, b, t) => a + (b - a) * t;
  const nowMs = () => performance.now();
  const num = (v, d) => (Number.isFinite(+v) ? +v : d);
  const cssVar = (k, v) => document.documentElement.style.setProperty(k, v);

  let cfgRoot;
  try {
    cfgRoot = (window.CodaKiosk && window.CodaKiosk.config) || JSON.parse(localStorage.getItem('soda_kiosk_config') || '{}') || {};
  } catch (e) { cfgRoot = {}; }
  if (!cfgRoot.air || typeof cfgRoot.air !== 'object') cfgRoot.air = {};
  const savedAir = cfgRoot.air;
  // The first morph build used a glass label and had no schema marker. A
  // pointer.morphVersion of 2 means this config has seen the iPad-style build;
  // only then do we trust an explicit "label"/"outline" choice. Older configs
  // are migrated once, including the old 700 ms tap window and .30 lift delta.
  const needsMorphMigration = !savedAir.pointer || Number(savedAir.pointer.morphVersion) !== 2;
  cfgRoot.air = merge(AIR_DEF, savedAir);
  const AIR = cfgRoot.air;
  if (needsMorphMigration) {
    if (AIR.pointer.morphMode === 'label') AIR.pointer.morphMode = 'highlight';
    AIR.pointer.pointerMorph = true;
    AIR.pointer.morphFromPointer = true;
    AIR.pointer.morphVersion = 2;
    if (num(AIR.gesture.tapWindowMs, 0) === 700) AIR.gesture.tapWindowMs = 1000;
    if (Math.abs(num(AIR.gesture.clickLiftDelta, 0) - 0.30) < 1e-9) AIR.gesture.clickLiftDelta = 0.18;
    saveCfg();
  }

  function saveCfg() {
    try {
      if (window.CodaKiosk && window.CodaKiosk.saveConfig) window.CodaKiosk.saveConfig(cfgRoot);
      else localStorage.setItem('soda_kiosk_config', JSON.stringify(cfgRoot));
    } catch (e) {}
  }

  /* ---------------------------------------------------------------- filters */
  class OneEuro {
    constructor(minCutoff, beta, dCutoff) {
      this.minCutoff = minCutoff; this.beta = beta; this.dCutoff = dCutoff || 1.0;
      this.x = null; this.dx = 0; this.t = 0;
    }
    alpha(cutoff, dt) {
      const tau = 1 / (2 * Math.PI * Math.max(0.0001, cutoff));
      return 1 / (1 + tau / Math.max(0.0009, dt));
    }
    reset(v, t) { this.x = v; this.dx = 0; this.t = Number.isFinite(t) ? t : nowMs(); return v; }
    filter(v, t) {
      if (this.x === null) return this.reset(v);
      const dt = Math.max(0.001, (t - this.t) / 1000);
      this.t = t;
      const dx = (v - this.x) / dt;
      const ad = this.alpha(this.dCutoff, dt);
      this.dx = lerp(this.dx, dx, ad);
      const cut = this.minCutoff + this.beta * Math.abs(this.dx);
      const a = this.alpha(cut, dt);
      this.x = lerp(this.x, v, a);
      return this.x;
    }
    setOpts(minCutoff, beta) { this.minCutoff = minCutoff; this.beta = beta; }
  }

  /* ------------------------------------------------------------------ sound */
  const Sound = (function () {
    let ctx = null;
    const STYLES = {
      glass: { wave: 'sine', gain: 0.85, sparkle: true },
      soft: { wave: 'sine', gain: 0.75, sparkle: false },
      synth: { wave: 'triangle', gain: 0.75, sparkle: true },
      retro: { wave: 'square', gain: 0.32, sparkle: false }
    };
    const N = (f, t, d, o) => Object.assign({ f: f, t: t, d: d }, o || {});
    const DEFS = {
      appear: [N(740, 0, .12), N(1108, .05, .18), N(1480, .12, .22, { v: .55 }), N(0, 0, .20, { noise: 1, v: .18 })],
      lock: [N(523, 0, .08), N(784, .05, .16), N(1046, .13, .22, { v: .65 })],
      click: [N(1318, 0, .05), N(1760, .02, .10), N(0, 0, .045, { noise: 1, v: .38, hp: 1600 })],
      release: [N(740, 0, .12, { to: 392, v: .7 }), N(0, .02, .10, { noise: 1, v: .12 })],
      error: [N(180, 0, .16, { wave: 'sawtooth', v: .45 }), N(138, .14, .28, { wave: 'sawtooth', v: .38 })],
      calibrate: [N(523, 0, .09), N(659, .08, .09), N(784, .16, .09), N(1046, .24, .22)],
      tick: [N(1400, 0, .025, { v: .25 })]
    };
    function ensure() {
      if (!ctx) { const C = window.AudioContext || window.webkitAudioContext; if (!C) return null; ctx = new C(); }
      if (ctx.state === 'suspended') ctx.resume().catch(() => {});
      return ctx;
    }
    function play(name, force) {
      const c = AIR.sound;
      if (!force && (!c.enabled || !c.events[name])) return;
      const a = ensure(); if (!a) return;
      const st = STYLES[c.style] || STYLES.glass;
      const master = (Math.max(0, Math.min(100, c.volume)) / 100) * .24 * st.gain;
      const t0 = a.currentTime + .012;
      (DEFS[name] || []).forEach(n => {
        const out = a.createGain(); out.connect(a.destination);
        const peak = master * (n.v || 1);
        out.gain.setValueAtTime(.0001, t0 + n.t);
        out.gain.exponentialRampToValueAtTime(Math.max(.0002, peak), t0 + n.t + .012);
        out.gain.exponentialRampToValueAtTime(.0001, t0 + n.t + n.d);
        let src;
        if (n.noise) {
          const len = Math.max(1, Math.floor(a.sampleRate * n.d));
          const buf = a.createBuffer(1, len, a.sampleRate), d = buf.getChannelData(0);
          for (let i = 0; i < len; i++) d[i] = (Math.random() * 2 - 1) * (1 - i / len);
          src = a.createBufferSource(); src.buffer = buf;
          const filt = a.createBiquadFilter(); filt.type = 'bandpass'; filt.frequency.value = n.hp || 1100; filt.Q.value = 1.2;
          src.connect(filt); filt.connect(out);
        } else {
          src = a.createOscillator(); src.type = n.wave || st.wave;
          src.frequency.setValueAtTime(n.f, t0 + n.t);
          if (n.to) src.frequency.exponentialRampToValueAtTime(n.to, t0 + n.t + n.d);
          src.connect(out);
        }
        src.start(t0 + n.t); src.stop(t0 + n.t + n.d + .04);
      });
    }
    return { play: play, ensure: ensure, test: name => play(name, true) };
  })();

  /* ------------------------------------------------------------------ state */
  const S = {
    ready: false, running: false, stream: null, video: null,
    engine: 'none', engineState: 'idle', engineError: '', modelLoading: false,
    source: 'camera', demo: false, demoAuto: false, demoT: 0,
    landmarker: null, lastInfer: 0, lastContour: 0, inferCount: 0, detectFps: 0,
    landmarks: null, handedness: '', handScore: 0, handSeen: false, lastSeen: 0,
    metrics: { ti: 9, tm: 9, im: 9, ring: 9, pinky: 9, palm: .2 },
    active: false, visible: false, coasting: false, poseFrames: 0, releaseFrames: 0,
    activatedAt: 0, indexUp: false, liftAt: 0, tapBase: 0, tapPeak: 0, lastClick: 0, clickCount: 0, lastTargetScan: 0,
    contourActive: false, contour: { x: .5, y: .5, area: 0, peaks: 0, solidity: 0, seen: 0 },
    raw: { x: .5, y: .5 }, point: { x: 50, y: 50 }, relOrigin: null,
    fx: new OneEuro(1.6, .025, 1), fy: new OneEuro(1.6, .025, 1),
    lite: false, lastPointAt: 0, hideAt: 0,
    targetEl: null, targetInfo: null, targetSince: 0, targetLostAt: 0,
    locked: false, lockAt: 0, dwellDone: false, lastDwellTick: 0,
    status: 'off', statusText: 'AIR OFF',
    previews: new Set(), debugCanvas: null, settingsRoot: null,
    deviceList: [], lastDevices: 0
  };

  const $ = (sel, root) => (root || document).querySelector(sel);
  const rootEl = () => document.getElementById('agRoot');

  /* --------------------------------------------------------------- UI mount */
  function mountUI() {
    if (document.getElementById('agRoot')) return;
    const root = document.createElement('div');
    root.id = 'agRoot';
    root.setAttribute('aria-hidden', 'true');
    root.innerHTML =
      '<canvas id="agTrail"></canvas>' +
      '<div id="agPointer">' +
        '<div class="agAura"></div><div class="agOrbit"></div><div class="agGlass"></div>' +
        '<div class="agCore"></div><div class="agPulse"></div><div class="agRipple"></div>' +
        '<div class="agGlyph"><i></i><i></i><i></i></div><div class="agLabel"></div>' +
      '</div>' +
      '<div id="agMorph" aria-hidden="true">' +
        '<div class="agMorphClone"></div><div class="agMorphOutline"></div>' +
        '<div class="agMorphTag"></div><div class="agMorphBar"><i></i></div>' +
        '<div class="agMorphValue"></div><div class="agMorphBadge"></div>' +
      '</div>' +
      '<div id="agDebug" aria-hidden="true">' +
        '<div class="agDbgHead"><span>AIR VISION</span><span id="agDbgState">OFF</span></div>' +
        '<canvas id="agDbgCanvas" width="320" height="240"></canvas>' +
        '<div class="agDbgGrid" id="agDbgGrid"></div>' +
      '</div>';
    (document.getElementById('frame') || document.body).appendChild(root);
    const v = document.createElement('video');
    v.id = 'agVideo'; v.muted = true; v.playsInline = true; v.autoplay = true;
    v.setAttribute('playsinline', ''); v.setAttribute('aria-hidden', 'true');
    v.style.cssText = 'position:absolute;width:1px;height:1px;opacity:0;pointer-events:none;left:-9px;top:-9px';
    root.appendChild(v);
    S.video = v;
    S.debugCanvas = $('#agDbgCanvas');
    const trail = $('#agTrail');
    if (trail) { S.trail = trail; S.tctx = trail.getContext('2d'); }
    const hud = document.getElementById('hudRight');
    if (hud && !document.getElementById('agPill')) {
      const pill = document.createElement('div');
      pill.id = 'agPill'; pill.dataset.s = 'off';
      pill.innerHTML = '<i></i><span>AIR</span>';
      pill.title = 'Air gesture status';
      hud.insertBefore(pill, hud.firstChild);
    }
    applyLook();
    sizeCanvas();
    window.addEventListener('resize', sizeCanvas, { passive: true });
  }

  function sizeCanvas() {
    const c = S.trail; if (!c) return;
    const w = Math.max(1, innerWidth), h = Math.max(1, innerHeight);
    const maxPx = S.lite ? 1_100_000 : 3_200_000;
    let scale = Math.min(2, window.devicePixelRatio || 1);
    if (w * h * scale * scale > maxPx) scale = Math.sqrt(maxPx / (w * h));
    c.width = Math.max(1, Math.round(w * scale));
    c.height = Math.max(1, Math.round(h * scale));
    if (S.tctx) S.tctx.setTransform(scale, 0, 0, scale, 0, 0);
  }

  function resolveLite() {
    const q = AIR.pointer.quality || 'auto';
    if (q === 'lite') return true;
    if (q === 'full') return false;
    return IS_MOBILE;
  }

  function syncCursor() {
    // The pointer root is pointer-events:none, so a cursor rule on it cannot
    // reach the actual page. Put the class on <html> instead, and only hide the
    // normal cursor while the air pointer is actually running so a camera
    // failure never leaves the kiosk without a mouse.
    const hide = !!AIR.pointer.hideSystemCursor && (S.running || S.demo);
    document.documentElement.classList.toggle('ag-hide-cursor', hide);
  }

  function applyLook() {
    const root = rootEl(); if (!root) return;
    const p = AIR.pointer, tr = AIR.tracker;
    root.style.setProperty('--ag-size', Math.max(18, p.size) + 'px');
    root.style.setProperty('--ag-core', Math.max(4, p.core) + 'px');
    root.style.setProperty('--ag-primary', p.primary);
    root.style.setProperty('--ag-secondary', p.secondary);
    root.style.setProperty('--ag-accent', p.accent);
    root.style.setProperty('--ag-glass', String(p.glass));
    root.style.setProperty('--ag-blur', Math.max(0, p.blur) + 'px');
    root.style.setProperty('--ag-border', Math.max(0, p.border) + 'px');
    root.style.setProperty('--ag-glow', String(Math.max(0, p.glow)));
    root.style.setProperty('--ag-hue', Math.max(-180, Math.min(180, p.hueShift)) + 'deg');
    root.style.setProperty('--ag-spin', Math.max(2, 30 - p.spin) + 's');
    root.style.setProperty('--ag-morph-content', String(Math.max(0, Math.min(1, p.morphOpacity))));
    root.style.setProperty('--ag-morph-dur', Math.max(80, Math.min(900, num(p.morphExpandMs, 220))) + 'ms');
    const style = POINTER_STYLES.some(s => s[0] === p.style) ? p.style : 'orb';
    if (p.style !== style) p.style = style;
    root.dataset.pointer = style;
    S.lite = resolveLite();
    root.classList.toggle('ag-lite', S.lite);
    root.classList.toggle('ag-pointer-morph', !!(S.locked && p.pointerMorph && p.morphMode !== 'none'));
    root.classList.toggle('ag-high-contrast', !!p.highContrast);
    root.classList.toggle('ag-reduced', !!p.reducedMotion);
    syncCursor();
    S.fx.setOpts(tr.smoothMinCutoff, tr.smoothBeta);
    S.fy.setOpts(tr.smoothMinCutoff, tr.smoothBeta);
    const pill = document.getElementById('agPill');
    if (pill) pill.style.display = AIR.statusPill ? '' : 'none';
    const dbg = document.getElementById('agDebug');
    if (dbg) dbg.classList.toggle('on', !!AIR.debug.showOverlay);
    const morph = document.getElementById('agMorph');
    if (morph) morph.style.setProperty('--ag-morph-pad', Math.max(0, p.morphPad) + 'px');
  }

  function setStatus(s, text) {
    S.status = s; S.statusText = text || s.toUpperCase();
    syncCursor();
    const pill = document.getElementById('agPill');
    if (pill) {
      pill.dataset.s = s;
      const sp = pill.querySelector('span');
      if (sp) sp.textContent = text || 'AIR';
      pill.title = 'Air gesture · ' + (text || s);
    }
    const dbg = document.getElementById('agDbgState');
    if (dbg) dbg.textContent = (text || s).replace(/^AIR\s*·?\s*/i, '');
    const set = document.getElementById('agSetStatus');
    if (set) set.textContent = text || s;
    if (AIR.debug.logToConsole) {
      try { console.log('[airgesture]', s, text || ''); } catch (e) {}
    }
  }

  function statusFromState() {
    if (!AIR.enabled) return setStatus('off', 'AIR OFF');
    if (S.demo) return setStatus('demo', 'AIR DEMO');
    if (S.engineState === 'error') return setStatus('error', 'AIR ERROR');
    if (!S.running) return setStatus('off', 'AIR OFF');
    if (S.engineState === 'loading') return setStatus('starting', 'AIR LOADING');
    if (S.active) return setStatus('active', 'AIR LIVE');
    if (S.handSeen || nowMs() - S.lastSeen < 600) return setStatus('tracking', 'AIR TRACK');
    return setStatus('ready', 'AIR READY');
  }

  /* ----------------------------------------------------------------- camera */
  function withTimeout(p, ms) {
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => reject(new Error('Timed out after ' + Math.round(ms / 1000) + 's')), ms);
      p.then(v => { clearTimeout(t); resolve(v); }, e => { clearTimeout(t); reject(e); });
    });
  }

  async function localAssetExists(path) {
    try {
      const r = await fetch(path, { method: 'HEAD', cache: 'no-store' });
      return r.ok;
    } catch (e) { return false; }
  }

  async function assetCandidates() {
    const mode = AIR.vision.assets;
    const remotes = [{ base: MP_CDN, local: false }, { base: MP_UNPKG, local: false }];
    if (mode === 'cdn') return remotes;
    if (mode === 'local') return [{ base: LOCAL_BASE, local: true }];
    const local = [{ base: LOCAL_BASE, local: true }];
    if (await localAssetExists(LOCAL_BASE + '/vision_bundle.mjs')) return local.concat(remotes);
    return remotes;
  }

  async function loadLandmarker() {
    if (S.modelLoading) return;
    if (AIR.vision.engine === 'contour') {
      S.engine = 'contour'; S.engineState = 'ready'; statusFromState(); return;
    }
    S.modelLoading = true; S.engineState = 'loading'; statusFromState();
    try {
      const candidates = await assetCandidates();
      let lm = null, lastError = null;
      for (const a of candidates) {
        try {
          const mod = await withTimeout(import(a.base + '/vision_bundle.mjs'), 25000);
          const vision = await withTimeout(mod.FilesetResolver.forVisionTasks(a.base + '/wasm'), 25000);
          let model = MP_MODEL;
          if (a.local && await localAssetExists(LOCAL_BASE + '/hand_landmarker.task')) model = LOCAL_BASE + '/hand_landmarker.task';
          const opts = {
            baseOptions: { modelAssetPath: model, delegate: AIR.vision.delegate === 'CPU' ? 'CPU' : 'GPU' },
            runningMode: 'VIDEO',
            numHands: Math.max(1, Math.min(2, +AIR.vision.maxHands || 1)),
            minHandDetectionConfidence: num(AIR.vision.minHandConfidence, .45),
            minHandPresenceConfidence: num(AIR.vision.minPresenceConfidence, .45),
            minTrackingConfidence: num(AIR.vision.minTrackingConfidence, .40)
          };
          try { lm = await withTimeout(mod.HandLandmarker.createFromOptions(vision, opts), 30000); }
          catch (e) {
            opts.baseOptions.delegate = 'CPU';
            lm = await withTimeout(mod.HandLandmarker.createFromOptions(vision, opts), 30000);
          }
          break;
        } catch (e) {
          lastError = e;
          if (AIR.debug.logToConsole) { try { console.warn('[airgesture] asset source failed, trying next:', a.base, e); } catch (_) {} }
        }
      }
      if (!lm) throw lastError || new Error('No MediaPipe asset source available');
      S.landmarker = lm; S.engine = 'landmarker'; S.engineState = 'ready'; S.engineError = '';
      statusFromState();
    } catch (e) {
      S.engineError = String(e && e.message ? e.message : e);
      S.engineState = 'error';
      if (AIR.vision.contourFallback) { S.engine = 'contour'; S.engineState = 'ready'; }
      statusFromState();
      if (AIR.debug.logToConsole) { try { console.warn('[airgesture] MediaPipe unavailable, contour fallback:', e); } catch (_) {} }
    } finally {
      S.modelLoading = false;
    }
  }

  async function refreshDevices(force) {
    if (!navigator.mediaDevices || !navigator.mediaDevices.enumerateDevices) return [];
    if (!force && nowMs() - S.lastDevices < 1200) return S.deviceList;
    try {
      const all = await navigator.mediaDevices.enumerateDevices();
      S.deviceList = all.filter(d => d.kind === 'videoinput');
      S.lastDevices = nowMs();
      const sel = document.getElementById('agCamSelect');
      if (sel) {
        const cur = sel.value || AIR.vision.deviceId || '';
        sel.replaceChildren();
        const auto = document.createElement('option'); auto.value = ''; auto.textContent = 'Default camera'; sel.appendChild(auto);
        S.deviceList.forEach((d, i) => {
          const o = document.createElement('option'); o.value = d.deviceId;
          o.textContent = d.label || ('Camera ' + (i + 1)); sel.appendChild(o);
        });
        sel.value = S.deviceList.some(d => d.deviceId === cur) ? cur : '';
      }
    } catch (e) {}
    return S.deviceList;
  }

  async function startCamera() {
    if (S.demo) stopDemo();
    if (!AIR.enabled) { setStatus('off', 'AIR OFF'); return false; }
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      S.engineState = 'error'; S.engineError = 'Camera API unavailable. Open the kiosk on localhost or HTTPS.';
      setStatus('error', 'AIR NO CAMERA'); return false;
    }
    stopCamera(true);
    S.running = true; S.engineState = S.landmarker ? 'ready' : 'loading'; S.engine = S.landmarker ? 'landmarker' : 'none';
    setStatus('starting', 'AIR STARTING');
    const [w, h] = String(AIR.vision.resolution || '640x480').split('x').map(n => Math.max(80, parseInt(n, 10) || 640));
    const base = { width: { ideal: w }, height: { ideal: h }, frameRate: { ideal: Math.max(1, +AIR.vision.fps || 24), max: 60 } };
    if (AIR.vision.deviceId) base.deviceId = { exact: AIR.vision.deviceId };
    let stream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ video: base, audio: false });
    } catch (e) {
      if (AIR.vision.deviceId) {
        try { stream = await navigator.mediaDevices.getUserMedia({ video: { width: base.width, height: base.height, frameRate: base.frameRate }, audio: false }); } catch (e2) { e = e2; }
      }
      if (!stream) {
        S.running = false; S.engineState = 'error';
        S.engineError = e && e.name === 'NotAllowedError' ? 'Camera permission denied. Allow the camera in the address bar, then press Start.' : (e && e.message ? e.message : String(e));
        setStatus('error', 'AIR ' + (e && e.name === 'NotAllowedError' ? 'BLOCKED' : 'CAM ERROR'));
        updateSettingsStatus();
        return false;
      }
    }
    S.stream = stream;
    const v = S.video || document.getElementById('agVideo');
    if (!v) { S.running = false; return false; }
    S.video = v; v.srcObject = stream;
    try { await v.play(); } catch (e) {}
    S.running = true; S.engineState = S.landmarker ? 'ready' : 'loading';
    setStatus('starting', 'AIR STARTING');
    await refreshDevices(true);
    if (AIR.vision.engine === 'contour') { S.engine = 'contour'; S.engineState = 'ready'; }
    else if (!S.landmarker) loadLandmarker();
    applyLook();
    updateSettingsStatus();
    return true;
  }

  function stopCamera(silent) {
    if (S.stream) { try { S.stream.getTracks().forEach(t => t.stop()); } catch (e) {} }
    S.stream = null;
    if (S.video) { try { S.video.srcObject = null; } catch (e) {} }
    S.running = false; S.handSeen = false; S.landmarks = null;
    if (!silent) {
      release('off');
      S.engineState = 'idle';
      setStatus('off', 'AIR OFF');
      updateSettingsStatus();
    }
  }

  function startDemo(auto) {
    stopCamera(true);
    S.demo = true; S.demoAuto = !!auto; S.demoT = nowMs(); S.running = true;
    S.engine = 'demo'; S.engineState = 'ready'; S.active = true; S.visible = true;
    S.activatedAt = nowMs(); S.lastSeen = nowMs(); S.wasActive = false;
    S.raw.x = .5; S.raw.y = .5;
    S.point.x = innerWidth * .5; S.point.y = innerHeight * .5;
    setStatus('demo', 'AIR DEMO');
    applyLook(); updateSettingsStatus();
    setTimeout(() => { rootEl() && rootEl().classList.add('ag-on'); }, 20);
  }

  function stopDemo() {
    if (!S.demo) return;
    S.demo = false; S.demoAuto = false; S.running = false; S.engine = 'none'; S.engineState = 'idle';
    release('off'); S.visible = false;
    const root = rootEl(); if (root) root.classList.remove('ag-on');
    setStatus('off', 'AIR OFF'); updateSettingsStatus();
  }

  /* ------------------------------------------------------------- demo input */
  function demoMove(e) {
    if (!S.demo || S.demoAuto) return;
    S.point.x = e.clientX; S.point.y = e.clientY;
    S.visible = true; S.active = true;
    const root = rootEl(); if (root) root.classList.add('ag-on');
    setStatus('demo', 'AIR DEMO');
  }
  function demoDown(e) {
    if (!S.demo) return;
    demoMove(e);
    if (S.locked) doClick('demo');
  }
  window.addEventListener('pointermove', demoMove, { passive: true });
  window.addEventListener('pointerdown', () => { Sound.ensure(); }, { once: true, passive: true });
  window.addEventListener('pointermove', () => { Sound.ensure(); }, { once: true, passive: true });
  window.addEventListener('pointerdown', demoDown, { passive: true });

  /* -------------------------------------------------------------- landmarks */
  const HAND_CONNECTIONS = [
    [0,1],[1,2],[2,3],[3,4], [0,5],[5,6],[6,7],[7,8], [5,9],[9,10],[10,11],[11,12],
    [9,13],[13,14],[14,15],[15,16], [13,17],[17,18],[18,19],[19,20], [0,17]
  ];

  function aspect() {
    const v = S.video;
    return v && v.videoWidth && v.videoHeight ? v.videoWidth / v.videoHeight : 4 / 3;
  }
  function d2(a, b) {
    const ar = aspect();
    const dx = (a.x - b.x) * ar, dy = a.y - b.y;
    return Math.sqrt(dx * dx + dy * dy);
  }

  function metricsFromLandmarks(lm) {
    const palm = Math.max(0.02, d2(lm[0], lm[9]));
    const m = {
      palm: palm,
      ti: d2(lm[4], lm[8]) / palm,
      tm: d2(lm[4], lm[12]) / palm,
      im: d2(lm[8], lm[12]) / palm,
      ring: d2(lm[16], lm[13]) / palm,
      pinky: d2(lm[20], lm[17]) / palm
    };
    Object.keys(m).forEach(k => { if (!Number.isFinite(m[k])) m[k] = 9; });
    return m;
  }

  function trackPoint(lm, mode) {
    if (mode === 'index') return { x: lm[8].x, y: lm[8].y };
    if (mode === 'middle') return { x: lm[12].x, y: lm[12].y };
    if (mode === 'pinch') return { x: (lm[4].x + lm[8].x) / 2, y: (lm[4].y + lm[8].y) / 2 };
    const ids = [0, 5, 9, 13, 17];
    let x = 0, y = 0;
    ids.forEach(i => { x += lm[i].x; y += lm[i].y; });
    return { x: x / ids.length, y: y / ids.length };
  }

  function ingestLandmarks(lm, handed, score, ts) {
    if (!lm || lm.length < 21) { onHandLost(ts); return; }
    if (AIR.gesture.handedness !== 'any' && handed && handed !== AIR.gesture.handedness) { onHandLost(ts); return; }
    if (score != null && score < num(AIR.gesture.confidenceMin, .3) && S.active) { onHandLost(ts); return; }
    S.landmarks = lm; S.handedness = handed || ''; S.handScore = score || 0; S.handSeen = true; S.lastSeen = ts;
    S.metrics = metricsFromLandmarks(lm);
    updateGesture(ts);
    const p = trackPoint(lm, AIR.tracker.point);
    if (Number.isFinite(p.x) && Number.isFinite(p.y)) { S.raw.x = p.x; S.raw.y = p.y; }
    if (S.active && S.visible) S.coasting = false;
  }

  function onHandLost(ts) {
    S.handSeen = false;
    const lostFor = ts - S.lastSeen;
    if (S.active && S.lastSeen && lostFor > num(AIR.tracker.lostHoldMs, 420)) release('lost');
    if (S.active && lostFor < num(AIR.tracker.lostHoldMs, 420)) S.coasting = true;
    if (!S.active) S.coasting = false;
  }

  function enterPose(m) {
    const g = AIR.gesture;
    const fold = !g.requireFolded || (m.ring <= g.ringFoldMax && m.pinky <= g.pinkyFoldMax);
    return m.ti <= g.pinchEnter && m.tm <= g.pinchEnter && fold;
  }
  function holdPose(m) {
    return m.tm <= AIR.gesture.pinchExit;
  }

  function updateGesture(ts) {
    const g = AIR.gesture, m = S.metrics;
    if (!S.active) {
      S.poseFrames = enterPose(m) ? S.poseFrames + 1 : 0;
      if (S.poseFrames >= Math.max(1, g.activationFrames)) activate(ts);
      return;
    }
    S.releaseFrames = holdPose(m) ? 0 : S.releaseFrames + 1;
    if (S.releaseFrames >= Math.max(1, g.releaseFrames)) { release('pose'); return; }
    if (g.clickMode === 'indexTap') {
      // A real hand often lifts the index less than the static clickUp threshold.
      // Use the pen-grip distance at activation as a baseline and accept a clear
      // relative lift, while still requiring the index to come back down.
      if (!(S.tapBase > 0)) S.tapBase = m.ti;
      const base = Number.isFinite(S.tapBase) && S.tapBase > 0 ? S.tapBase : Math.max(0, g.clickDown);
      const lift = Math.max(g.clickDown + .08, Math.min(g.clickUp, base + num(g.clickLiftDelta, .18)));
      if (!S.indexUp) {
        if (m.ti > lift) { S.indexUp = true; S.liftAt = ts; S.tapPeak = m.ti; }
      } else {
        S.tapPeak = Math.max(S.tapPeak || 0, m.ti);
        const down = m.ti < Math.min(g.clickDown, (S.tapPeak || g.clickUp) - num(g.clickDropDelta, .18));
        if (down) {
          S.indexUp = false;
          if (ts - S.liftAt <= num(g.tapWindowMs, 1000) && ts - S.activatedAt >= num(g.settleMs, 350)) doClick('tap');
          S.tapBase = m.ti; S.tapPeak = 0;
        }
      }
    }
  }

  function activate(ts) {
    if (S.active) return;
    S.active = true; S.visible = true; S.poseFrames = 0; S.releaseFrames = 0;
    S.indexUp = false; S.activatedAt = ts; S.lastSeen = ts; S.coasting = false; S.lastTargetScan = 0;
    S.tapBase = S.metrics.ti; S.tapPeak = 0;
    if (AIR.tracker.mode === 'relative') resetRelativeOrigin(ts);
    S.wasActive = false;
    const root = rootEl(); if (root) root.classList.add('ag-on');
    Sound.play('appear');
    if (AIR.reactFace && window.CodaFace && window.CodaFace.express) {
      try { window.CodaFace.express('curious', 1100); } catch (e) {}
    }
    Fx.ring(18);
    statusFromState();
    updateSettingsStatus();
  }

  function release(reason) {
    const was = S.active || S.locked;
    if (S.locked) unlockTarget(true);
    S.active = false; S.visible = false; S.poseFrames = 0; S.releaseFrames = 0;
    S.indexUp = false; S.coasting = false; S.hit = null; S.lastTargetScan = 0;
    S.tapBase = 0; S.tapPeak = 0;
    S.wasActive = false; S.relOrigin = null;
    const root = rootEl(); if (root) root.classList.remove('ag-on');
    if (was && reason !== 'off') Sound.play('release');
    statusFromState();
    updateSettingsStatus();
  }

  /* --------------------------------------------------------------- contour */
  const Contour = (function () {
    const W = 160, H = 120;
    let canvas = null, ctx = null, data = null, mask = null, labels = null, stack = null;
    function init() {
      if (canvas) return;
      canvas = document.createElement('canvas'); canvas.width = W; canvas.height = H;
      ctx = canvas.getContext('2d', { willReadFrequently: true });
      data = new Uint8ClampedArray(W * H * 4); mask = new Uint8Array(W * H);
      labels = new Int32Array(W * H); stack = new Int32Array(W * H);
    }
    function skin(r, g, b) {
      const tol = Math.max(0, Math.min(100, AIR.vision.skinTolerance));
      const y = .299 * r + .587 * g + .114 * b;
      const cb = 128 - .168736 * r - .331264 * g + .5 * b;
      const cr = 128 + .5 * r - .418688 * g - .081312 * b;
      const mx = Math.max(r, g, b), mn = Math.min(r, g, b);
      const broad = r > 55 && g > 28 && b > 12 && r > g && r > b && mx - mn > 9 && Math.abs(r - g) > 6;
      const ycc = y > 45 && cr >= 132 - tol * .16 && cr <= 176 + tol * .10 && cb >= 72 - tol * .10 && cb <= 132 + tol * .08;
      return broad && ycc;
    }
    function process(video, ts) {
      if (!video || video.readyState < 2 || !video.videoWidth) return null;
      init();
      try { ctx.drawImage(video, 0, 0, W, H); } catch (e) { return null; }
      data = ctx.getImageData(0, 0, W, H).data;
      mask.fill(0);
      for (let i = 0, p = 0; i < W * H; i++, p += 4) {
        if (skin(data[p], data[p + 1], data[p + 2])) mask[i] = 1;
      }
      labels.fill(0);
      let best = null, bestArea = 0, bestPixels = null, next = 1;
      for (let start = 0; start < W * H; start++) {
        if (!mask[start] || labels[start]) continue;
        let sp = 0, area = 0, minX = W, maxX = 0, minY = H, maxY = 0, sx = 0, sy = 0;
        const pixels = [];
        stack[sp++] = start; labels[start] = next;
        while (sp) {
          const idx = stack[--sp];
          const x = idx % W, y = (idx - x) / W;
          area++; sx += x; sy += y; pixels.push(idx);
          if (x < minX) minX = x; if (x > maxX) maxX = x;
          if (y < minY) minY = y; if (y > maxY) maxY = y;
          if (x > 0 && mask[idx - 1] && !labels[idx - 1]) { labels[idx - 1] = next; stack[sp++] = idx - 1; }
          if (x < W - 1 && mask[idx + 1] && !labels[idx + 1]) { labels[idx + 1] = next; stack[sp++] = idx + 1; }
          if (y > 0 && mask[idx - W] && !labels[idx - W]) { labels[idx - W] = next; stack[sp++] = idx - W; }
          if (y < H - 1 && mask[idx + W] && !labels[idx + W]) { labels[idx + W] = next; stack[sp++] = idx + W; }
        }
        next++;
        if (area > bestArea) { bestArea = area; best = { area, minX, maxX, minY, maxY, cx: sx / area, cy: sy / area }; bestPixels = pixels; }
      }
      const minArea = W * H * num(AIR.vision.skinMinArea, .006);
      if (!best || bestArea < minArea) {
        S.contour = { x: .5, y: .5, area: 0, peaks: 0, solidity: 0, seen: S.contour.seen, ts: ts };
        return S.contour;
      }
      const bw = best.maxX - best.minX + 1, bh = best.maxY - best.minY + 1;
      const solidity = best.area / Math.max(1, bw * bh);
      const bins = 72, prof = new Float32Array(bins);
      for (let i = 0; i < bestPixels.length; i++) {
        const idx = bestPixels[i], x = idx % W, y = (idx - x) / W;
        const boundary = (x === 0 || !mask[idx - 1]) || (x === W - 1 || !mask[idx + 1]) || (y === 0 || !mask[idx - W]) || (y === H - 1 || !mask[idx + W]);
        if (!boundary) continue;
        const ang = Math.atan2(y - best.cy, x - best.cx);
        const bin = ((Math.floor((ang + Math.PI) / (2 * Math.PI) * bins) % bins) + bins) % bins;
        const rad = Math.hypot(x - best.cx, y - best.cy);
        if (rad > prof[bin]) prof[bin] = rad;
      }
      for (let pass = 0; pass < 2; pass++) {
        const cp = Float32Array.from(prof);
        for (let i = 0; i < bins; i++) prof[i] = (cp[(i - 1 + bins) % bins] + cp[i] * 2 + cp[(i + 1) % bins]) / 4;
      }
      let maxR = 0, sum = 0, n = 0;
      for (let i = 0; i < bins; i++) { maxR = Math.max(maxR, prof[i]); if (prof[i] > 0) { sum += prof[i]; n++; } }
      const mean = n ? sum / n : 0;
      let peaks = 0;
      for (let i = 0; i < bins; i++) {
        const v = prof[i];
        if (v < mean * 1.16 || v < maxR * .24) continue;
        if (v >= prof[(i - 1 + bins) % bins] && v >= prof[(i + 1) % bins]) peaks++;
      }
      S.contour = {
        x: best.cx / W, y: best.cy / H, area: best.area / (W * H), peaks: peaks,
        solidity: solidity, seen: ts, box: [best.minX / W, best.minY / H, best.maxX / W, best.maxY / H]
      };
      return S.contour;
    }
    return { process: process, get canvas() { return canvas; } };
  })();

  /* -------------------------------------------------------------- inference */
  function tickVision(ts) {
    const v = S.video;
    if (!v || v.readyState < 2) return;
    const contourDue = AIR.vision.contourFallback && ts - S.lastContour >= 1000 / Math.max(2, +AIR.vision.contourFps || 12);
    if (contourDue) { S.lastContour = ts; Contour.process(v, ts); }
    const lm = S.landmarker;
    if (lm && AIR.vision.engine !== 'contour' && ts - S.lastInfer >= 1000 / Math.max(4, +AIR.vision.fps || 24)) {
      S.lastInfer = ts;
      try {
        const res = lm.detectForVideo(v, ts);
        const hand = res && res.landmarks && res.landmarks[0];
        const h = (res && (res.handednesses || res.handedness) || [])[0];
        const cat = h && (h[0] || h);
        const handed = cat && cat.categoryName ? cat.categoryName : '';
        const score = cat && cat.score != null ? cat.score : 1;
        S.inferCount++;
        S.detectFps = S.detectFps ? S.detectFps * .9 + 10 : 10;
        if (hand) ingestLandmarks(hand, handed, score, ts);
        else onHandLost(ts);
      } catch (e) {
        if (AIR.debug.logToConsole) { try { console.warn('[airgesture] detect error', e); } catch (_) {} }
      }
    }
    const contourFresh = ts - S.contour.seen < 500;
    if (!S.handSeen && contourFresh && S.contour.area > 0) {
      S.raw.x = S.contour.x; S.raw.y = S.contour.y;
      if (S.active) S.coasting = ts - S.contour.seen > 90;
    }
    // Pure contour mode (or MediaPipe failed): compact hand shape = gesture.
    if (S.engine === 'contour' && S.engineState === 'ready') {
      const c = S.contour;
      const ok = contourFresh && c.peaks <= num(AIR.vision.contourMaxPeaks, 3) && c.solidity >= num(AIR.vision.contourMinSolidity, .30) && c.area >= num(AIR.vision.skinMinArea, .006);
      if (!S.active) {
        S.poseFrames = ok ? S.poseFrames + 1 : 0;
        if (S.poseFrames >= Math.max(1, +AIR.vision.contourActivateFrames || 3) && ok) activate(ts);
      } else {
        S.releaseFrames = ok ? 0 : S.releaseFrames + 1;
        if (S.releaseFrames >= Math.max(1, +AIR.vision.contourReleaseFrames || 6)) release('contour');
      }
      if (contourFresh) { S.handSeen = true; S.lastSeen = Math.max(S.lastSeen, c.seen); }
    }
    if (ts - (S.lastStatus || 0) > 260) { S.lastStatus = ts; statusFromState(); }
  }

  /* --------------------------------------------------------------- tracking */
  function normPoint(raw) {
    const tr = AIR.tracker;
    let x = AIR.vision.mirror ? 1 - raw.x : raw.x;
    let y = raw.y;
    if (tr.invertX) x = 1 - x;
    if (tr.invertY) y = 1 - y;
    return { x: x, y: y };
  }

  function mapPoint(raw) {
    const tr = AIR.tracker;
    const p = normPoint(raw);
    const bw = Math.max(.05, tr.boxRight - tr.boxLeft), bh = Math.max(.05, tr.boxBottom - tr.boxTop);
    let bx = (p.x - tr.boxLeft) / bw, by = (p.y - tr.boxTop) / bh;
    bx = (bx - .5) * num(tr.sensX, 1) + .5;
    by = (by - .5) * num(tr.sensY, 1) + .5;
    const lo = tr.edgeClamp ? 0 : -.12, hi = tr.edgeClamp ? 1 : 1.12;
    bx = clamp(bx, lo, hi); by = clamp(by, lo, hi);
    return { x: bx * innerWidth, y: by * innerHeight };
  }

  function mapRelative(raw) {
    const tr = AIR.tracker;
    const p = normPoint(raw);
    const o = S.relOrigin || p;
    const gain = num(tr.relativeGain, 2.2);
    let x = innerWidth * .5 + (p.x - o.x) * innerWidth * gain * num(tr.sensX, 1);
    let y = innerHeight * .5 + (p.y - o.y) * innerHeight * gain * num(tr.sensY, 1);
    const lo = tr.edgeClamp ? 0 : -.12, hi = tr.edgeClamp ? 1 : 1.12;
    x = clamp(x, innerWidth * lo, innerWidth * hi);
    y = clamp(y, innerHeight * lo, innerHeight * hi);
    return { x: x, y: y };
  }

  function resetRelativeOrigin(ts) {
    S.relOrigin = normPoint(S.raw);
    S.point.x = innerWidth * .5;
    S.point.y = innerHeight * .5;
    S.fx.reset(S.point.x, ts); S.fy.reset(S.point.y, ts);
    S.point.vx = 0;
  }

  function tickPointer(ts) {
    const root = rootEl(); if (!root) return;
    if (S.demo) {
      if (S.demoAuto) {
        const t = (ts - S.demoT) / 1000;
        S.point.x = innerWidth * (.5 + .34 * Math.sin(t * .53));
        S.point.y = innerHeight * (.5 + .24 * Math.sin(t * .81 + 1.1));
        S.point.vx = Math.cos(t * .53) * innerWidth * .34 * .53;
      }
      S.active = true; S.visible = true;
      root.classList.add('ag-on');
      applyPointVars(ts);
      return;
    }
    if (!S.active) {
      if (!S.locked) root.classList.remove('ag-on');
      return;
    }
    const relative = AIR.tracker.mode === 'relative';
    if (relative && !S.relOrigin) resetRelativeOrigin(ts);
    const mapped = relative ? mapRelative(S.raw) : mapPoint(S.raw);
    const wasActive = S.wasActive;
    if (!wasActive) {
      const sx = relative ? innerWidth * .5 : mapped.x;
      const sy = relative ? innerHeight * .5 : mapped.y;
      S.point.x = sx; S.point.y = sy;
      S.fx.reset(sx, ts); S.fy.reset(sy, ts);
      S.point.vx = 0;
    } else {
      const tr = AIR.tracker;
      const fx = S.fx.filter(mapped.x, ts), fy = S.fy.filter(mapped.y, ts);
      const px = fx + S.fx.dx * (num(tr.predictionMs, 0) / 1000);
      const py = fy + S.fy.dx * (num(tr.predictionMs, 0) / 1000);
      const nx = clamp(px, -20, innerWidth + 20), ny = clamp(py, -20, innerHeight + 20);
      const dz = num(tr.deadzone, 0);
      if (Math.abs(nx - S.point.x) >= dz || Math.abs(ny - S.point.y) >= dz) {
        S.point.vx = nx - S.point.x;
        S.point.x = nx; S.point.y = ny;
      } else {
        S.point.vx *= .8;
      }
    }
    S.wasActive = true;
    S.visible = true;
    root.classList.add('ag-on');
    root.classList.toggle('ag-coasting', !!S.coasting);
    applyPointVars(ts);
  }

  function applyPointVars(ts) {
    const root = rootEl(); if (!root) return;
    const p = AIR.pointer;
    const rot = clamp((S.point.vx || 0) * .55, -14, 14) + (p.idleFloat ? Math.sin(ts / 900) * 1.8 : 0);
    root.style.setProperty('--ag-x', S.point.x.toFixed(1) + 'px');
    root.style.setProperty('--ag-y', S.point.y.toFixed(1) + 'px');
    root.style.setProperty('--ag-rot', (S.locked ? 0 : rot).toFixed(2) + 'deg');
    root.style.setProperty('--ag-scale', String(S.locked ? clamp(p.lockScale, .1, 1) : 1));
    Fx.trail(S.point.x, S.point.y, ts);
  }

  function demoTick(ts) {
    S.active = true; S.visible = true;
    if (S.demoAuto) {
      if (S.locked && ts - S.lastClick > 2400) doClick('demo-auto');
    }
  }

  /* ------------------------------------------------------------------- loop */
  let loopStarted = false;
  function loop(ts) {
    requestAnimationFrame(loop);
    if (document.hidden && AIR.vision.pauseWhenHidden) return;
    if (S.demo) {
      demoTick(ts);
      tickPointer(ts);
      updateTarget(ts);
      Fx.tick(ts);
      maybePreview(ts);
      return;
    }
    if (!S.running) { Fx.tick(ts); maybePreview(ts); return; }
    tickVision(ts);
    tickPointer(ts);
    updateTarget(ts);
    Fx.tick(ts);
    maybePreview(ts);
  }
  function ensureLoop() { if (!loopStarted) { loopStarted = true; requestAnimationFrame(loop); } }

  /* --------------------------------------------------------------------- FX */
  const Fx = (function () {
    const trailPts = [], parts = [], rings = [];
    let lastTrail = 0, lastSpark = 0, lastTick = 0, dirty = false;
    function trail(x, y, ts) {
      if (!S.tctx) return;
      const life = Math.max(0, Math.min(100, num(AIR.pointer.trail, 55)));
      if (life <= 0) return;
      if (ts - lastTrail < (S.lite ? 24 : 11)) return;
      lastTrail = ts;
      trailPts.push({ x: x, y: y, t: ts, hue: (ts * .03) % 360 });
      const max = S.lite ? 34 : 22 + life * 1.1;
      while (trailPts.length > max) trailPts.shift();
      if (AIR.pointer.particles && ts - lastSpark > (S.lite ? 280 : 150)) {
        lastSpark = ts;
        parts.push({ x: x + (Math.random() - .5) * 16, y: y + (Math.random() - .5) * 16, vx: (Math.random() - .5) * .3, vy: -.2 - Math.random() * .5, t: ts, life: 650 + Math.random() * 500, r: .8 + Math.random() * 1.6 });
        while (parts.length > (S.lite ? 36 : 90)) parts.shift();
      }
    }
    function ring(n) {
      rings.push({ t: nowMs(), r: n || 14, life: 700 });
      while (rings.length > 12) rings.shift();
    }
    function burst(n) {
      if (!AIR.pointer.particles || !S.point) return;
      const count = Math.max(0, Math.min(S.lite ? 32 : 80, n || AIR.pointer.particleCount || 18));
      for (let i = 0; i < count; i++) {
        const a = Math.random() * Math.PI * 2, sp = .7 + Math.random() * 2.8;
        parts.push({ x: S.point.x, y: S.point.y, vx: Math.cos(a) * sp, vy: Math.sin(a) * sp, t: nowMs(), life: 480 + Math.random() * 620, r: 1 + Math.random() * 2.2 });
      }
      ring(26);
    }
    function tick(ts) {
      const c = S.tctx; if (!c) return;
      if (!S.visible && !trailPts.length && !parts.length && !rings.length) {
        if (dirty) { c.clearRect(0, 0, innerWidth, innerHeight); dirty = false; }
        return;
      }
      if (ts - lastTick < (S.lite ? 34 : 16)) return;
      lastTick = ts;
      c.clearRect(0, 0, innerWidth, innerHeight);
      dirty = true;
      const life = Math.max(0, Math.min(100, num(AIR.pointer.trail, 55)));
      if (life > 0 && trailPts.length > 1 && !AIR.pointer.reducedMotion) {
        c.save(); c.globalCompositeOperation = 'lighter'; c.lineCap = 'round'; c.lineJoin = 'round';
        for (let i = 1; i < trailPts.length; i++) {
          const a = trailPts[i - 1], b = trailPts[i], age = 1 - (ts - b.t) / (700 + life * 6);
          if (age <= 0) continue;
          const k = i / trailPts.length;
          c.strokeStyle = 'rgba(126,247,212,' + (age * k * .20).toFixed(3) + ')';
          c.lineWidth = Math.max(1, life * .10) * (1 + k);
          c.beginPath(); c.moveTo(a.x, a.y); c.lineTo(b.x, b.y); c.stroke();
        }
        c.restore();
      }
      while (trailPts.length && ts - trailPts[0].t > 1300 + life * 6) trailPts.shift();
      if (parts.length) {
        c.save(); c.globalCompositeOperation = 'lighter';
        for (let i = parts.length - 1; i >= 0; i--) {
          const p = parts[i], age = clamp((ts - p.t) / p.life, 0, 1);
          if (age >= 1) { parts.splice(i, 1); continue; }
          p.x += p.vx; p.y += p.vy; p.vy += .018;
          c.fillStyle = 'rgba(255,255,255,' + ((1 - age) * .7).toFixed(3) + ')';
          c.beginPath(); c.arc(p.x, p.y, Math.max(.1, p.r * (1 - age * .55)), 0, Math.PI * 2); c.fill();
        }
        c.restore();
      }
      if (rings.length) {
        c.save(); c.globalCompositeOperation = 'lighter';
        for (let i = rings.length - 1; i >= 0; i--) {
          const r = rings[i], age = clamp((ts - r.t) / r.life, 0, 1);
          if (age >= 1) { rings.splice(i, 1); continue; }
          c.strokeStyle = 'rgba(126,247,212,' + ((1 - age) * .55).toFixed(3) + ')';
          c.lineWidth = 1.4;
          // Clock skew between an event's performance.now() and the next
          // requestAnimationFrame timestamp can make age negative. Never pass a
          // negative radius to canvas: it throws and kills the rest of the frame.
          c.beginPath(); c.arc(S.point.x, S.point.y, Math.max(.1, r.r + age * 52), 0, Math.PI * 2); c.stroke();
        }
        c.restore();
      }
    }
    return { trail: trail, tick: tick, ring: ring, burst: burst };
  })();

  /* ---------------------------------------------------------------- targets */
  const TARGET_SELECTOR = [
    'button', 'a[href]', 'input', 'select', 'textarea',
    '[role="button"]', '[role="slider"]', '[role="switch"]', '[role="checkbox"]',
    '[role="tab"]', '[role="link"]', '.tab', '[tabindex]:not([tabindex="-1"])'
  ].join(',');
  const BLOCK_SELECTOR = '.recipeCard, .panelSection, .volumeStat, .histRow, .diagItem, .issueItem, .agBlockCard, .agPlayground .agBlockCard';

  let candCache = [], candAt = 0;

  function visible(el) {
    if (!el || !el.isConnected) return false;
    const r = el.getBoundingClientRect();
    if (r.width < 5 || r.height < 5) return false;
    if (r.bottom < -10 || r.top > innerHeight + 10 || r.right < -10 || r.left > innerWidth + 10) return false;
    const cs = getComputedStyle(el);
    return cs.visibility !== 'hidden' && cs.display !== 'none' && cs.pointerEvents !== 'none' && +cs.opacity > .02;
  }

  function typeOf(el) {
    const tag = el.tagName.toLowerCase();
    if (el.matches('[role="slider"]')) return 'slider';
    if (tag === 'input') {
      const t = (el.type || 'text').toLowerCase();
      if (t === 'range') return 'slider';
      if (t === 'checkbox' || t === 'radio') return 'toggle';
      if (t === 'button' || t === 'submit' || t === 'reset') return 'button';
      if (t === 'hidden') return '';
      return 'field';
    }
    if (tag === 'select') return 'select';
    if (tag === 'textarea') return 'field';
    if (tag === 'a') return 'link';
    if (tag === 'button' || el.matches('[role="button"]')) return 'button';
    if (el.matches('[role="switch"],[role="checkbox"]')) return 'toggle';
    if (el.matches('[role="tab"],.tab')) return 'tab';
    return 'block';
  }

  function labelOf(el, type) {
    let t = el.getAttribute('aria-label') || el.getAttribute('title') || '';
    if (!t && type === 'field') t = el.getAttribute('placeholder') || '';
    if (!t && type === 'select') {
      const opt = el.options && el.options[el.selectedIndex];
      t = (el.getAttribute('aria-label') || '') + (opt ? ' · ' + opt.textContent : '');
    }
    if (!t) {
      const clone = el.cloneNode(true);
      clone.querySelectorAll('input,select,textarea,option,script,style,svg').forEach(x => x.remove());
      t = (clone.textContent || '').replace(/\s+/g, ' ').trim();
    }
    if (type === 'field' && el.value) t = t ? t + ' · ' + el.value : el.value;
    if (type === 'slider') t = (t || 'Slider') + ' · ' + (el.value != null ? el.value : (el.getAttribute('aria-valuenow') || ''));
    return (t || type).slice(0, 64);
  }

  function targetInfo(el, type) {
    const r = el.getBoundingClientRect();
    const cs = getComputedStyle(el);
    return {
      el: el, type: type || typeOf(el), rect: r,
      label: labelOf(el, type || typeOf(el)),
      radius: cs.borderTopLeftRadius && cs.borderTopLeftRadius !== '0px' ? cs.borderTopLeftRadius : '12px',
      bg: cs.backgroundColor
    };
  }

  function usable(el) {
    if (!el || el.closest('#agRoot')) return false;
    if (!visible(el)) return false;
    const type = typeOf(el);
    if (!type) return false;
    if (type === 'block' && !AIR.pointer.blockTargets) return false;
    if (type === 'block') {
      const r = el.getBoundingClientRect();
      if (r.width * r.height > innerWidth * innerHeight * (num(AIR.pointer.blockMaxAreaPct, 32) / 100)) return false;
      if (r.width < 52 || r.height < 26) return false;
    }
    return true;
  }

  function candidateList() {
    const ts = nowMs();
    if (ts - candAt < 380) return candCache;
    candAt = ts;
    candCache = [];
    try {
      document.querySelectorAll(TARGET_SELECTOR).forEach(el => { if (usable(el)) candCache.push(el); });
      if (AIR.pointer.blockTargets) document.querySelectorAll(BLOCK_SELECTOR).forEach(el => { if (usable(el)) candCache.push(el); });
    } catch (e) {}
    return candCache;
  }

  function findTarget(x, y) {
    const seen = new Set();
    const stack = document.elementsFromPoint(x, y) || [];
    for (let i = 0; i < stack.length && i < 14; i++) {
      const el = stack[i];
      if (!el || el.closest('#agRoot')) continue;
      let t = null;
      try { t = el.closest(TARGET_SELECTOR); } catch (e) {}
      if (t && !seen.has(t) && usable(t)) return targetInfo(t);
      if (AIR.pointer.blockTargets) {
        try {
          const b = el.closest(BLOCK_SELECTOR);
          if (b && !seen.has(b) && usable(b)) return targetInfo(b, 'block');
        } catch (e) {}
      }
    }
    const snap = Math.max(0, num(AIR.pointer.snapRadius, 30));
    if (snap > 0) {
      let best = null, bestD = snap + 1;
      const list = candidateList();
      for (let i = 0; i < list.length; i++) {
        const el = list[i];
        if (seen.has(el)) continue;
        const r = el.getBoundingClientRect();
        if (r.width * r.height > innerWidth * innerHeight * .38) continue;
        const dx = x < r.left ? r.left - x : x > r.right ? x - r.right : 0;
        const dy = y < r.top ? r.top - y : y > r.bottom ? y - r.bottom : 0;
        const d = Math.sqrt(dx * dx + dy * dy);
        if (d < bestD) { bestD = d; best = el; }
      }
      if (best) return targetInfo(best);
    }
    return null;
  }

  /* ------------------------------------------------------------------ morph */
  const Morph = (function () {
    let el = null, cloneBox = null, outline = null, tag = null, bar = null, value = null, badge = null, lastPlace = '', lastMode = '';
    function init() {
      el = document.getElementById('agMorph');
      if (!el) return;
      cloneBox = el.querySelector('.agMorphClone');
      outline = el.querySelector('.agMorphOutline');
      tag = el.querySelector('.agMorphTag');
      bar = el.querySelector('.agMorphBar');
      value = el.querySelector('.agMorphValue');
      badge = el.querySelector('.agMorphBadge');
    }
    function content(info) {
      if (!cloneBox) return;
      cloneBox.replaceChildren();
      const mode = AIR.pointer.morphMode || 'highlight';
      if (mode === 'none' || mode === 'outline' || mode === 'highlight') { cloneBox.style.display = 'none'; return; }
      cloneBox.style.display = '';
      if (mode === 'clone' && /^(button|link|tab)$/.test(info.type)) {
        try {
          const c = info.el.cloneNode(true);
          c.removeAttribute('id'); c.removeAttribute('aria-hidden');
          c.querySelectorAll('[id]').forEach(x => x.removeAttribute('id'));
          c.querySelectorAll('input,select,textarea,button,a').forEach(x => { x.tabIndex = -1; x.setAttribute('aria-hidden', 'true'); });
          c.style.width = '100%'; c.style.height = '100%'; c.style.margin = '0'; c.style.pointerEvents = 'none';
          c.style.background = 'transparent'; c.style.border = '0'; c.style.boxShadow = 'none'; c.style.color = '#fff';
          cloneBox.appendChild(c);
          return;
        } catch (e) {}
      }
      const t = document.createElement('div');
      t.className = 'agMorphText'; t.textContent = info.label;
      cloneBox.appendChild(t);
    }
    function placeTarget(info, force) {
      if (!el) init(); if (!el || !info) return;
      const pad = Math.max(0, num(AIR.pointer.morphPad, 7));
      const r = info.el.getBoundingClientRect();
      const left = clamp(r.left - pad, 0, innerWidth - 2);
      const top = clamp(r.top - pad, 0, innerHeight - 2);
      const width = Math.max(8, Math.min(innerWidth - left, r.width + pad * 2));
      const height = Math.max(8, Math.min(innerHeight - top, r.height + pad * 2));
      const radius = info.radius || '12px';
      const mode = AIR.pointer.morphMode || 'highlight';
      // The target scan runs several times a second. If the rect and mode have
      // not changed, leave the overlay alone: writing left/top/width/height and
      // toggling classes every frame forces needless style/layout work and can
      // starve the camera on a phone.
      const key = [left, top, width, height, radius, mode].join('|');
      if (!force && key === lastPlace) { el.classList.add('on'); return; }
      const modeChanged = mode !== lastMode;
      lastMode = mode;
      lastPlace = key;
      if (modeChanged) content(info);
      el.style.left = left + 'px'; el.style.top = top + 'px';
      el.style.width = width + 'px'; el.style.height = height + 'px';
      el.style.borderRadius = radius;
      el.classList.toggle('ag-morph-none', mode === 'none');
      el.classList.toggle('ag-morph-outline', mode === 'outline');
      el.classList.toggle('ag-morph-highlight', mode === 'highlight');
      el.classList.add('on');
    }
    function place(info, animate) {
      if (!el) init(); if (!el || !info) return;
      if (animate && AIR.pointer.morphFromPointer !== false && S.point) {
        el.classList.remove('on', 'pressed', 'dwell');
        if (S.lite) {
          // Lite/mobile: keep the target rect static and animate only the
          // compositor transform. Growing a tiny seed from the pointer via
          // left/top/width/height forces layout on every frame and is exactly
          // what makes a phone camera stutter.
          placeTarget(info, true);
          const r = el.getBoundingClientRect();
          const ox = clamp((S.point.x - r.left) / Math.max(1, r.width) * 100, 0, 100);
          const oy = clamp((S.point.y - r.top) / Math.max(1, r.height) * 100, 0, 100);
          el.style.transformOrigin = ox + '% ' + oy + '%';
          el.style.transition = 'none';
          el.style.transform = 'scale(.12)';
          void el.offsetWidth;
          el.style.transition = '';
          el.style.transform = 'scale(1)';
        } else {
          // Full mode: a small glass seed at the pointer grows into the target.
          el.style.transformOrigin = '50% 50%';
          el.style.left = (S.point.x - 4) + 'px';
          el.style.top = (S.point.y - 4) + 'px';
          el.style.width = '8px'; el.style.height = '8px'; el.style.borderRadius = '50%';
          el.classList.add('on');
          void el.offsetWidth;
          placeTarget(info, true);
        }
      } else {
        el.style.transformOrigin = '50% 50%';
        el.style.transform = '';
        placeTarget(info);
      }
    }
    function show(info) {
      if (!el) init(); if (!el || !info) return;
      place(info, true);
      content(info);
      if (tag) tag.textContent = info.type === 'slider' ? 'SLIDER' : info.type === 'toggle' ? 'TOGGLE' : info.type === 'select' ? 'CHOOSE' : info.type === 'field' ? 'TYPE' : info.type === 'block' ? 'BLOCK' : 'TARGET';
      if (bar) bar.style.display = info.type === 'slider' ? '' : 'none';
      if (badge) {
        const mode = effectiveClickMode();
        badge.textContent = mode === 'dwell' ? 'DWELL TO CLICK' : mode === 'manual' ? 'POINT ONLY' : 'LIFT INDEX TO CLICK';
        badge.style.display = info.type === 'block' ? '' : 'none';
      }
      updateSlider(info);
    }
    function refresh(info) {
      if (!el || !info) return;
      placeTarget(info);
      updateSlider(info);
    }
    function updateSlider(info) {
      if (!info || info.type !== 'slider' || !S.targetEl) return;
      const r = info.el.getBoundingClientRect();
      let ratio = (S.point.x - r.left) / Math.max(1, r.width);
      ratio = clamp(ratio, 0, 1);
      if (bar) { const i = bar.querySelector('i'); if (i) i.style.width = (ratio * 100).toFixed(1) + '%'; }
      if (value) value.textContent = info.el.value != null ? info.el.value : (info.el.getAttribute('aria-valuenow') || '');
    }
    function setDwell(p) {
      if (!el) return;
      el.classList.toggle('dwell', p > 0 && p < 1);
      el.style.setProperty('--ag-dwell', clamp(p * 100, 0, 100).toFixed(1) + '%');
    }
    function press() {
      if (!el) return;
      el.classList.remove('pressed'); void el.offsetWidth; el.classList.add('pressed');
      setTimeout(() => { if (el) el.classList.remove('pressed'); }, 380);
    }
    function hide() {
      if (!el) return;
      lastPlace = ''; lastMode = '';
      el.classList.remove('on', 'pressed', 'dwell', 'ag-morph-highlight', 'ag-morph-outline', 'ag-morph-none');
      el.style.setProperty('--ag-dwell', '0%');
    }
    return { show: show, refresh: refresh, hide: hide, press: press, setDwell: setDwell, updateSlider: updateSlider, init: init };
  })();

  /* -------------------------------------------------------------- lock/click */
  function effectiveClickMode() {
    if (S.engine === 'contour' && !(S.landmarker && S.handSeen)) return 'dwell';
    return AIR.gesture.clickMode || 'indexTap';
  }

  function lockTarget(t, ts) {
    if (S.locked) return;
    S.locked = true; S.lockAt = ts; S.dwellDone = false;
    S.targetInfo = t;
    const root = rootEl(); if (root) {
      root.classList.add('ag-locked');
      root.classList.toggle('ag-pointer-morph', !!(AIR.pointer.pointerMorph && AIR.pointer.morphMode !== 'none'));
    }
    const lab = document.querySelector('#agPointer .agLabel');
    if (lab) lab.textContent = t.label;
    Morph.show(t);
    Sound.play('lock');
    statusFromState();
    try { t.el.dispatchEvent(new CustomEvent('airgesture:lock', { bubbles: true, detail: { type: t.type, label: t.label } })); } catch (e) {}
  }

  function unlockTarget(silent) {
    if (!S.locked && !S.targetEl) return;
    const t = S.targetInfo;
    if (t && t.type === 'slider') dispatchRangeChange(t.el);
    S.locked = false; S.targetInfo = null; S.dwellDone = false;
    const root = rootEl(); if (root) { root.classList.remove('ag-locked'); root.classList.remove('ag-pointer-morph'); }
    Morph.hide();
    const lab = document.querySelector('#agPointer .agLabel');
    if (lab) lab.textContent = '';
    if (!silent) Sound.play('release');
    if (t) { try { t.el.dispatchEvent(new CustomEvent('airgesture:unlock', { bubbles: true, detail: { type: t.type } })); } catch (e) {} }
    statusFromState();
  }

  function setNativeValue(el, v) {
    try {
      const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : (el instanceof HTMLInputElement ? HTMLInputElement.prototype : null);
      const setter = proto && Object.getOwnPropertyDescriptor(proto, 'value');
      if (setter && setter.set) setter.set.call(el, v); else el.value = v;
    } catch (e) { el.value = v; }
  }
  function fire(el, type) {
    try { el.dispatchEvent(new Event(type, { bubbles: true, cancelable: true })); } catch (e) {}
  }
  function dispatchRangeChange(el) {
    if (!el) return;
    fire(el, 'change');
    try { el.dispatchEvent(new CustomEvent('airgesture:change', { bubbles: true, detail: { value: el.value } })); } catch (e) {}
  }
  function applySlider(t) {
    if (!t || t.type !== 'slider') return;
    const el = t.el, r = el.getBoundingClientRect();
    const min = num(el.min, 0), max = num(el.max, 100), step = num(el.step, 1) || 1;
    let ratio = clamp((S.point.x - r.left) / Math.max(1, r.width), 0, 1);
    let v = min + ratio * (max - min);
    v = Math.round(v / step) * step;
    v = clamp(v, min, max);
    if (el.value !== String(v)) {
      setNativeValue(el, v);
      fire(el, 'input');
      if (S.locked) Morph.updateSlider(t);
    }
  }

  function cycleSelect(el) {
    if (!el || !el.options || !el.options.length) return;
    el.selectedIndex = (el.selectedIndex + 1) % el.options.length;
    fire(el, 'input'); fire(el, 'change');
    if (S.targetInfo) S.targetInfo.label = labelOf(el, 'select');
    const lab = document.querySelector('#agPointer .agLabel');
    if (lab && S.targetInfo) lab.textContent = S.targetInfo.label;
    Morph.show(S.targetInfo || targetInfo(el, 'select'));
  }

  function doClick(source) {
    let t = S.targetInfo;
    // A fast tap can land before the lock delay has elapsed. Hit-test once at
    // click time so the gesture still works instead of silently doing nothing.
    if (!t || !t.el || !t.el.isConnected) {
      t = findTarget(S.point.x, S.point.y);
      if (!t) return;
      if (!S.locked) {
        Morph.show(t);
        setTimeout(() => { if (!S.locked) Morph.hide(); }, 260);
      }
    }
    const el = t.el;
    if (el.disabled || el.getAttribute('aria-disabled') === 'true') { Sound.play('error'); return; }
    try {
      if (t.type === 'slider') { applySlider(t); dispatchRangeChange(el); }
      else if (t.type === 'select') cycleSelect(el);
      else if (t.type === 'field') { try { el.focus({ preventScroll: true }); } catch (e) { el.focus(); } }
      else if (t.type === 'block') {
        try { el.dispatchEvent(new CustomEvent('airgesture:select', { bubbles: true, detail: { label: t.label } })); } catch (e) {}
      } else {
        try { el.focus({ preventScroll: true }); } catch (e) {}
        if (typeof el.click === 'function') el.click();
        else {
          const r = el.getBoundingClientRect();
          const opt = { bubbles: true, cancelable: true, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2, button: 0, view: window };
          ['pointerdown','mousedown','pointerup','mouseup','click'].forEach(type => { try { el.dispatchEvent(new MouseEvent(type, opt)); } catch (e) {} });
        }
      }
      S.clickCount++; S.lastClick = nowMs();
      Morph.press(); Fx.burst(AIR.pointer.particleCount); Sound.play('click');
      try { el.dispatchEvent(new CustomEvent('airgesture:click', { bubbles: true, detail: { type: t.type, label: t.label, source: source || 'gesture' } })); } catch (e) {}
      if (S.demo) S.lockAt = nowMs();
    } catch (e) {
      Sound.play('error');
      if (AIR.debug.logToConsole) { try { console.warn('[airgesture] click failed', e); } catch (_) {} }
    }
  }

  function edgeScroll(ts) {
    if (!AIR.pointer.edgeScroll || !S.active) return;
    const m = Math.max(6, num(AIR.pointer.edgeScrollPx, 26));
    let dy = 0;
    if (S.point.y < m) dy = -1; else if (S.point.y > innerHeight - m) dy = 1;
    if (!dy) { S.lastEdgeScroll = ts; return; }
    if (ts - (S.lastEdgeScroll || 0) < 34) return;
    S.lastEdgeScroll = ts;
    const speed = Math.max(1, num(AIR.pointer.edgeScrollSpeed, 9));
    const under = document.elementFromPoint(clamp(S.point.x, 1, innerWidth - 1), clamp(S.point.y, 1, innerHeight - 1));
    let node = under;
    while (node && node !== document.body && node !== document.documentElement) {
      const cs = getComputedStyle(node);
      if (node.scrollHeight > node.clientHeight + 4 && /(auto|scroll)/.test(cs.overflowY)) {
        node.scrollTop += dy * speed; return;
      }
      node = node.parentElement;
    }
    window.scrollBy(0, dy * speed);
  }

  function updateTarget(ts) {
    if (!S.active || !S.visible) { if (S.locked) unlockTarget(true); return; }
    edgeScroll(ts);
    // Hit-testing calls elementFromPoint() and getComputedStyle(). On a phone that is
    // expensive enough to starve the video, so scan a few times a second, not every frame.
    const scanEvery = S.lite ? 55 : 32;
    const scan = !S.lastTargetScan || ts - S.lastTargetScan >= scanEvery;
    if (scan) {
      S.lastTargetScan = ts;
      const t = findTarget(S.point.x, S.point.y);
      if (!t) {
        if (!S.targetLostAt) S.targetLostAt = ts;
        if (S.locked && ts - S.targetLostAt >= num(AIR.pointer.unlockDelayMs, 140)) unlockTarget(false);
        if (ts - S.targetLostAt > 500) { S.targetEl = null; S.targetInfo = null; }
        return;
      }
      S.targetLostAt = 0;
      if (t.el !== S.targetEl) {
        const wasLocked = S.locked;
        S.targetEl = t.el; S.targetInfo = t; S.targetSince = ts;
        if (wasLocked) { Morph.show(t); Sound.play('tick'); }
        const lab = document.querySelector('#agPointer .agLabel');
        if (lab) lab.textContent = t.label;
      } else {
        t.rect = t.el.getBoundingClientRect();
        S.targetInfo = t;
        if (S.locked) Morph.refresh(t);
      }
      if (!S.locked) {
        if (ts - S.targetSince >= Math.max(0, num(AIR.pointer.lockDelayMs, 85))) lockTarget(t, ts);
        return;
      }
    }
    if (!S.locked || !S.targetInfo) return;
    const t = S.targetInfo;
    const mode = effectiveClickMode();
    if (mode === 'dwell' && !S.dwellDone) {
      const progress = clamp((ts - S.lockAt - num(AIR.pointer.lockDelayMs, 85)) / Math.max(250, num(AIR.gesture.dwellMs, 850)), 0, 1);
      Morph.setDwell(progress);
      if (progress >= 1) { S.dwellDone = true; doClick('dwell'); }
    } else {
      Morph.setDwell(0);
    }
    if (AIR.pointer.sliderLive !== false && t.type === 'slider') applySlider(t);
  }

  /* ---------------------------------------------------------------- preview */
  const ctxCache = new WeakMap();
  function previewCtx(c) {
    if (!ctxCache.has(c)) ctxCache.set(c, c.getContext('2d'));
    return ctxCache.get(c);
  }

  function renderPreview(canvas, ts) {
    if (!canvas) return;
    const c = previewCtx(canvas); if (!c) return;
    const W = canvas.width || 320, H = canvas.height || 240;
    c.save(); c.clearRect(0, 0, W, H);
    c.fillStyle = '#020807'; c.fillRect(0, 0, W, H);
    const v = S.video;
    if (v && v.readyState >= 2 && v.videoWidth && !S.demo) {
      c.save(); c.translate(W, 0); c.scale(-1, 1);
      c.drawImage(v, 0, 0, W, H);
      c.restore();
    } else {
      const t = ts / 1000;
      c.fillStyle = '#07120f'; c.fillRect(0, 0, W, H);
      c.strokeStyle = 'rgba(126,247,212,.08)'; c.lineWidth = 1;
      for (let x = 0; x < W; x += 24) { c.beginPath(); c.moveTo(x, 0); c.lineTo(x, H); c.stroke(); }
      for (let y = 0; y < H; y += 24) { c.beginPath(); c.moveTo(0, y); c.lineTo(W, y); c.stroke(); }
      c.fillStyle = 'rgba(126,247,212,.55)'; c.font = '10px ui-monospace,monospace'; c.textAlign = 'center';
      c.fillText(S.demo ? 'DEMO POINTER' : 'CAMERA IDLE', W / 2, H / 2);
      if (S.demo) { c.beginPath(); c.arc(W / 2 + Math.sin(t * .8) * W * .22, H / 2 + Math.cos(t * 1.1) * H * .18, 18 + Math.sin(t * 3) * 3, 0, Math.PI * 2); c.strokeStyle = '#7ef7d4'; c.lineWidth = 2; c.stroke(); }
    }
    if (AIR.debug.drawLandmarks && S.landmarks && !S.demo) {
      c.save(); c.translate(W, 0); c.scale(-1, 1);
      c.strokeStyle = 'rgba(126,247,212,.55)'; c.lineWidth = 1.2;
      HAND_CONNECTIONS.forEach(pair => {
        const a = S.landmarks[pair[0]], b = S.landmarks[pair[1]];
        if (!a || !b) return;
        c.beginPath(); c.moveTo(a.x * W, a.y * H); c.lineTo(b.x * W, b.y * H); c.stroke();
      });
      c.fillStyle = '#ffffff';
      S.landmarks.forEach((p, i) => {
        c.fillStyle = i === 4 || i === 8 || i === 12 ? '#ff8bd1' : '#7ef7d4';
        c.beginPath(); c.arc(p.x * W, p.y * H, i === 4 || i === 8 || i === 12 ? 3.4 : 2, 0, Math.PI * 2); c.fill();
      });
      c.restore();
    }
    if (S.contour && S.contour.seen && ts - S.contour.seen < 900 && S.contour.box) {
      const b = S.contour.box;
      c.save(); c.translate(W, 0); c.scale(-1, 1);
      c.strokeStyle = 'rgba(155,201,255,.7)'; c.setLineDash([4, 4]); c.lineWidth = 1;
      c.strokeRect(b[0] * W, b[1] * H, (b[2] - b[0]) * W, (b[3] - b[1]) * H);
      c.setLineDash([]);
      c.fillStyle = 'rgba(155,201,255,.8)';
      c.beginPath(); c.arc(S.contour.x * W, S.contour.y * H, 3, 0, Math.PI * 2); c.fill();
      c.restore();
    }
    c.fillStyle = 'rgba(0,0,0,.45)'; c.fillRect(0, H - 17, W, 17);
    c.fillStyle = '#9fe8d4'; c.font = '9px ui-monospace,monospace'; c.textAlign = 'left';
    c.fillText((S.demo ? 'DEMO' : S.engine.toUpperCase()) + ' · ' + (S.handSeen ? 'HAND' : 'NO HAND') + ' · ' + S.metrics.ti.toFixed(2) + '/' + S.metrics.tm.toFixed(2), 6, H - 6);
    c.restore();
  }

  function maybePreview(ts) {
    if (ts - (S.lastPreview || 0) < 70) return;
    S.lastPreview = ts;
    S.previews.forEach(c => {
      if (c && c.isConnected && (c.offsetWidth || c.offsetHeight)) renderPreview(c, ts);
    });
    if (AIR.debug.showOverlay && S.debugCanvas) renderPreview(S.debugCanvas, ts);
    if (ts - (S.lastMetricsUi || 0) > 240) { S.lastMetricsUi = ts; updateSettingsMetrics(); }
  }

  function updateSettingsMetrics() {
    const set = (id, v) => { const el = document.getElementById(id); if (el) el.textContent = v; };
    const m = S.metrics;
    set('agMetTi', m.ti.toFixed(2));
    set('agMetTm', m.tm.toFixed(2));
    set('agMetRing', m.ring.toFixed(2));
    set('agMetPinky', m.pinky.toFixed(2));
    set('agMetEngine', S.demo ? 'demo' : (S.engine || '—'));
    set('agMetHand', S.handSeen ? 'yes' : 'no');
    set('agMetFps', S.running ? (S.detectFps ? S.detectFps.toFixed(0) + ' fps' : '…') : '—');
    set('agMetClicks', String(S.clickCount));
    set('agMetTap', S.indexUp ? 'UP ' + (S.tapPeak || m.ti).toFixed(2) : 'down ' + (S.tapBase || m.ti).toFixed(2));
    set('agMetStatus', S.statusText || S.status);
    const bar = document.getElementById('agMetBar');
    if (bar) {
      const score = clamp(1 - Math.max(m.ti, m.tm) / Math.max(1, AIR.gesture.pinchExit), 0, 1);
      bar.style.width = (score * 100).toFixed(0) + '%';
    }
    const badge = document.getElementById('agCamBadgeText');
    if (badge) badge.textContent = S.demo ? 'DEMO' : S.running ? (S.handSeen ? 'HAND' : 'SEARCHING') : 'CAMERA OFF';
    const badgeEl = document.getElementById('agCamBadge');
    if (badgeEl) {
      badgeEl.className = 'agCamBadge ' + (S.demo ? '' : S.running ? (S.handSeen ? '' : 'idle') : 'idle') + (S.engineState === 'error' ? ' err' : '');
    }
    const dbg = document.getElementById('agDbgGrid');
    if (dbg) {
      const rows = [
        ['Pinch T–I / T–M', m.ti.toFixed(2) + ' / ' + m.tm.toFixed(2)],
        ['Index tap', S.indexUp ? 'UP ' + (S.tapPeak || m.ti).toFixed(2) : 'down ' + (S.tapBase || m.ti).toFixed(2)],
        ['Pointer', Math.round(S.point.x) + ', ' + Math.round(S.point.y)],
        ['Target', S.targetInfo ? (S.targetInfo.type + ' · ' + S.targetInfo.label) : 'none'],
        ['Clicks', String(S.clickCount)],
        ['State', S.statusText || S.status]
      ];
      dbg.replaceChildren(...rows.map(([k, v]) => {
        const wrap = document.createElement('div');
        if (k === 'Target' || k === 'State') wrap.className = 'agDbgWide';
        const a = document.createElement('span'); a.textContent = k;
        const b = document.createElement('b'); b.textContent = v;
        wrap.append(a, b); return wrap;
      }));
    }
  }

  function updateSettingsStatus() {
    const el = document.getElementById('agSetStatus');
    if (el) {
      let txt = S.statusText || S.status.toUpperCase();
      if (S.engineError) txt += ' — ' + S.engineError;
      else if (S.engineState === 'ready' && S.engine === 'landmarker') txt += ' · MediaPipe landmarks';
      else if (S.engine === 'contour') txt += ' · contour fallback';
      else if (S.running) txt += ' · ' + S.engine;
      el.textContent = txt;
    }
    updateSettingsMetrics();
  }

  function attachPreview(canvas) {
    if (canvas) { if (!canvas.width) { canvas.width = 320; canvas.height = 240; } S.previews.add(canvas); renderPreview(canvas, nowMs()); }
    return () => S.previews.delete(canvas);
  }
  function detachPreview(canvas) { S.previews.delete(canvas); }

  /* --------------------------------------------------------------- settings */
  function btn(label, cls, fn) {
    const b = document.createElement('button');
    b.type = 'button'; b.className = cls || 'quietBtn'; b.textContent = label;
    b.addEventListener('click', fn); return b;
  }

  function metricRow(label, id) {
    // Returns markup (not an element) because buildSettings() composes the
    // metrics block in one HTML string. String(element) would render as
    // "[object HTMLDivElement]".
    const esc = String(label).replace(/[&<>"]/g, ch => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[ch]));
    return '<div><span>' + esc + '</span><b id="' + id + '">—</b></div>';
  }

  function buildSettings() {
    const host = document.getElementById('airCtl');
    if (!host) return;
    host.replaceChildren();
    S.settingsRoot = host;

    const top = document.createElement('div');
    top.className = 'agSettingsTop';
    top.innerHTML =
      '<div class="agCameraShell agSettingsCam">' +
        '<canvas id="agSettingsCanvas" width="320" height="240"></canvas>' +
        '<div class="agCamBadge idle" id="agCamBadge"><span id="agCamBadgeText">CAMERA OFF</span></div>' +
      '</div>' +
      '<div class="agSettingsSide">' +
        '<div class="agSetStatus" id="agSetStatus">Checking camera…</div>' +
        '<div class="agMetrics">' +
          metricRow('Pinch T–I', 'agMetTi') + metricRow('Pinch T–M', 'agMetTm') +
          metricRow('Ring fold', 'agMetRing') + metricRow('Pinky fold', 'agMetPinky') +
          metricRow('Engine', 'agMetEngine') + metricRow('Hand', 'agMetHand') +
          metricRow('Detect', 'agMetFps') + metricRow('Clicks', 'agMetClicks') +
          metricRow('Index tap', 'agMetTap') + metricRow('Status', 'agMetStatus') +
        '</div>' +
        '<div class="agMeter"><i id="agMetBar"></i></div>' +
        '<div class="systemActions" id="agMainActions"></div>' +
      '</div>';
    host.appendChild(top);
    const actions = $('#agMainActions', top);
    actions.append(
      btn('Start vision', 'saveBtn', () => { AIR.enabled = true; saveCfg(); startCamera(); }),
      btn('Stop vision', 'quietBtn', () => { AIR.enabled = false; saveCfg(); stopCamera(); }),
      btn('Demo pointer', 'quietBtn', () => startDemo(false)),
      btn('Air gesture lab', 'quietBtn', () => window.open('/airgesture', '_blank', 'noopener')),
      btn('Refresh cameras', 'quietBtn', () => refreshDevices(true))
    );

    const note = document.createElement('p');
    note.className = 'empty agSettingsNote';
    note.innerHTML = 'Pinch <b>thumb + index + middle</b> like holding a pen. Keep thumb + middle touching, then lift and lower the index to click. Pick any pointer in the <b>Pointer gallery</b>; when it settles on a target it grows into that target’s glass outline. Metrics are live: hold the real pose and press <b>Learn pinch</b>, lift the index and press <b>Learn click</b>; use <b>Test click</b> to check the page handler.';
    host.appendChild(note);

    // camera chooser
    const camRow = document.createElement('div');
    camRow.className = 'agCamRow';
    const camLab = document.createElement('label');
    camLab.setAttribute('for', 'agCamSelect'); camLab.textContent = 'Camera';
    const sel = document.createElement('select'); sel.id = 'agCamSelect';
    const auto = document.createElement('option'); auto.value = ''; auto.textContent = 'Default camera'; sel.appendChild(auto);
    S.deviceList.forEach((d, i) => { const o = document.createElement('option'); o.value = d.deviceId; o.textContent = d.label || ('Camera ' + (i + 1)); sel.appendChild(o); });
    sel.value = AIR.vision.deviceId || '';
    sel.addEventListener('change', () => { AIR.vision.deviceId = sel.value; saveCfg(); if (S.running) startCamera(); });
    camRow.append(camLab, sel);
    host.appendChild(camRow);
    refreshDevices(true);

    const controls = window.CodaKiosk && window.CodaKiosk.buildControls ? window.CodaKiosk.buildControls : null;
    if (!controls) {
      const warn = document.createElement('p'); warn.className = 'empty';
      warn.textContent = 'Open this panel from the kiosk to edit settings. The lab page only runs the pointer.';
      host.appendChild(warn);
      attachPreview($('#agSettingsCanvas', top));
      updateSettingsStatus();
      return;
    }

    const after = (k, v) => { onCfgChange(k, v); };
    const group = (head) => {
      const grid = document.createElement('div'); grid.className = 'ctlGrid';
      if (head) { const h = document.createElement('div'); h.className = 'ctlHead'; h.textContent = head; grid.appendChild(h); }
      host.appendChild(grid); return grid;
    };

    // Vision
    let g = group('Vision & camera');
    controls(g, AIR.vision, [
      { k: 'source', label: 'Input', type: 'select', opts: [['camera', 'Webcam (real hand)'], ['demo', 'Demo pointer (mouse)']] },
      { k: 'engine', label: 'Vision engine', type: 'select', opts: [['auto', 'Auto (MediaPipe + contour fallback)'], ['landmarker', 'MediaPipe landmarks only'], ['contour', 'Contour tracker only (no model)']] },
      { k: 'resolution', label: 'Capture resolution', type: 'select', opts: [['320x240', '320 × 240 (fastest)'], ['480x360', '480 × 360'], ['640x480', '640 × 480 (recommended)'], ['1280x720', '1280 × 720 (sharpest)']] },
      { k: 'fps', label: 'Vision frame rate', type: 'range', min: 8, max: 40, step: 1, unit: ' fps' },
      { k: 'mirror', label: 'Mirror camera (selfie view)', type: 'bool' },
      { k: 'assets', label: 'Model files', type: 'select', opts: [['auto', 'Auto (local vendor, else CDN)'], ['cdn', 'Always CDN'], ['local', 'Local /vendor/airgesture only']] },
      { k: 'delegate', label: 'Compute', type: 'select', opts: [['GPU', 'GPU (faster)'], ['CPU', 'CPU (more compatible)']] },
      { k: 'contourFallback', label: 'Contour fallback tracker', type: 'bool' },
      { k: 'contourFps', label: 'Contour tracker rate', type: 'range', min: 4, max: 30, step: 1, unit: ' fps' },
      { k: 'skinTolerance', label: 'Skin-colour tolerance', type: 'range', min: 0, max: 100, step: 1, unit: '%' },
      { k: 'skinMinArea', label: 'Contour minimum size', type: 'range', min: .001, max: .05, step: .001, unit: ' area' },
      { k: 'contourMaxPeaks', label: 'Contour finger peaks (activation)', type: 'range', min: 1, max: 8, step: 1 },
      { k: 'contourMinSolidity', label: 'Contour compactness', type: 'range', min: .1, max: .9, step: .01 },
      { k: 'contourActivateFrames', label: 'Contour frames to activate', type: 'range', min: 1, max: 12, step: 1 },
      { k: 'contourReleaseFrames', label: 'Contour frames to release', type: 'range', min: 1, max: 20, step: 1 },
      { k: 'minHandConfidence', label: 'Hand detection confidence', type: 'range', min: .1, max: .95, step: .01 },
      { k: 'minPresenceConfidence', label: 'Hand presence confidence', type: 'range', min: .1, max: .95, step: .01 },
      { k: 'minTrackingConfidence', label: 'Landmark tracking confidence', type: 'range', min: .1, max: .95, step: .01 },
      { k: 'pauseWhenHidden', label: 'Pause vision when page hidden', type: 'bool' }
    ], after);

    // Gesture
    g = group('Pen-grip gesture');
    controls(g, AIR.gesture, [
      { k: 'pinchEnter', label: 'Pinch enter threshold', type: 'range', min: .1, max: 2.5, step: .01, hint: 'Lower = requires a tighter pinch' },
      { k: 'pinchExit', label: 'Pinch hold/release threshold', type: 'range', min: .2, max: 3, step: .01 },
      { k: 'requireFolded', label: 'Require ring + pinky folded', type: 'bool' },
      { k: 'ringFoldMax', label: 'Ring folded threshold', type: 'range', min: .1, max: 2, step: .01 },
      { k: 'pinkyFoldMax', label: 'Pinky folded threshold', type: 'range', min: .1, max: 2, step: .01 },
      { k: 'activationFrames', label: 'Frames to appear', type: 'range', min: 1, max: 15, step: 1 },
      { k: 'releaseFrames', label: 'Frames to disappear', type: 'range', min: 1, max: 25, step: 1 },
      { k: 'settleMs', label: 'Ignore clicks after appear', type: 'range', min: 0, max: 1200, step: 10, unit: ' ms' },
      { k: 'clickMode', label: 'Click trigger', type: 'select', opts: [['indexTap', 'Index finger tap (pen click)'], ['dwell', 'Dwell on target'], ['manual', 'Pointer only (no click)']] },
      { k: 'clickUp', label: 'Index-up threshold', type: 'range', min: .2, max: 3, step: .01 },
      { k: 'clickDown', label: 'Index-down threshold', type: 'range', min: .1, max: 2.5, step: .01 },
      { k: 'clickLiftDelta', label: 'Extra lift needed above pen grip', type: 'range', min: .1, max: .8, step: .01 },
      { k: 'clickDropDelta', label: 'How far the tap must fall', type: 'range', min: .05, max: .6, step: .01 },
      { k: 'tapWindowMs', label: 'Tap must finish within', type: 'range', min: 120, max: 2000, step: 20, unit: ' ms' },
      { k: 'dwellMs', label: 'Dwell time (dwell mode)', type: 'range', min: 250, max: 2500, step: 50, unit: ' ms' },
      { k: 'confidenceMin', label: 'Minimum hand confidence', type: 'range', min: 0, max: .9, step: .01 },
      { k: 'handedness', label: 'Hand', type: 'select', opts: [['any', 'Either hand'], ['Right', 'Right only'], ['Left', 'Left only']] }
    ], after);
    const learnRow = document.createElement('div');
    learnRow.className = 'systemActions';
    learnRow.append(
      btn('Learn pinch from current hand', 'quietBtn', () => learn('pinch')),
      btn('Learn click lift from current hand', 'quietBtn', () => learn('click')),
      btn('Test click on current target', 'quietBtn', () => {
        const t = S.targetInfo || findTarget(S.point.x, S.point.y);
        const before = S.clickCount;
        if (t) doClick('test');
        const el = document.getElementById('agSetStatus');
        if (el) el.textContent = t
          ? 'Click test: ' + (S.clickCount > before ? 'fired on ' : 'found ') + t.label + (S.clickCount > before ? '' : ' — but no click event')
          : 'Click test: no target under the pointer. Move over a button and try again.';
      }),
      btn('Reset gesture thresholds', 'quietBtn', () => {
        AIR.gesture = merge(AIR_DEF.gesture, {});
        saveCfg(); applyLook(); buildSettings(); statusFromState();
      })
    );
    host.appendChild(learnRow);

    // Tracking
    g = group('Tracking & screen mapping');
    controls(g, AIR.tracker, [
      { k: 'mode', label: 'Tracking mode', type: 'select', opts: [['relative', 'Wrist-relative — starts centre, moves like a mouse'], ['absolute', 'Absolute — point at the screen']] },
      { k: 'point', label: 'Hand anchor point', type: 'select', opts: [['palm', 'Palm centre (most stable)'], ['index', 'Index fingertip'], ['middle', 'Middle fingertip'], ['pinch', 'Thumb/index midpoint']] },
      { k: 'sensX', label: 'Horizontal sensitivity', type: 'range', min: .3, max: 3, step: .05, unit: '×' },
      { k: 'sensY', label: 'Vertical sensitivity', type: 'range', min: .3, max: 3, step: .05, unit: '×' },
      { k: 'relativeGain', label: 'Wrist travel gain', type: 'range', min: .5, max: 5, step: .1, unit: '×' },
      { k: 'invertX', label: 'Invert horizontal', type: 'bool' },
      { k: 'invertY', label: 'Invert vertical', type: 'bool' },
      { k: 'boxLeft', label: 'Active box left', type: 'range', min: 0, max: .45, step: .01 },
      { k: 'boxRight', label: 'Active box right', type: 'range', min: .55, max: 1, step: .01 },
      { k: 'boxTop', label: 'Active box top', type: 'range', min: 0, max: .45, step: .01 },
      { k: 'boxBottom', label: 'Active box bottom', type: 'range', min: .55, max: 1, step: .01 },
      { k: 'deadzone', label: 'Pixel deadzone', type: 'range', min: 0, max: 12, step: .5, unit: ' px' },
      { k: 'smoothMinCutoff', label: 'Smoothing (lower = smoother)', type: 'range', min: .3, max: 8, step: .1 },
      { k: 'smoothBeta', label: 'Speed responsiveness', type: 'range', min: 0, max: .2, step: .005 },
      { k: 'predictionMs', label: 'Motion prediction', type: 'range', min: 0, max: 120, step: 2, unit: ' ms' },
      { k: 'lostHoldMs', label: 'Hold pointer when hand lost', type: 'range', min: 0, max: 1500, step: 20, unit: ' ms' },
      { k: 'hideDelayMs', label: 'Hide after release', type: 'range', min: 0, max: 800, step: 20, unit: ' ms' },
      { k: 'edgeClamp', label: 'Keep pointer on screen', type: 'bool' }
    ], after);

    // Pointer gallery
    g = group('Pointer gallery');
    const gallery = document.createElement('div');
    gallery.className = 'agStyleGallery';
    const paintGallery = () => {
      gallery.querySelectorAll('.agStyleCard').forEach(card => {
        const on = card.dataset.style === AIR.pointer.style;
        card.classList.toggle('on', on);
        card.setAttribute('aria-pressed', on ? 'true' : 'false');
      });
    };
    POINTER_STYLES.forEach(([id, name]) => {
      const card = document.createElement('button');
      card.type = 'button'; card.className = 'agStyleCard'; card.dataset.style = id;
      card.setAttribute('aria-pressed', 'false'); card.title = name + ' pointer';
      const sw = document.createElement('span'); sw.className = 'agStyleSwatch'; sw.setAttribute('aria-hidden', 'true');
      const label = document.createElement('span'); label.className = 'agStyleName'; label.textContent = name;
      card.append(sw, label);
      card.addEventListener('click', () => {
        AIR.pointer.style = id; saveCfg(); applyLook(); paintGallery();
        const styleRow = [...host.querySelectorAll('.ctlRow')].find(row =>
          (row.querySelector('span') || {}).textContent === 'Pointer style');
        const select = styleRow && styleRow.querySelector('select');
        if (select) select.value = id;
      });
      gallery.appendChild(card);
    });
    g.appendChild(gallery);
    paintGallery();

    // Pointer
    g = group('Pointer look & morphing');
    controls(g, AIR.pointer, [
      { k: 'style', label: 'Pointer style', type: 'select', opts: POINTER_STYLES, after: () => { paintGallery(); onCfgChange('style'); } },
      { k: 'quality', label: 'Rendering quality', type: 'select', opts: [['auto', 'Auto — lite on phones / Termux'], ['full', 'Full — backdrop blur and every effect'], ['lite', 'Lite — best on low power / camera freeze']] },
      { k: 'size', label: 'Pointer size', type: 'range', min: 18, max: 110, step: 1, unit: ' px' },
      { k: 'core', label: 'Core dot size', type: 'range', min: 4, max: 36, step: 1, unit: ' px' },
      { k: 'primary', label: 'Primary glass colour', type: 'color' },
      { k: 'secondary', label: 'Secondary colour', type: 'color' },
      { k: 'accent', label: 'Accent colour', type: 'color' },
      { k: 'glass', label: 'Glass opacity', type: 'range', min: 0, max: 1, step: .01 },
      { k: 'blur', label: 'Backdrop blur', type: 'range', min: 0, max: 30, step: 1, unit: ' px' },
      { k: 'border', label: 'Glass rim width', type: 'range', min: 0, max: 4, step: .1, unit: ' px' },
      { k: 'glow', label: 'Glow strength', type: 'range', min: 0, max: 160, step: 2, unit: '%' },
      { k: 'hueShift', label: 'Hue rotation', type: 'range', min: -180, max: 180, step: 2, unit: '°' },
      { k: 'spin', label: 'Orbit speed', type: 'range', min: 0, max: 28, step: 1 },
      { k: 'trail', label: 'Motion trail', type: 'range', min: 0, max: 100, step: 1, unit: '%' },
      { k: 'particles', label: 'Sparkle particles', type: 'bool' },
      { k: 'particleCount', label: 'Click particle count', type: 'range', min: 0, max: 60, step: 1 },
      { k: 'lockScale', label: 'Pointer scale when locked', type: 'range', min: .1, max: 1, step: .01 },
      { k: 'pointerMorph', label: 'Pointer becomes the target', type: 'bool' },
      { k: 'morphFromPointer', label: 'Grow from pointer position', type: 'bool' },
      { k: 'morphMode', label: 'Morph style', type: 'select', opts: [['highlight', 'iPad-style outline + highlight'], ['clone', 'Clone target content'], ['label', 'Glass label'], ['outline', 'Outline only'], ['none', 'No morph overlay']] },
      { k: 'morphExpandMs', label: 'Morph travel time', type: 'range', min: 80, max: 900, step: 10, unit: ' ms' },
      { k: 'morphPad', label: 'Morph padding', type: 'range', min: 0, max: 24, step: 1, unit: ' px' },
      { k: 'morphOpacity', label: 'Morph content opacity', type: 'range', min: .1, max: 1, step: .01 },
      { k: 'snapRadius', label: 'Magnetic snap radius', type: 'range', min: 0, max: 90, step: 1, unit: ' px' },
      { k: 'lockDelayMs', label: 'Dwell before morph', type: 'range', min: 0, max: 600, step: 5, unit: ' ms' },
      { k: 'unlockDelayMs', label: 'Delay before unmorph', type: 'range', min: 0, max: 600, step: 5, unit: ' ms' },
      { k: 'blockTargets', label: 'Morph onto cards/blocks too', type: 'bool' },
      { k: 'blockMaxAreaPct', label: 'Largest block (% of screen)', type: 'range', min: 5, max: 70, step: 1, unit: '%' },
      { k: 'sliderLive', label: 'Sliders follow the pointer live', type: 'bool' },
      { k: 'edgeScroll', label: 'Edge auto-scroll', type: 'bool' },
      { k: 'edgeScrollPx', label: 'Edge scroll zone', type: 'range', min: 6, max: 80, step: 2, unit: ' px' },
      { k: 'edgeScrollSpeed', label: 'Edge scroll speed', type: 'range', min: 1, max: 30, step: 1 },
      { k: 'highContrast', label: 'High-contrast pointer', type: 'bool' },
      { k: 'reducedMotion', label: 'Reduce pointer motion', type: 'bool' },
      { k: 'hideSystemCursor', label: 'Hide system mouse cursor', type: 'bool' }
    ], after);

    // Sound
    g = group('Gesture sounds');
    controls(g, AIR.sound, [
      { k: 'enabled', label: 'Air-gesture sounds', type: 'bool' },
      { k: 'volume', label: 'Volume', type: 'range', min: 0, max: 100, step: 5, unit: '%', after: () => Sound.test('appear') },
      { k: 'style', label: 'Sound style', type: 'select', opts: [['glass', 'Glass shimmer'], ['soft', 'Soft sine'], ['synth', 'Synth triangle'], ['retro', 'Retro square']], after: () => Sound.test('appear') }
    ], after);
    const evHead = document.createElement('div'); evHead.className = 'ctlHead'; evHead.textContent = 'Events'; host.appendChild(evHead);
    const evWrap = document.createElement('div'); evWrap.className = 'ctlGrid'; host.appendChild(evWrap);
    Object.keys(AIR_DEF.sound.events).forEach(name => {
      const row = document.createElement('div'); row.className = 'ctlRow';
      const lab = document.createElement('label'); lab.textContent = name.charAt(0).toUpperCase() + name.slice(1);
      const cb = document.createElement('input'); cb.type = 'checkbox'; cb.checked = !!AIR.sound.events[name];
      cb.addEventListener('change', () => { AIR.sound.events[name] = cb.checked; saveCfg(); });
      lab.prepend(cb, ' ');
      const test = btn('Test', 'quietBtn', () => Sound.test(name));
      row.append(lab, test); evWrap.appendChild(row);
    });

    // Debug
    g = group('Diagnostics & debugging');
    controls(g, AIR.debug, [
      { k: 'showOverlay', label: 'Floating vision overlay', type: 'bool', after: applyLook },
      { k: 'drawLandmarks', label: 'Draw hand landmarks', type: 'bool' },
      { k: 'logToConsole', label: 'Log events to browser console', type: 'bool' }
    ], after);
    const dbgRow = document.createElement('div');
    dbgRow.className = 'systemActions';
    dbgRow.append(
      btn('Copy diagnostics', 'quietBtn', copyDiagnostics),
      btn('Open vision lab', 'quietBtn', () => window.open('/airgesture', '_blank', 'noopener')),
      btn('Restart vision', 'quietBtn', () => { if (AIR.enabled) startCamera(); }),
      btn('Reset air gesture', 'danger quietBtn', resetAir)
    );
    host.appendChild(dbgRow);

    attachPreview($('#agSettingsCanvas', top));
    updateSettingsStatus();
  }

  function onCfgChange(k, v) {
    saveCfg(); applyLook();
    if (k === 'quality') sizeCanvas();
    if (k === 'mode') {
      S.wasActive = false;
      if (S.active && v === 'relative') resetRelativeOrigin();
    }
    if (k === 'enabled') { if (v) startCamera(); else stopCamera(); }
    if (k === 'source') { if (v === 'demo') startDemo(false); else startCamera(); }
    if (['deviceId', 'resolution', 'fps', 'engine', 'assets', 'delegate'].includes(k) && S.running) startCamera();
    updateSettingsStatus();
  }

  function learn(kind) {
    const el0 = document.getElementById('agSetStatus');
    if (!S.handSeen) { updateSettingsStatus(); if (el0) el0.textContent = 'No hand seen. Hold the pose in front of the camera, then press Learn again.'; return; }
    if (S.engine !== 'landmarker') { if (el0) el0.textContent = 'Learn needs MediaPipe landmarks. Switch Vision engine back to Auto or MediaPipe, then try again.'; return; }
    const m = S.metrics, g = AIR.gesture;
    if (kind === 'pinch') {
      g.pinchEnter = +clamp(Math.max(m.ti, m.tm) * 1.18, .18, 2.4).toFixed(2);
      g.pinchExit = +clamp(Math.max(g.pinchEnter * 1.42, g.pinchEnter + .18), .3, 3).toFixed(2);
      g.ringFoldMax = +clamp(Math.max(m.ring * 1.20, .2), .2, 2).toFixed(2);
      g.pinkyFoldMax = +clamp(Math.max(m.pinky * 1.20, .2), .2, 2).toFixed(2);
    } else {
      g.clickUp = +clamp(Math.max(m.ti * 1.08, g.pinchEnter * 1.18), g.pinchEnter + .08, 3).toFixed(2);
      g.clickDown = +clamp(g.pinchEnter * .92, .1, g.clickUp - .03).toFixed(2);
    }
    saveCfg(); Sound.play('calibrate'); buildSettings();
    const el = document.getElementById('agSetStatus');
    if (el) el.textContent = kind === 'pinch' ? 'Pinch thresholds captured. Now lift the index and learn the click.' : 'Click lift captured. Test it in the lab.';
  }

  function copyDiagnostics() {
    const data = diagnostic();
    const text = JSON.stringify(data, null, 2);
    try {
      navigator.clipboard.writeText(text).then(
        () => { const el = document.getElementById('agSetStatus'); if (el) el.textContent = 'Diagnostics copied to clipboard.'; },
        () => { console.log(text); }
      );
    } catch (e) { try { console.log(text); } catch (_) {} }
  }

  function resetAir() {
    if (!window.confirm('Reset every Air gesture setting to defaults?')) return;
    cfgRoot.air = merge(AIR_DEF, {});
    saveCfg();
    try { location.reload(); } catch (e) { buildSettings(); }
  }

  function diagnostic() {
    return {
      version: VERSION,
      status: S.status, statusText: S.statusText, engine: S.engine, engineState: S.engineState,
      engineError: S.engineError, running: S.running, demo: S.demo,
      handSeen: S.handSeen, handedness: S.handedness, handScore: S.handScore,
      detectFps: +S.detectFps.toFixed(1), inferCount: S.inferCount,
      metrics: Object.assign({}, S.metrics), contour: Object.assign({}, S.contour),
      active: S.active, locked: S.locked, clickCount: S.clickCount,
      tap: { base: +(S.tapBase || 0).toFixed(2), peak: +(S.tapPeak || 0).toFixed(2), up: !!S.indexUp },
      target: S.targetInfo ? { type: S.targetInfo.type, label: S.targetInfo.label } : null,
      stream: !!S.stream, video: S.video ? { w: S.video.videoWidth, h: S.video.videoHeight, state: S.video.readyState } : null,
      devices: S.deviceList.map(d => ({ id: d.deviceId, label: d.label })),
      secure: window.isSecureContext, config: clone(AIR)
    };
  }

  /* -------------------------------------------------------------- simulation */
  function syntheticPose(kind) {
    const p = [
      [.50,.72],[.435,.685],[.382,.645],[.335,.605],[.300,.575],
      [.432,.585],[.432,.505],[.432,.445],[.430,.390],
      [.500,.560],[.500,.470],[.500,.410],[.500,.360],
      [.568,.585],[.578,.520],[.588,.478],[.598,.448],
      [.632,.612],[.650,.562],[.662,.532],[.674,.505]
    ].map(([x, y]) => ({ x, y, z: 0 }));
    if (kind === 'pen' || kind === 'click') {
      p[4] = { x: .482, y: .520, z: 0 };
      p[8] = kind === 'click' ? { x: .510, y: .305, z: 0 } : { x: .510, y: .512, z: 0 };
      p[12] = { x: .500, y: .535, z: 0 };
      p[16] = { x: .578, y: .585, z: 0 };
      p[20] = { x: .640, y: .612, z: 0 };
      p[14] = { x: .578, y: .585, z: 0 };
      p[15] = { x: .578, y: .585, z: 0 };
      p[18] = { x: .640, y: .612, z: 0 };
      p[19] = { x: .640, y: .612, z: 0 };
    }
    return p;
  }

  function feedPose(kind, ts) {
    const t = ts == null ? nowMs() : ts;
    const lm = syntheticPose(kind);
    ingestLandmarks(lm, 'Right', 1, t);
    return t;
  }

  /* ---------------------------------------------------------------- public API */
  window.AirGesture = {
    version: VERSION,
    get config() { return AIR; },
    get state() {
      return {
        status: S.status, statusText: S.statusText, active: S.active, visible: S.visible,
        locked: S.locked, engine: S.engine, engineState: S.engineState, running: S.running,
        demo: S.demo, handSeen: S.handSeen, clickCount: S.clickCount,
        lite: S.lite, point: { x: +S.point.x.toFixed(1), y: +S.point.y.toFixed(1) },
        tap: { base: +(S.tapBase || 0).toFixed(2), peak: +(S.tapPeak || 0).toFixed(2), up: !!S.indexUp },
        raw: { x: S.raw.x, y: S.raw.y },
        relativeOrigin: S.relOrigin ? { x: +S.relOrigin.x.toFixed(3), y: +S.relOrigin.y.toFixed(3) } : null,
        filters: {
          fx: { x: S.fx.x, dx: S.fx.dx, t: S.fx.t },
          fy: { x: S.fy.x, dx: S.fy.dx, t: S.fy.t }
        }
      };
    },
    start() { AIR.enabled = true; saveCfg(); return startCamera(); },
    stop() { AIR.enabled = false; saveCfg(); stopCamera(); },
    toggle() { if (S.running) this.stop(); else this.start(); },
    startDemo(auto) { AIR.enabled = true; saveCfg(); startDemo(auto != null ? auto : false); },
    stopDemo() { stopDemo(); },
    setSource(source) { AIR.vision.source = source === 'demo' ? 'demo' : 'camera'; saveCfg(); if (source === 'demo') startDemo(false); else startCamera(); },
    setEnabled(v) { AIR.enabled = !!v; saveCfg(); if (AIR.enabled) startCamera(); else stopCamera(); },
    refreshDevices(force) { return refreshDevices(force !== false); },
    attachPreview(canvas) { return attachPreview(canvas); },
    detachPreview(canvas) { detachPreview(canvas); },
    metrics() { return Object.assign({}, S.metrics, { contour: Object.assign({}, S.contour) }); },
    diagnostics() { return diagnostic(); },
    describeTarget() { return S.targetInfo ? { type: S.targetInfo.type, label: S.targetInfo.label } : null; },
    click() { doClick('api'); },
    setPointerStyle(style) {
      if (!POINTER_STYLES.some(s => s[0] === style)) return false;
      AIR.pointer.style = style; saveCfg(); applyLook(); return true;
    },
    pointerStyles() { return POINTER_STYLES.map(s => ({ id: s[0], name: s[1] })); },
    learn(kind) { learn(kind); },
    rebuildSettings() { buildSettings(); },
    openSettings() { try { window.CodaKiosk && window.CodaKiosk.openSettings && window.CodaKiosk.openSettings('air'); } catch (e) {} },
    save() { saveCfg(); },
    reset() { cfgRoot.air = merge(AIR_DEF, {}); saveCfg(); try { location.reload(); } catch (e) {} },
    __test: {
      feedPose: feedPose, syntheticPose: syntheticPose, ingest: ingestLandmarks,
      findTarget: findTarget, mapPoint: mapPoint, mapRelative: mapRelative, tickPointer: tickPointer, config: AIR,
      setStatus: setStatus, activate: activate, release: release,
      setPoint(x, y) { S.point.x = x; S.point.y = y; S.visible = true; S.active = true; const r = rootEl(); if (r) r.classList.add('ag-on'); }
    }
  };

  /* -------------------------------------------------------------------- init */
  function init() {
    mountUI();
    if (document.getElementById('airCtl')) buildSettings();
    ensureLoop();
    const tab = document.querySelector('.tab[data-tab="air"]');
    if (tab) tab.addEventListener('click', () => { refreshDevices(true); updateSettingsStatus(); });
    window.addEventListener('beforeunload', () => stopCamera(true));
    window.addEventListener('pagehide', () => stopCamera(true));
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && S.running && S.video && S.video.paused) S.video.play().catch(() => {});
    });
    if (!window.isSecureContext && AIR.vision.source === 'camera') {
      S.engineError = 'Camera needs https:// or http://localhost.';
      if (AIR.debug.logToConsole) { try { console.warn('[airgesture]', S.engineError); } catch (e) {} }
    }
    updateSettingsStatus();
    const q = new URLSearchParams(location.search);
    if (!AIR.enabled) { setStatus('off', 'AIR OFF'); return; }
    if (q.get('demo') === '1' || AIR.vision.source === 'demo') {
      startDemo(q.get('auto') === '1');
    } else if (AIR.autoStart) {
      setTimeout(() => { if (AIR.enabled && !S.running && !S.demo) startCamera(); }, Math.max(0, num(AIR.startDelayMs, 1400)));
    }
  }

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, { once: true });
  else init();
})();

